// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.*;
/**
 * Samples the search-space completely at random. Used for comparing other
 * optimizers to 'worst-case' performance.
 */
public class RND extends Optimizer {
	/**
	 * Construct the object.
	 */
	public RND() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public RND(Problem problem) {
		super(problem);
	}

	@Override
	public double[] getDefaultParameters() {
		return null;
	}

	@Override
	public String getName() {
		return "RND";
	}

	@Override
	public double[] getLowerBound() {
		return null;
	}

	@Override
	public double[] getUpperBound() {
		return null;
	}

	@Override
	public int getDimensionality() {
		return 0;
	}

	@Override
	public Result optimize(double[] parameters) {
		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		int n = problem.getDimensionality();

		// Allocate agent position and search-range vectors.
		double[] x = new double[n]; // Current position.
		double[] g = new double[n]; // Best-found position.

		// Initialize agent-position in search-space.
		Tools.initializeUniform(x, lowerBound, upperBound);

		// Initialize fitness to worst possible.
		double fitness = problem.getMaxFitness();

		// Initialize feasibility.
		boolean feasible = false;

		int i;
		for (i = 0; problem.continueOptimization(i, fitness, feasible); i++) {
			// Sample from entire search-space.
			Tools.initializeUniform(x, lowerBound, upperBound);

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(x);

			// Compute fitness if feasibility is same or better.
			if (Tools.isBetterFeasible(feasible, newFeasible)) {
				// Compute new fitness.
				double newFitness = problem.fitness(x, fitness, feasible,
						newFeasible);

				// Update best-known position and fitness.
				if (Tools.isBetterFeasibleFitness(feasible, newFeasible,
						fitness, newFitness)) {
					// Update best-known position.
					Tools.copy(x, g);

					// Update best-known fitness.
					fitness = newFitness;

					// Update feasibility.
					feasible = newFeasible;
				}
			}

			// Trace fitness of best found solution.
			trace(i, fitness, feasible);
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(g, fitness, feasible, i);
	}
}
