package swarmops.optimizers.sso;

import java.util.ArrayList;

public abstract class Enacba {

	private String name = null;
	
	public Enacba( String name) {
		this.name = name;
	}
	
	abstract public double calculate(ArrayList<Double> x);	

	@Override
	public String toString() {
		return name;
	}
	
}
