package swarmops.optimizers.sso;

import java.util.ArrayList;

import swarmops.Problem;

/*
 * Sphere
 */
public class FX extends Enacba {
	
	Problem problem;

	public FX(Problem problem) {
		super(problem.getName());
		this.problem = problem;
	}
	
	@Override
	public double calculate(ArrayList<Double> X) {
		
		double[] arr = new double[X.size()];
		for (int i = 0; i < X.size(); i++) {
			arr[i] = X.get(i);
		}
		return problem.fitness(arr);
	}

}