package swarmops.optimizers.sso;

import java.util.ArrayList;

public class MyProblem {

	public final ArrayList<Razpon> razponi;
	public final int steviloSpremenljivk;
	public final boolean MAX; //true -> find maximum
	public final Enacba enacba;	
	
	public MyProblem(ArrayList<Razpon> razponi, boolean MAX, Enacba enacba) {	
		this.razponi = razponi;
		this.steviloSpremenljivk = razponi.size();
		this.MAX = MAX;
		this.enacba = enacba;			
	}

	@Override
	public String toString() {		
		String string = new String(steviloSpremenljivk + "\t" + MAX 
				+ "\t" + enacba);
		return string;
	}
	
}
