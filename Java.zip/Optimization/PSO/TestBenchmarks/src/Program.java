// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

import java.io.IOException;
import swarmops.*;
import swarmops.optimizers.*;
import swarmops.problems.*;

/**
 * Test optimizer on benchmark problems.
 */
public class Program {
	// Create optimizer object.
	static Optimizer optimizer = new SSO(); //MOL
	// static Optimizer optimizer = new DESuite(DECrossover.Variant.Rand1Bin,
	// DESuite.DitherVariant.None);

	// Control parameters for optimizer.
	//static final double[] parameters = optimizer.getDefaultParameters();
	static final double[] parameters = PSO.Parameters.allBenchmarks5Dim10000IterA;
	//allBenchmarks5Dim10000IterA;
	// static final double[] parameters =
	// PSO.Parameters.allBenchmarks5Dim10000IterA;

	// Optimization settings.
	static final int numRuns = 50;
	static final int dim = 5;
	static final int dimFactor = 1000;
	static final int numIterations = dimFactor * dim;

	// Mangle search-space.
	static final boolean useMangler = false;
	static final double spillover = 0.05; // E.g. 0.05
	static final double displacement = 0.1; // E.g. 0.1
	static final double diffusion = 0.01; // E.g. 0.01
	static final double fitnessNoise = 0.01; // E.g. 0.01

	/**
	 * Optimize the given problem and output result-statistics.
	 * 
	 * @throws IOException
	 */
	static void doOptimize(Problem problem) throws IOException {
		if (useMangler) {
			// Wrap problem-object in search-space mangler.
			problem = new Mangler(problem, diffusion, displacement, spillover,
					fitnessNoise);
		}

		// Create a fitness trace for tracing the progress of optimization re.
		// mean.
		int numMeanIntervals = 3000;
		FitnessTrace fitnessTraceMean = new FitnessTraceMean(numIterations,
				numMeanIntervals);

		// Create a fitness trace for tracing the progress of optimization re.
		// quartiles.
		// Note that fitnessTraceMean is chained to this object by passing it to
		// the constructor, this causes both fitness traces to be used.
		int numQuartileIntervals = 10;
		FitnessTrace fitnessTraceQuartiles = new FitnessTraceQuartiles(numRuns,
				numIterations, numQuartileIntervals, fitnessTraceMean);

		// Create a feasibility trace for tracing the progress of optimization
		// re. fesibility.
		FeasibleTrace feasibleTrace = new FeasibleTrace(numIterations,
				numMeanIntervals, fitnessTraceQuartiles);

		// Assign the problem etc. to the optimizer.
		optimizer.problem = problem;
		optimizer.fitnessTrace = feasibleTrace;

		// Wrap the optimizer in a logger of result-statistics.
		boolean statisticsOnlyFeasible = true;
		Statistics statistics = new Statistics(optimizer,
				statisticsOnlyFeasible);

		// Wrap it again in a repeater.
		Repeat repeat = new RepeatSum(statistics, numRuns);

		// Perform the optimization runs.
		repeat.fitness(parameters);

		// Compute result-statistics.
		statistics.compute();

		// Output result-statistics.
		System.out.printf("%s & %s & %s & %s & %s & %s & %s & %s & %s \\\\\n",
				problem.getName(), Tools
						.formatNumber(statistics.fitnessStatistics.getMean()),
				Tools.formatNumber(statistics.fitnessStatistics
						.getStandardDeviation()), Tools
						.formatNumber(statistics.fitnessQuartiles.getMin()),
				Tools.formatNumber(statistics.fitnessQuartiles.getQ1()), Tools
						.formatNumber(statistics.fitnessQuartiles.getMedian()),
				Tools.formatNumber(statistics.fitnessQuartiles.getQ3()), Tools
						.formatNumber(statistics.fitnessQuartiles.getMax()),
				Tools.formatPercent(statistics.getFeasibleFraction()));

		// Output fitness and feasible traces.
		fitnessTraceMean.writeToFile(optimizer.getName() + "-FitnessTraceMean-"
				+ problem.getName() + ".txt");
		fitnessTraceQuartiles.writeToFile(optimizer.getName()
				+ "-FitnessTraceQuartiles-" + problem.getName() + ".txt");
		feasibleTrace.writeToFile(String.format(optimizer.getName()
				+ "-FeasibleTrace-" + problem.getName() + ".txt"));
	}

	public static void main(String[] args) throws IOException {
		// Initialize PRNG.
		Globals.random = new swarmops.random.MersenneTwister();

		// Output optimization settings.
		System.out.printf("Benchmark-tests.\n");
		System.out.printf("Optimizer: %s\n", optimizer.getName());
		System.out.printf("Using following parameters:\n");
		Tools.printParameters(optimizer, parameters);
		System.out.printf("Number of runs per problem: %d\n", numRuns);
		System.out.printf("Dimensionality: %d\n", dim);
		System.out.printf("Dim-factor: %d\n", dimFactor);
		if (useMangler) {
			System.out.printf("Mangle search-space:\n");
			System.out.printf("\tSpillover:     %g\n", spillover);
			System.out.printf("\tDisplacement:  %g\n", displacement);
			System.out.printf("\tDiffusion:     %g\n", diffusion);
			System.out.printf("\tFitnessNoise:  %g\n", fitnessNoise);
		} else {
			System.out.printf("Mangle search-space: No\n");
		}
		System.out.printf("\n");
		System.out
				.printf("Problem & Mean & Std.Dev. & Min & Q1 & Median & Q3 & Max & Feasible \\\\\n");
		System.out.printf("\\hline\n");

		// Starting-time.
		long t1 = System.currentTimeMillis();


		//doOptimize(new Schwefel222(dim, numIterations));
		//8
		doOptimize(new Schwefel(dim, numIterations));
		//9
		//doOptimize(new Rastrigin(dim, numIterations));
		//10
		//doOptimize(new Ackley(dim, numIterations));
		//11
		//doOptimize(new Griewank(dim, numIterations));
		
		
		//doOptimize(new Penalized1(dim, numIterations));
		//doOptimize(new Penalized2(dim, numIterations));
		//doOptimize(new QuarticNoise(dim, numIterations));
		//doOptimize(new Rosenbrock(dim, numIterations));
		//doOptimize(new Schwefel12(dim, numIterations));
		//doOptimize(new Schwefel221(dim, numIterations));
		//doOptimize(new Schwefel222(dim, numIterations));
		//doOptimize(new Sphere(dim, numIterations));
		//doOptimize(new Step(dim, numIterations));
		 
		
		// End-time.
		long t2 = System.currentTimeMillis();

		// Output time-usage.
		System.out.printf("\n");
		System.out.printf("Time usage: %.2f seconds\n",
				(double) (t2 - t1) / 1000);
	}
}
