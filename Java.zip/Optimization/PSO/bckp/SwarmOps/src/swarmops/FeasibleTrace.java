// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.io.Writer;
import java.io.IOException;
import swarmops.statistics.StatisticsAccumulator;

/**
 * Store feasibility-values during optimization runs and write them to a file
 * afterwards. The number of iterations per optimization run must be known in
 * advance.
 */
public class FeasibleTrace extends FitnessTrace {
	/**
	 * Construct a new object.
	 * 
	 * @param numIterations
	 *            number of iterations per optimization run.
	 * @param numIntervals
	 *            approximate number of intervals to show mean.
	 */
	public FeasibleTrace(int numIterations, int numIntervals) {
		this(numIterations, numIntervals, null);
	}

	/**
	 * Construct a new object.
	 * 
	 * @param numIterations
	 *            number of iterations per optimization run.
	 * @param numIntervals
	 *            approximate number of intervals to show mean.
	 * @param chainedFitnessTrace
	 *            chained FitnessTrace object.
	 */
	public FeasibleTrace(int numIterations, int numIntervals,
			FitnessTrace chainedFitnessTrace) {
		super(chainedFitnessTrace, numIterations, numIntervals, 0);

		// Allocate trace.
		trace = new StatisticsAccumulator[maxIntervals];
		for (int i = 0; i < maxIntervals; i++) {
			trace[i] = new StatisticsAccumulator();
		}
	}

	/**
	 * Storage for the feasible trace.
	 */
	protected StatisticsAccumulator[] trace;

	/**
	 * Clear the stored feasible trace.
	 */
	public void Clear() {
		for (int i = 0; i < trace.length; i++) {
			trace[i].clear();
		}
	}

	@Override
	protected void log(int index, double fitness, boolean feasible) {
		trace[index].accumulate((feasible) ? (1) : (0));
	}

	@Override
	public void write(Writer writer) throws IOException {
		writer.write(String
				.format("Mean feasibility 0 means all solutions were infeasible.%n"));
		writer.write(String
				.format("Mean feasibility 1 means all solutions were feasible.%n%n"));
		writer.write(String.format("# Iteration\tMean Feasibility%n"));
		writer.write(String
				.format("# Iteration\tMean Fitness\tStdError\tMin\tMax%n%n"));

		for (int i = 0; i < trace.length; i++) {
			StatisticsAccumulator t = trace[i];

			if (t.getCount() > 0) {
				writer.write(String.format("%d %g%n", iteration(i), t.getMean()));
			} else {
				break;
			}
		}

		writer.close();
	}
}
