// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Prints parameters and fitness to Console. Useful in viewing the progress of
 * meta-optimization. Works as a 'transparent' wrapper for the problem to be
 * optimized. Note that feasibility is computed here.
 */
public class FitnessPrint extends ProblemWrapper {
	/**
	 * Constructs a new object.
	 * 
	 * @param problem
	 *            the problem being wrapped.
	 */
	public FitnessPrint(Problem problem) {
		this(problem, false);
	}

	/**
	 * Constructs the object.
	 * 
	 * @param problem
	 *            the problem being wrapped.
	 * @param formatAsArray
	 *            format output as Java array.
	 */
	public FitnessPrint(Problem problem, boolean formatAsArray) {
		super(problem);

		this.formatAsArray = formatAsArray;
	}

	/**
	 * Format output as Java array.
	 */
	public final boolean formatAsArray;

	@Override
	public String getName() {
		return "FitnessPrint (" + problem.getName() + ")";
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit,
			boolean oldFeasible, boolean newFeasible) {
		// Compute fitness of wrapped problem and print the result.

		double fitness = problem.fitness(parameters, fitnessLimit);

		Tools.printSolution(parameters, fitness, fitnessLimit, oldFeasible,
				newFeasible, formatAsArray);

		return fitness;
	}

	@Override
	public void beginOptimizationRun() {
		// At beginning of new optimization run print a newline.

		Tools.printNewline();
	}
}
