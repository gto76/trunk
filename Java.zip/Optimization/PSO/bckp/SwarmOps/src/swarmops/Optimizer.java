// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Base-class for an optimizer.
 */
public abstract class Optimizer extends Problem {
	/**
	 * Construct the object.
	 */
	public Optimizer() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public Optimizer(Problem problem) {
		super();

		this.problem = problem;
	}

	/**
	 * Problem to optimize.
	 */
	public Problem problem;

	/**
	 * Fitness-trace used for tracing the progress of optimization.
	 */
	public FitnessTrace fitnessTrace;

	/**
	 * Return the default control parameters for the optimizer.
	 */
	public abstract double[] getDefaultParameters();

	/**
	 * Optimize with default parameters.
	 * 
	 * @return best-found candidate solution.
	 */
	public Result optimize() {
		return optimize(getDefaultParameters());
	}

	/**
	 * Optimize using designated control parameters.
	 * 
	 * @param parameters
	 *            control parameters for optimizer.
	 * @return best-found candidate solution.
	 */
	public Result optimize(double[] parameters) {
		return optimize(parameters, getMaxFitness());
	}

	/**
	 * Optimize using designated control parameters.
	 * 
	 * @param parameters
	 *            control parameters for optimizer.
	 * @param fitnessLimit
	 *            preemptive fitness limit.
	 * @return best-found candidate solution.
	 */
	public Result optimize(double[] parameters, double fitnessLimit) {
		return optimize(parameters);
	}

	/**
	 * Trace the progress of optimization.
	 * 
	 * @param iteration
	 *            number of iterations (i.e. fitness evaluations) performed.
	 * @param fitness
	 *            fitness of best-found candidate solution.
	 * @param feasible
	 *            feasibility of best-found candidate solution.
	 */
	protected void trace(int iteration, double fitness, boolean feasible) {
		if (fitnessTrace != null) {
			fitnessTrace.add(iteration, fitness, feasible);
		}
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit) {
		return optimize(parameters, fitnessLimit).fitness;
	}

	@Override
	public double getMinFitness() {
		return problem.getMinFitness();
	}
}
