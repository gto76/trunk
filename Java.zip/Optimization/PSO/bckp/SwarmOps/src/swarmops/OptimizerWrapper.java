// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Transparently wrap an Optimizer-object by calling through for all methods.
 * This is very similar to ProblemWrapper but Java does not allow for multiple
 * inheritance and we need this class to inherit from Optimizer and therefore
 * cannot make it inherit from ProblemWrapper as well.
 */
public abstract class OptimizerWrapper extends Optimizer {
	/**
	 * Construct the object.
	 * 
	 * @param optimizer
	 *            optimizer being wrapped.
	 */
	public OptimizerWrapper(Optimizer optimizer) {
		super();
		this.optimizer = optimizer;
	}

	/**
	 * The optimizer that is being wrapped.
	 */
	public Optimizer optimizer;

	@Override
	public double[] getLowerBound() {
		return optimizer.getLowerBound();
	}

	@Override
	public double[] getUpperBound() {
		return optimizer.getUpperBound();
	}

	@Override
	public double[] getLowerInit() {
		return optimizer.getLowerInit();
	}

	@Override
	public double[] getUpperInit() {
		return optimizer.getUpperInit();
	}

	@Override
	public int getDimensionality() {
		return optimizer.getDimensionality();
	}

	@Override
	public double getMinFitness() {
		return optimizer.getMinFitness();
	}

	@Override
	public double getMaxFitness() {
		return optimizer.getMaxFitness();
	}

	@Override
	public double getAcceptableFitness() {
		return optimizer.getAcceptableFitness();
	}

	@Override
	public String[] getParameterName() {
		return optimizer.getParameterName();
	}

	@Override
	public boolean enforceConstraints(double[] parameters) {
		return optimizer.enforceConstraints(parameters);
	}

	@Override
	public boolean isFeasible(double[] parameters) {
		return optimizer.isFeasible(parameters);
	}

	@Override
	public void beginOptimizationRun() {
		optimizer.beginOptimizationRun();
	}

	@Override
	public void endOptimizationRun() {
		optimizer.endOptimizationRun();
	}

	@Override
	public boolean continueOptimization(int iterations, double fitness,
			boolean feasible) {
		return optimizer.continueOptimization(iterations, fitness, feasible);
	}

	@Override
	public double[] getDefaultParameters() {
		return optimizer.getDefaultParameters();
	}
}
