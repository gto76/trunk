// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Base-class for an optimization problem.
 */
public abstract class Problem {
	/**
	 * Construct the object.
	 */
	public Problem() {
	}

	/**
	 * Construct the object.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Problem(int maxIterations) {
		this(maxIterations, true);
	}

	/**
	 * Construct the object.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 * @param requireFeasible
	 *            require solution to be feasible (satisfy constraints.)
	 */
	public Problem(int maxIterations, boolean requireFeasible) {
		this.maxIterations = maxIterations;
		this.requireFeasible = requireFeasible;
	}

	/**
	 * Maximum number of iterations (i.e. fitness evaluations) to perform.
	 */
	public int maxIterations;

	/**
	 * Require solution to be feasible (satisfy constraints.)
	 */
	protected boolean requireFeasible;

	/**
	 * Return the name of the optimization problem.
	 */
	public abstract String getName();

	/**
	 * Return lower boundary of the search-space.
	 */
	public abstract double[] getLowerBound();

	/**
	 * Return upper boundary of the search-space.
	 */
	public abstract double[] getUpperBound();

	/**
	 * Return lower initialization boundary, if different from search-space
	 * boundary.
	 */
	public double[] getLowerInit() {
		return getLowerBound();
	}

	/**
	 * Return upper initialization boundary, if different from search-space
	 * boundary.
	 */
	public double[] getUpperInit() {
		return getUpperBound();
	}

	/**
	 * Minimum (i.e. best) fitness possible. This is especially important if
	 * using meta-optimization where the fitness is assumed to be non-negative
	 * and should be roughly equivalent amongst all the problems meta-optimized
	 * for.
	 */
	public abstract double getMinFitness();

	/**
	 * Maximum (i.e. worst) fitness possible.
	 */
	public double getMaxFitness() {
		return java.lang.Double.MAX_VALUE;
	}

	/**
	 * Threshold for an acceptable fitness value.
	 */
	public double getAcceptableFitness() {
		return getMinFitness();
	}

	/**
	 * Return dimensionality of the problem, that is, the number of parameters
	 * in a candidate solution.
	 */
	public abstract int getDimensionality();

	/**
	 * Array with names of parameters.
	 */
	public String[] getParameterName() {
		return null;
	}

	/**
	 * Compute and return fitness for the given parameters.
	 * 
	 * @param parameters
	 *            candidate solution.
	 */
	public double fitness(double[] parameters) {
		return fitness(parameters, true);
	}

	/**
	 * Compute and return fitness for the given parameters. The fitness
	 * evaluation is aborted preemptively, if the fitness becomes higher (i.e.
	 * worse) than fitnessLimit, and if it is not possible for the fitness to
	 * improve.
	 * 
	 * @param parameters
	 *            candidate solution.
	 * @param fitnessLimit
	 *            preemptive fitness limit.
	 */
	public double fitness(double[] parameters, double fitnessLimit) {
		return fitness(parameters);
	}

	/**
	 * Compute and return fitness for the given parameters. The fitness
	 * evaluation is aborted preemptively if feasibility of the new candidate
	 * solution is same or better as that of the old candidate solution, and if
	 * the fitness becomes higher (i.e. worse) than fitnessLimit and if it is
	 * not possible for the fitness to improve.
	 * 
	 * @param parameters
	 *            candidate solution.
	 * @param fitnessLimit
	 *            preemptive fitness limit.
	 * @param oldFeasible
	 *            feasibility of old candidate solution.
	 * @param newFeasible
	 *            feasibility of new candidate solution.
	 * @return
	 */
	public double fitness(double[] parameters, double fitnessLimit,
			boolean oldFeasible, boolean newFeasible) {
		double f;
		if (Tools.isBetterFeasible(oldFeasible, newFeasible)) {
			f = fitness(parameters, fitnessLimit);
		} else {
			f = fitness(parameters);
		}
		return f;
	}

	/**
	 * Compute and return fitness for the given parameters.
	 * 
	 * @param parameters
	 *            candidate solution.
	 * @param feasible
	 *            feasibility of candidate solution.
	 */
	public double fitness(double[] parameters, boolean feasible) {
		return fitness(parameters, getMaxFitness(), feasible, feasible);
	}

	/**
	 * Has the gradient has been implemented?
	 */
	public boolean hasGradient() {
		return false;
	}

	/**
	 * Compute the gradient of the fitness-function.
	 * 
	 * @param x
	 *            candidate solution.
	 * @param v
	 *            array for holding the gradient.
	 * @return Computation time-complexity factor. E.g. if fitness takes time
	 *         O(n) to compute and gradient takes time O(n*n) to compute, then
	 *         return n.
	 */
	public int gradient(double[] x, double[] v) {
		throw new java.lang.UnsupportedOperationException();
	}

	/**
	 * Enforce constraints and evaluate feasibility.
	 * 
	 * @param parameters
	 *            candidate solution.
	 */
	public boolean enforceConstraints(double[] parameters) {
		// If you do not wish to enforce constraints you should make
		// this call isFeasible().

		// By default we bound the candidate solution to the search-space
		// boundaries.
		Tools.bound(parameters, getLowerBound(), getUpperBound());

		// Since we know that candidate solution is now within bounds and this
		// is all that is required for feasibility, we could just return true
		// here. isFeasible() is called for educational purposes and because
		// most optimizers do not call isFeasible() but call
		// enforceConstraints() so if the user were to only override
		// isFeasible() constraint handling would not work as expected.
		return isFeasible(parameters);
	}

	/**
	 * Evaluate feasibility (constraint satisfaction).
	 * 
	 * @param parameters
	 *            candidate solution.
	 * @return
	 */
	public boolean isFeasible(double[] parameters) {
		return Tools.isBetweenBounds(parameters, getLowerBound(),
				getUpperBound());
	}

	/**
	 * Called at the beginning of an optimization run.
	 */
	public void beginOptimizationRun() {
		// Do nothing by default.
	}

	/**
	 * Called at the end of an optimization run.
	 */
	public void endOptimizationRun() {
		// Do nothing by default.
	}

	/**
	 * Return whether optimization is allowed to continue.
	 * 
	 * @param iterations
	 *            number of iterations performed in optimization run.
	 * @param fitness
	 *            best fitness found in optimization run.
	 * @param feasible
	 *            feasibility of best found candidate solution.
	 */
	public boolean continueOptimization(int iterations, double fitness,
			boolean feasible) {
		return (iterations < maxIterations && !(fitness <= getAcceptableFitness() && (!requireFeasible || feasible)));
	}
}
