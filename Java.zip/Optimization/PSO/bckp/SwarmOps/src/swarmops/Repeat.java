// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Base-class for performing a number of optimization runs.
 */
public abstract class Repeat extends Problem {
	/**
	 * Construct the object.
	 * 
	 * @param optimizer
	 *            optimizer to use.
	 * @param numRuns
	 *            number of optimization runs to perform.
	 */
	public Repeat(Optimizer optimizer, int numRuns) {
		super();

		this.optimizer = optimizer;
		this.numRuns = numRuns;
	}

	/**
	 * Optimizer to use.
	 */
	protected final Optimizer optimizer;

	/**
	 * Number of optimization runs to perform.
	 */
	protected final int numRuns;

	/**
	 * Compute fitness using Optimizer's default parameters.
	 */
	public double fitness() {
		return fitness(optimizer.getDefaultParameters());
	}

	@Override
	public String getName() {
		return optimizer.getName();
	}

	@Override
	public double[] getLowerBound() {
		return optimizer.getLowerBound();
	}

	@Override
	public double[] getUpperBound() {
		return optimizer.getUpperBound();
	}

	@Override
	public double[] getLowerInit() {
		return optimizer.getLowerInit();
	}

	@Override
	public double[] getUpperInit() {
		return optimizer.getUpperInit();
	}

	@Override
	public int getDimensionality() {
		return optimizer.getDimensionality();
	}
}
