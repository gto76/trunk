// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Performs a number of optimization runs and returns the sum of the fitness.
 * Ignores feasibility (constraint satisfaction.) This allows for Preemptive
 * Fitness Evaluation.
 */
public class RepeatSum extends Repeat {
	/**
	 * Construct the object.
	 * 
	 * @param optimizer
	 *            optimizer to use.
	 * @param numRuns
	 *            number of optimization runs to perform.
	 */
	public RepeatSum(Optimizer optimizer, int numRuns) {
		super(optimizer, numRuns);
	}

	@Override
	public String getName() {
		return "RepeatSum(" + optimizer.getName() + ")";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double fitness(double[] parameters, double fitnessLimit) {
		// Initialize the fitness sum.
		double fitnessSum = 0;

		// Perform a number of optimization runs.
		for (int i = 0; i < numRuns && fitnessSum < fitnessLimit; i++) {
			// Perform one optimization run.
			Result result = optimizer.optimize(parameters, fitnessLimit
					- fitnessSum);

			// Compute the normalized fitness.
			double fitnessNormalized = result.fitness
					- optimizer.getMinFitness();

			assert fitnessNormalized >= 0;

			// Accumulate the fitness sum.
			fitnessSum += fitnessNormalized;
		}

		return fitnessSum;
	}
}
