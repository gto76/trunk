// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Results of optimization, that is, the best found solution, its fitness, its
 * feasibility, and the number of optimization iterations used to find the
 * solution.
 */
public class Result {
	/**
	 * Construct an object with optimization results, not initialized.
	 */
	public Result() {
	}

	/**
	 * Construct an object with optimization results.
	 * 
	 * @param parameters
	 *            best found solution parameters.
	 * @param fitness
	 *            fitness of best found solution.
	 * @param feasible
	 *            feasibility (constraint satisfaction) of best found solution.
	 * @param iterations
	 *            number of optimization iterations used.
	 */
	public Result(double[] parameters, double fitness, boolean feasible,
			int iterations) {
		this.parameters = parameters.clone();
		this.fitness = fitness;
		this.feasible = feasible;
		this.iterations = iterations;
	}

	/**
	 * Best found solution parameters.
	 */
	public double[] parameters;

	/**
	 * Fitness of best found solution.
	 */
	public double fitness;

	/**
	 * Feasibility (constraint satisfaction) associated with best found
	 * solution. Defaults to true if problem is not constrained.
	 */
	public boolean feasible;

	/**
	 * Number of iterations (i.e. fitness evaluations) it took to achieve these
	 * results.
	 */
	public int iterations;
}
