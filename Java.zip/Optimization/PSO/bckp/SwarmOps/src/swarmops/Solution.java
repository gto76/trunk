// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

/**
 * Candidate solution consisting of search-space parameters and their associated
 * fitness value and feasibility.
 */
public class Solution implements Comparable<Solution> {
	/**
	 * Construct the object.
	 * 
	 * @param parameters
	 *            candidate solution parameters.
	 * @param fitness
	 *            fitness for candidate solution.
	 * @param feasible
	 *            feasibility of candidate solution.
	 */
	public Solution(double[] parameters, double fitness, boolean feasible) {
		this.parameters = parameters.clone();
		this.fitness = fitness;
		this.feasible = feasible;
	}

	/**
	 * Candidate solution parameters.
	 */
	public final double[] parameters;

	/**
	 * Fitness of candidate solution.
	 */
	public final double fitness;

	/**
	 * Feasibility of candidate solution.
	 */
	public final boolean feasible;

	@Override
	public int compareTo(Solution o) {
		// Comparer used for sorting a list of Solution-objects
		// according to fitness and feasibility in ascending (worsening)
		// order.

		assert o != null;

		int retVal;

		if (this.fitness == o.fitness && this.feasible == o.feasible) {
			retVal = 0;
		} else if (Tools.isBetterFeasibleFitness(this.feasible, o.feasible,
				this.fitness, o.fitness)) {
			retVal = 1;
		} else {
			retVal = -1;
		}

		return retVal;
	}
}
