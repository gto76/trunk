// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops;

import java.util.Iterator;
import java.util.LinkedList;
import swarmops.statistics.*;

/**
 * Wrapper for an optimizer providing statistics such as mean fitness achieved
 * over a number of optimization runs, best results achieved, etc. Transparently
 * supports the same methods as the the optimizer itself, but stores the
 * optimization results so as to compute the statistics.
 */
public class Statistics extends OptimizerWrapper {
	/**
	 * Create a Statistics-object.
	 * 
	 * @param optimizer
	 *            optimizer-object being wrapped.
	 * @param onlyFeasible
	 *            only use feasible results.
	 */
	public Statistics(Optimizer optimizer, boolean onlyFeasible) {
		super(optimizer);
		this.onlyFeasible = onlyFeasible;
		results = new LinkedList<Result>();
	}

	/**
	 * Only use feasible results.
	 */
	private boolean onlyFeasible;

	/**
	 * Return whether to only use feasible results.
	 */
	public boolean getOnlyFeasible() {
		return onlyFeasible;
	}

	/**
	 * Number of results regardless of feasibility.
	 */
	private int count;

	/**
	 * Number of feasible results.
	 */
	private int countFeasible;

	/**
	 * Fraction of results that are feasible (satisfy constraints).
	 */
	public double getFeasibleFraction() {
		return (double) countFeasible / count;
	}

	/**
	 * Optimization results stored for later computation of statistics.
	 */
	private LinkedList<Result> results;

	/**
	 * Best optimization result achieved, based on fitness alone.
	 */
	public Result bestResult;

	/**
	 * Quartiles for fitness results.
	 */
	public Quartiles fitnessQuartiles;

	/**
	 * Quartiles for iterations results.
	 */
	public Quartiles iterationsQuartiles;

	/**
	 * Fitness statistics such as mean, std.dev., etc.
	 */
	public StatisticsAccumulator fitnessStatistics;

	/**
	 * Iterations statistics such as mean, std.dev., etc.
	 */
	public StatisticsAccumulator iterationsStatistics;

	/**
	 * Compute the statistics. Call this after all optimization runs have
	 * executed.
	 */
	public void compute() {
		// Create new statistics-objects.
		fitnessStatistics = new StatisticsAccumulator();
		iterationsStatistics = new StatisticsAccumulator();

		// Create new quartiles-objects.
		fitnessQuartiles = new Quartiles();
		iterationsQuartiles = new Quartiles();

		int k = results.size();

		if (k > 0) {
			// Best fitness so far.
			double bestFitness = optimizer.getMaxFitness();

			// Convert to arrays.
			Double[] fitnessArray = new Double[k];
			Double[] iterationsArray = new Double[k];

			Iterator<Result> itor = results.iterator();
			for (int i = 0; i < k && itor.hasNext(); i++) {
				Result result = itor.next();

				// Notational convenience.
				double fitness = result.fitness;
				int iterations = result.iterations;

				// Assign to arrays.
				fitnessArray[i] = fitness;
				iterationsArray[i] = new Double(iterations);

				// Accumulate statistics.
				fitnessStatistics.accumulate(fitness);
				iterationsStatistics.accumulate(iterations);

				// Update best-found result.
				if (fitness < bestFitness) {
					bestResult = result;
					bestFitness = fitness;
				}
			}

			// Fitness quartiles.
			fitnessQuartiles.computeUnsortedInplace(fitnessArray);

			// Iterations quartiles.
			iterationsQuartiles.computeUnsortedInplace(iterationsArray);
		} else {
			// Results were empty so there's no best result either.
			bestResult = null;
		}
	}

	/**
	 * Clear the stored data used for computing statistics.
	 */
	public void clear() {
		results.clear();
		bestResult = null;

		count = 0;
		countFeasible = 0;
	}

	@Override
	public String getName() {
		return "Statistics (" + optimizer.getName() + ")";
	}

	@Override
	public Result optimize(double[] parameters, double fitnessLimit) {
		// Call through to the Optimizer.
		Result result = optimizer.optimize(parameters, fitnessLimit);

		// Store optimization result for later use by the Compute() method,
		// if feasibility is required then only store feasible results.
		if (!onlyFeasible || result.feasible) {
			results.add(result);
		}

		if (result.feasible) {
			// Increase count of feasible results.
			countFeasible++;
		}

		// Increase total count of results, regardless of feasibility.
		count++;

		// Return the optimization result.
		return result;
	}
}
