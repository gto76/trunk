// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Globals;
import swarmops.random.RandomSet;

/**
 * Variants of crossover operator for Differential Evolution (DE), originally
 * due to Storner and Price (1).
 * 
 * References:
 * 
 * (1) R. Storn and K. Price. Differential evolution - a simple and efficient
 * heuristic for global optimization over continuous spaces. Journal of Global
 * Optimization, 11:341-359, 1997.
 */
public class DECrossover {
	/** Crossover variants. */
	public enum Variant {
		Rand1Bin, Best1Bin,
	}

	/**
	 * Return name of the crossover variant.
	 */
	public static String getName(Variant variant) {
		String s;

		switch (variant) {
		case Best1Bin:
			s = "Best1Bin";
			break;

		case Rand1Bin:
			s = "Rand1Bin";
			break;

		default:
			s = "Unknown";
			break;
		}

		return s;
	}

	/**
	 * Perform DE crossover.
	 * 
	 * @param crossover
	 *            Crossover variant to be performed.
	 * @param CR
	 *            crossover probability.
	 * @param n
	 *            dimensionality for problem.
	 * @param w
	 *            differential weight (array).
	 * @param x
	 *            current agent position.
	 * @param y
	 *            potentially new agent position.
	 * @param g
	 *            population's best known position.
	 * @param agents
	 *            entire population.
	 * @param randomSet
	 *            random-set used for drawing distinct agents.
	 */
	public static void crossover(Variant crossover, double CR, int n,
			double[] w, double[] x, double[] y, double[] g, double[][] agents,
			RandomSet randomSet) {
		// Agents used in crossover.
		double[] a, b, c;

		switch (crossover) {
		case Best1Bin: {
			// The first agent used in crossover is g.
			a = g;

			// Pick random and distinct agent-indices.
			// Also distinct from agent x.
			int R1 = randomSet.draw();
			int R2 = randomSet.draw();

			b = agents[R1];
			c = agents[R2];
		}
			break;

		case Rand1Bin:
		default: {
			// Pick random and distinct agent-indices.
			// Also distinct from agent x.
			int R1 = randomSet.draw();
			int R2 = randomSet.draw();
			int R3 = randomSet.draw();

			// Refer to the randomly picked agents as a and b.
			a = agents[R1];
			b = agents[R2];
			c = agents[R3];
		}
			break;
		}

		// Pick a random dimension.
		int R = Globals.random.nextIndex(n);

		// Compute potentially new position.
		for (int k = 0; k < n; k++) {
			if (k == R || Globals.random.nextBoolean(CR)) {
				y[k] = a[k] + w[k] * (b[k] - c[k]);
			} else {
				y[k] = x[k];
			}
		}
	}
}
