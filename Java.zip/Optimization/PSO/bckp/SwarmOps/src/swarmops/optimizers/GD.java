// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Gradient Descent (GD), follows the gradient of the problem in small steps.
 */
public class GD extends Optimizer {
	/**
	 * Construct the object.
	 */
	public GD() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public GD(Problem problem) {
		super(problem);
	}

	/** Names of the control parameters. */
	private static final String[] parameterName = { "Stepsize" };

	private static final double[] defaultParameters = { 0.05 };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 0 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 2 };

	@Override
	public double[] getDefaultParameters() {
		return defaultParameters;
	}

	@Override
	public String getName() {
		return "GD";
	}

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public int getDimensionality() {
		return 1;
	}

	/**
	 * Get control parameter stepsize.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static double getStepsize(double[] parameters) {
		return parameters[0];
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameter specific to GD method.
		double stepsize = getStepsize(parameters);

		// Get problem-context.
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent position and search-range.
		double[] x = new double[n]; // Current position.
		double[] v = new double[n]; // Gradient/velocity.
		double[] g = new double[n]; // Best-found position.

		// Initialize agent-position in search-space.
		Tools.initializeUniform(x, lowerInit, upperInit);

		// Enforce constraints and evaluate feasibility.
		boolean feasible = problem.enforceConstraints(x);

		// Compute fitness of initial position.
		// This counts as an iteration below.
		double fitness = problem.fitness(x, feasible);

		// This is the best-found position.
		Tools.copy(x, g);

		// Trace fitness of best found solution.
		trace(0, fitness, feasible);

		int i;
		for (i = 1; problem.continueOptimization(i, fitness, feasible); i++) {
			// Compute gradient.
			// int gradientIterations = problem.gradient(x, v);
			problem.gradient(x, v);

			// Compute norm of gradient-vector.
			double gradientNorm = Tools.norm(v);

			// Compute current stepsize.
			double normalizedStepsize = stepsize / gradientNorm;

			// Move in direction of steepest descent.
			for (int j = 0; j < n; j++) {
				x[j] -= normalizedStepsize * v[j];
			}

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(x);

			// Compute fitness if feasibility (constraint satisfaction) is same
			// or better.
			if (Tools.isBetterFeasible(feasible, newFeasible)) {
				// Compute new fitness.
				double newFitness = problem.fitness(x, fitness, feasible,
						newFeasible);

				// Update best position and fitness found in this run.
				if (Tools.isBetterFeasibleFitness(feasible, newFeasible,
						fitness, newFitness)) {
					// Update this run's best known position.
					Tools.copy(x, g);

					// Update this run's best know fitness.
					fitness = newFitness;
				}
			}

			// Trace fitness of best found solution.
			trace(i, fitness, feasible);

			// Add iterations for gradient computation.
			// This is incompatible with FitnessTrace.
			// i += gradientIterations;
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(g, fitness, feasible, i);
	}
}
