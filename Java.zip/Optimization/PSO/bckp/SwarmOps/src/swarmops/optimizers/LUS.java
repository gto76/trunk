// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Local Unimodal Sampling (LUS) optimizer originally due to Pedersen (1). Does
 * local sampling with an exponential decrease of the sampling-range. Works well
 * for many optimization problems, especially when only short runs are allowed.
 * Is particularly well suited as the overlaying meta-optimizer when tuning
 * parameters for another optimizer.
 * 
 * References:
 * 
 * (1) M.E.H. Pedersen. Tuning & Simplifying Heuristical Optimization. PhD
 * Thesis, University of Southampton, 2010.
 */
public class LUS extends Optimizer {
	/**
	 * Construct the object.
	 */
	public LUS() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public LUS(Problem problem) {
		super(problem);
	}

	/** Names of the control parameters. */
	private static final String[] parameterName = { "Gamma" };

	private static final double[] defaultParameters = { 3.0 };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 0.5 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 100.0 };

	@Override
	public double[] getDefaultParameters() {
		return defaultParameters;
	}

	@Override
	public String getName() {
		return "LUS";
	}

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public int getDimensionality() {
		return 1;
	}

	/**
	 * Get control parameter gamma.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static double getGamma(double[] parameters) {
		return parameters[0];
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameter specific to LUS method.
		double gamma = getGamma(parameters);

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent position and search-range vectors.
		double[] x = new double[n]; // Current position.
		double[] y = new double[n]; // Potentially new position.
		double[] d = new double[n]; // Search-range.

		// Initialize search-range and decrease-factor.
		double r = 1; // Search-range.
		double q = Math.pow(2.0, -1.0 / (n * gamma)); // Decrease-factor (using
														// gamma = 1.0/alpha).

		// Initialize agent-position in search-space.
		Tools.initializeUniform(x, lowerInit, upperInit);

		// Initialize search-range to full search-space.
		Tools.initializeRange(d, lowerBound, upperBound);

		// Enforce constraints and evaluate feasibility.
		boolean feasible = problem.enforceConstraints(x);

		// Compute fitness of initial position.
		// This counts as an iteration below.
		double fitness = problem.fitness(x, feasible);

		// Trace fitness of best found solution.
		trace(0, fitness, feasible);

		int i;
		for (i = 1; problem.continueOptimization(i, fitness, feasible); i++) {
			// Compute potentially new position.
			for (int j = 0; j < n; j++) {
				// Pick a sample from the neighbourhood of the current
				// position and within the given range.
				y[j] = Tools.sampleBounded(x[j], r * d[j], lowerBound[j],
						upperBound[j]);
			}

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(y);

			// Compute fitness if feasibility (constraint satisfaction) is same
			// or better.
			if (Tools.isBetterFeasible(feasible, newFeasible)) {
				// Compute fitness of new position.
				double newFitness = problem.fitness(y, fitness, feasible,
						newFeasible);

				// Update best known position, if improvement.
				if (Tools.isBetterFeasibleFitness(feasible, newFeasible,
						fitness, newFitness)) {
					// Update fitness.
					fitness = newFitness;

					// Update feasibility.
					feasible = newFeasible;

					// Update position by swapping array x and y.
					double[] temp = x;
					x = y;
					y = temp;
				} else // Worse fitness.
				{
					// Decrease the search-range.
					r *= q;
				}
			} else // Worse feasibility.
			{
				// Decrease the search-range.
				r *= q;
			}

			// Trace fitness of best found solution.
			trace(i, fitness, feasible);
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(x, fitness, feasible, i);
	}
}
