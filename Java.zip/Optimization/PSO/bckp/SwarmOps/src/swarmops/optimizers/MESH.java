// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Optimizer that iterates over all possible combinations of parameters fitting
 * a mesh of a certain size. This is particularly useful for displaying
 * performance landscapes from meta-optimization, relating choices of control
 * parameters to the performance of the optimizer.
 */
public class MESH extends Optimizer {
	/**
	 * Construct the object.
	 */
	public MESH() {
		super();
		
		this.mask = null;
	}

	/**
	 * Construct the object.
	 * 
	 * @param mask
	 *            fix certain parameters or leave null.
	 * @param problem
	 *            problem to optimize.
	 */
	public MESH(Double[] mask, Problem problem) {
		super(problem);

		assert mask == null || mask.length == problem.getDimensionality();

		this.mask = (mask != null) ? (mask.clone()) : (null);
	}

	/** Fix some parameters to the given values. */
	private Double[] mask;

	/** Names of the control parameters. */
	private static final String[] parameterName = { "NumIterationsPerDim" };

	private static final double[] defaultParameters = { 8 };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 1 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 1000 };

	@Override
	public double[] getDefaultParameters() {
		return defaultParameters;
	}

	@Override
	public String getName() {
		return "MESH";
	}

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public int getDimensionality() {
		return 1;
	}

	/**
	 * Get control parameter, numIterationsPerDim.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static int getNumIterationsPerDim(double[] parameters) {
		return (int) Math.round(parameters[0]);
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameter specific to this optimizer.
		int numIterationsPerDim = getNumIterationsPerDim(parameters);

		assert numIterationsPerDim >= 1;

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		int n = problem.getDimensionality();

		// Allocate mesh position and mesh-incremental values.
		double[] x = new double[n]; // Mesh position.
		double[] delta = new double[n]; // Mesh incremental values.

		// Best found solution.
		Result g = new Result();
		g.parameters = new double[n];

		// Initialize mesh position to the lower boundary.
		Tools.copy(lowerBound, x);

		// Compute mesh incremental values for all dimensions.
		for (int i = 0; i < n; i++) {
			delta[i] = (upperBound[i] - lowerBound[i])
					/ (numIterationsPerDim - 1);
		}

		// Start recursive traversal of mesh.
		recursive(0, numIterationsPerDim, delta, x, g);

		// Signal end of optimization run.
		problem.endOptimizationRun();

		g.iterations = (int) Math.pow(numIterationsPerDim, n);

		// Return best-found solution and fitness.
		return g;
	}

	/**
	 * Helper function for recursive traversal of the mesh in a depth-first
	 * order.
	 * 
	 * @param curDim
	 *            current dimension being processed.
	 * @param numIterationsPerDim
	 *            number of mesh iterations per dimension.
	 * @param delta
	 *            distance between points in mesh.
	 * @param x
	 *            current mesh point.
	 * @param g
	 *            best found solution in mesh.
	 */
	private void recursive(int curDim, int numIterationsPerDim, double[] delta,
			double[] x, Result g) {
		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		int n = problem.getDimensionality();

		assert curDim >= 0 && curDim < n;

		// Should parameters be mesh-computed?
		if (mask == null || mask[curDim] == null) {
			// Iterate over all mesh-entries for current dimension.
			int i;
			for (i = 0; i < numIterationsPerDim; i++) {
				// Update mesh position for current dimension.
				x[curDim] = lowerBound[curDim] + delta[curDim] * i;

				// Bound mesh position for current dimension.
				x[curDim] = Tools.bound(x[curDim], lowerBound[curDim],
						upperBound[curDim]);

				// Do actual recursion or fitness evaluation.
				recursiveInner(curDim, numIterationsPerDim, delta, x, g);
			}
		} else {
			// Use fixed parameter instead of mesh-computed.
			x[curDim] = mask[curDim].doubleValue();

			// Do actual recursion or fitness evaluation.
			recursiveInner(curDim, numIterationsPerDim, delta, x, g);
		}
	}

	/**
	 * Helper function for recursive traversal of the mesh in a depth-first
	 * order.
	 * 
	 * @param curDim
	 *            current dimension being processed.
	 * @param numIterationsPerDim
	 *            number of mesh iterations per dimension.
	 * @param delta
	 *            distance between points in mesh.
	 * @param x
	 *            current mesh point.
	 * @param g
	 *            best found solution in mesh.
	 */
	private void recursiveInner(int curDim, int numIterationsPerDim,
			double[] delta, double[] x, Result g) {
		int n = problem.getDimensionality();

		assert curDim >= 0 && curDim < n;

		// Either recurse or compute fitness for mesh position.
		if (curDim < n - 1) {
			// Recurse for next dimension.
			recursive(curDim + 1, numIterationsPerDim, delta, x, g);
		} else {
			// Compute feasibility (constraint satisfaction).
			boolean feasible = problem.isFeasible(x);

			// Compute fitness for current mesh position.
			// This is done regardless of feasibility.
			double fitness = problem.fitness(x, feasible);

			// Update best position and fitness found in this run.
			if (Tools.isBetterFeasibleFitness(g.feasible, feasible, g.fitness,
					fitness)) {
				// Update this run's best known position.
				Tools.copy(x, g.parameters);

				// Update this run's best know fitness.
				g.fitness = fitness;

				// Update best known feasibility.
				g.feasible = feasible;
			}
		}
	}
}
