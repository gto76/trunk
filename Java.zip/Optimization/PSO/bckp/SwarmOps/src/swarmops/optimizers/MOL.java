// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.optimizers;

import swarmops.Globals;
import swarmops.Optimizer;
import swarmops.Problem;
import swarmops.Result;
import swarmops.Tools;

/**
 * Many Optimizing Liaisons (MOL) optimization method devised as a
 * simplification to the PSO method originally due to Eberhart et al. (1, 2).
 * The MOL method does not have any attraction to the particle's own best known
 * position, and the algorithm also makes use of random selection of which
 * particle to update instead of iterating over the entire swarm. It is similar
 * to the "Social Only" PSO suggested by Kennedy (3), and was studied more
 * thoroguhly by Pedersen et al. (4) who found it to sometimes outperform PSO,
 * and have more easily tunable control parameters.
 * 
 * References:
 * 
 * (1) J. Kennedy and R. Eberhart. Particle swarm optimization. In Proceedings
 * of IEEE International Conference on Neural Networks, volume IV, pages
 * 1942-1948, Perth, Australia, 1995
 * 
 * (2) Y. Shi and R.C. Eberhart. A modified particle swarm optimizer. In
 * Proceedings of the IEEE International Conference on Evolutionary Computation,
 * pages 69-73, Anchorage, AK, USA, 1998.
 * 
 * (3) J. Kennedy. The particle swarm: social adaptation of knowledge, In:
 * Proceedings of the IEEE International Conference on Evolutionary Computation,
 * Indianapolis, USA, 1997.
 * 
 * (4) M.E.H. Pedersen and A.J. Chipperfield. Simplifying particle swarm
 * optimization. Applied Soft Computing, 10, p. 618-628, 2010.
 */
public class MOL extends Optimizer {
	/**
	 * Construct the object.
	 */
	public MOL() {
		super();
	}

	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            problem to optimize.
	 */
	public MOL(Problem problem) {
		super(problem);
	}

	/** Names of the control parameters. */
	private static final String[] parameterName = { "S", "Omega", "Phi" };

	/** Lower boundary for the control parameters. */
	private static final double[] lowerBound = { 1.0, -2.0, -4.0 };

	/** Upper boundary for the control parameters. */
	private static final double[] upperBound = { 300.0, 2.0, 6.0 };

	@Override
	public double[] getDefaultParameters() {
		return Parameters.allBenchmarks30Dim60000Iter;
	}

	@Override
	public String getName() {
		return "MOL";
	}

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public int getDimensionality() {
		return 3;
	}

	/**
	 * Get control parameter, number of agents aka. swarm-size.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public static int getNumAgents(double[] parameters) {
		return (int) Math.round(parameters[0]);
	}

	/**
	 * Get control parameter omega.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getOmega(double[] parameters) {
		return parameters[1];
	}

	/**
	 * Get control parameter phi.
	 * 
	 * @param parameters
	 *            parameters passed to optimizer.
	 */
	public double getPhi(double[] parameters) {
		return parameters[2];
	}

	@Override
	public Result optimize(double[] parameters) {
		assert parameters != null && parameters.length == getDimensionality();

		// Signal beginning of optimization run.
		problem.beginOptimizationRun();

		// Retrieve parameter specific to this optimizer.
		int numAgents = getNumAgents(parameters);
		double omega = getOmega(parameters);
		double phi = getPhi(parameters);

		// Get problem-context.
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();
		double[] lowerInit = problem.getLowerInit();
		double[] upperInit = problem.getUpperInit();
		int n = problem.getDimensionality();

		// Allocate agent positions and velocities.
		double[][] agents = new double[numAgents][n];
		double[][] velocities = new double[numAgents][n];

		// Allocate velocity boundaries.
		double[] velocityLowerBound = new double[n];
		double[] velocityUpperBound = new double[n];

		// Best-found position, fitness and constraint feasibility.
		double[] g = new double[n];
		double gFitness = problem.getMaxFitness();
		boolean gFeasible = false;

		// Iteration variables.
		int i, j, k;

		// Initialize velocity boundaries.
		for (k = 0; k < n; k++) {
			double range = Math.abs(upperBound[k] - lowerBound[k]);

			velocityLowerBound[k] = -range;
			velocityUpperBound[k] = range;
		}

		// Initialize all agents.
		// This counts as iterations below.
		for (j = 0; j < numAgents
				&& problem.continueOptimization(j, gFitness, gFeasible); j++) {
			// Refer to the j'th agent as x and v.
			double[] x = agents[j];
			double[] v = velocities[j];

			// Initialize agent-position in search-space.
			Tools.initializeUniform(x, lowerInit, upperInit);

			// Initialize velocity.
			Tools.initializeUniform(v, velocityLowerBound, velocityUpperBound);

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(x);

			// Compute fitness if feasibility (constraint satisfaction) is same
			// or better.
			if (Tools.isBetterFeasible(gFeasible, newFeasible)) {
				// Compute fitness of initial position.
				double newFitness = problem.fitness(x, gFitness, gFeasible,
						newFeasible);

				// Update swarm's best known position, if improvement.
				if (Tools.isBetterFeasibleFitness(gFeasible, newFeasible,
						gFitness, newFitness)) {
					Tools.copy(x, g);
					gFitness = newFitness;
					gFeasible = newFeasible;
				}
			}

			// Trace fitness of best found solution.
			trace(j, gFitness, gFeasible);
		}

		// Perform actual optimization iterations.
		for (i = numAgents; problem
				.continueOptimization(i, gFitness, gFeasible); i++) {
			assert numAgents > 0;

			// Pick random agent.
			j = Globals.random.nextIndex(numAgents);

			// Refer to the j'th agent as x and v.
			double[] x = agents[j];
			double[] v = velocities[j];

			// Pick random weight.
			double r = Globals.random.nextUniform();

			// Update velocity.
			for (k = 0; k < n; k++) {
				v[k] = omega * v[k] + phi * r * (g[k] - x[k]);
			}

			// Enforce velocity bounds before updating position.
			Tools.bound(v, velocityLowerBound, velocityUpperBound);

			// Update position.
			for (k = 0; k < n; k++) {
				x[k] = x[k] + v[k];
			}

			// Enforce constraints and evaluate feasibility.
			boolean newFeasible = problem.enforceConstraints(x);

			// Compute fitness if feasibility (constraint satisfaction) is same
			// or better.
			if (Tools.isBetterFeasible(gFeasible, newFeasible)) {
				// Compute new fitness.
				double newFitness = problem.fitness(x, gFitness, gFeasible,
						newFeasible);

				// Update swarm's best known position, if improvement.
				if (Tools.isBetterFeasibleFitness(gFeasible, newFeasible,
						gFitness, newFitness)) {
					Tools.copy(x, g);
					gFitness = newFitness;
					gFeasible = newFeasible;
				}
			}

			// Trace fitness of best found solution.
			trace(i, gFitness, gFeasible);
		}

		// Signal end of optimization run.
		problem.endOptimizationRun();

		// Return best-found solution and fitness.
		return new Result(g, gFitness, gFeasible, i);
	}

	/**
	 * Control parameters tuned for various optimization scenarios.
	 */
	public static class Parameters {
		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 400 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim400IterA = { 23.0,
				-0.3328, 2.8446 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 400 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim400IterB = { 50.0, 0.284,
				1.9466 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 4000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim4000IterA = { 183.0,
				-0.2797, 3.0539 };

		/**
		 * Control parameters tuned for all benchmark problems in 2 dimensions
		 * and 4000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks2Dim4000IterB = { 139.0,
				0.6372, 1.0949 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 1000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim1000Iter = { 50.0,
				-0.3085, 2.0273 };

		/**
		 * Control parameters tuned for all benchmark problems in 5 dimensions
		 * and 10000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks5Dim10000Iter = { 96.0,
				-0.3675, 4.171 };

		/**
		 * Control parameters tuned for all benchmark problems in 10 dimensions
		 * and 2000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks10Dim2000Iter = { 60.0,
				-0.27, 2.9708 };

		/**
		 * Control parameters tuned for all benchmark problems in 10 dimensions
		 * and 20000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks10Dim20000Iter = { 116.0,
				-0.3518, 3.8304 };

		/**
		 * Control parameters tuned for all benchmark problems in 20 dimensions
		 * and 40000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks20Dim40000Iter = { 228.0,
				-0.3747, 4.2373 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks20Dim400000IterA = { 125.0,
				-0.2575, 4.6713 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 20 dimensions and 400000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks20Dim400000IterB = { 67.0,
				-0.4882, 2.7923 };

		/**
		 * Control parameters tuned for all benchmark problems in 50 dimensions
		 * and 100000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks50Dim100000Iter = { 290.0,
				-0.3067, 3.6223 };

		/**
		 * Control parameters tuned for Ackley, Rastrigin, Rosenbrock, and
		 * Schwefel1-2 in 100 dimensions and 200000 fitness evaluations in one
		 * optimization run.
		 */
		public static final double[] fourBenchmarks100Dim200000Iter = { 219.0,
				-0.1685, 3.9162 };

		/**
		 * Control parameters tuned for all benchmark problems in 30 dimensions
		 * and 60000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks30Dim60000Iter = { 198.0,
				-0.2723, 3.8283 };

		/**
		 * Control parameters tuned for all benchmark problems in 30 dimensions
		 * and 600000 fitness evaluations in one optimization run.
		 */
		public static final double[] allBenchmarks30Dim600000Iter = { 134.0,
				-0.43, 3.0469 };

		/**
		 * Control parameters tuned for Rastrigin in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] rastrigin_30Dim60000Iter = { 114.0,
				-0.3606, 3.822 };

		/**
		 * Control parameters tuned for Schwefel1-2 in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] schwefel12_30Dim60000Iter1 = { 130.0,
				-0.2765, 3.8011 };

		/**
		 * Control parameters tuned for Schwefel1-2 in 30 dimensions and 60000
		 * fitness evaluations in one optimization run.
		 */
		public static final double[] schwefel12_30Dim60000Iter2 = { 138.0,
				-0.4774, 2.3943 };

		/**
		 * Control parameters tuned for Sphere and Rosenbrock problems in 30
		 * dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] sphereRosenbrock_30Dim60000Iter = { 42.0,
				-0.4055, 3.1722 };

		/**
		 * Control parameters tuned for Rastrigin and Schwefel1-2 problems in 30
		 * dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] rastriginSchwefel12_30Dim60000Iter = {
				47.0, -0.3, 3.5582 };

		/**
		 * Control parameters tuned for Rastrigin and Schwefel1-2 problems in 30
		 * dimensions each and 600000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] rastriginSchwefel12_30Dim600000Iter1 = {
				130, -0.4135, 3.1937 };

		/**
		 * Control parameters tuned for Rastrigin and Schwefel1-2 problems in 30
		 * dimensions each and 600000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] rastriginSchwefel12_30Dim600000Iter2 = {
				72.0, -0.6076, 1.9609 };

		/**
		 * Control parameters tuned for QuarticNoise, Sphere, Step problems in
		 * 30 dimensions each and 60000 fitness evaluations in one optimization
		 * run.
		 */
		public static final double[] quarticNoiseSphereStep_30Dim60000Iter = {
				83.0, -0.3461, 3.2535 };
	}

	/**
	@Override
	public boolean isFeasible(double[] parameters) {
		int numAgents = getNumAgents(parameters);
		double omega = getOmega(parameters);
		double phi = getPhi(parameters);

		// Example of constraints on an optimizer's control optimizers.
		// These particular constraints are only for demonstration purposes.
		return (numAgents >= 1) && (omega > 0 || omega < -0.5)
				&& (omega * phi < 0) && (omega + phi < 2);
	}
	*/
}
