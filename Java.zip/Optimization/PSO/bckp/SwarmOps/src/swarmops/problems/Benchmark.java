// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

import swarmops.Problem;

/** Base-class for benchmark problems. */
public abstract class Benchmark extends Problem {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * @param lowerBound
	 *            lower search-space boundary.
	 * @param upperBound
	 *            upper search-space boundary.
	 * @param lowerInit
	 *            lower initialization boundary.
	 * @param upperInit
	 *            upper initialization boundary.
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Benchmark(int dimensionality, double lowerBound, double upperBound,
			double lowerInit, double upperInit, int maxIterations) {
		super(maxIterations);

		assert dimensionality >= 1;

		this.dimensionality = dimensionality;

		this.lowerBound = new double[dimensionality];
		this.upperBound = new double[dimensionality];

		this.lowerInit = new double[dimensionality];
		this.upperInit = new double[dimensionality];

		for (int i = 0; i < dimensionality; i++) {
			this.lowerBound[i] = lowerBound;
			this.upperBound[i] = upperBound;

			this.lowerInit[i] = lowerInit;
			this.upperInit[i] = upperInit;
		}
	}

	private final int dimensionality;
	private final double[] lowerBound;
	private final double[] upperBound;
	private final double[] lowerInit;
	private final double[] upperInit;

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public double[] getLowerInit() {
		return lowerInit;
	}

	@Override
	public double[] getUpperInit() {
		return upperInit;
	}

	@Override
	public int getDimensionality() {
		return dimensionality;
	}
}
