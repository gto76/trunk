// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

import swarmops.Globals;
import swarmops.Problem;
import swarmops.ProblemWrapper;

/**
 * Search-space mangler, used to increase the difficulty of optimizing benchmark
 * problems and avoid correlation with global optima such as zero. Note that
 * this works with parallel optimizers but not with parallel meta-optimization
 * because of the way MetaFitness is implemented.
 */
public class Mangler extends ProblemWrapper {
	/**
	 * Construct the object.
	 * 
	 * @param problem
	 *            the problem being wrapped.
	 * @param diffusion
	 *            diffusion factor, larger than 0, e.g. 0.01
	 * @param displacement
	 *            displacement factor, larger than 0, e.g. 0.1
	 * @param spillover
	 *            fitnessNoise factor, lager than 0, e.g. 0.01
	 * @param fitnessNoise
	 *            spillover factor, larger than 0, e.g. 0.05
	 */
	public Mangler(Problem problem, double diffusion, double displacement,
			double spillover, double fitnessNoise) {
		super(problem);
		// Assign to fields.
		this.diffusion = diffusion;
		this.displacement = displacement;
		this.spillover = spillover;
		this.fitnessNoise = fitnessNoise;

		// Allocate transformation matrix and array.
		int n = problem.getDimensionality();
		A = new double[n][n];
		b = new double[n];
	}

	/**
	 * Diffusion factor.
	 */
	private double diffusion;

	/**
	 * Displacement factor.
	 */
	private double displacement;

	/**
	 * Spillover factor.
	 */
	private double spillover;

	/**
	 * FitnessNoise factor.
	 */
	private double fitnessNoise;

	/**
	 * Matrix used for transforming input position: y = A * x + b
	 */
	double[][] A;

	/**
	 * Array used for transforming input position: y = A * x + b
	 */
	double[] b;

	@Override
	public double fitness(double[] parameters, double fitnessLimit,
			boolean oldFeasible, boolean newFeasible) {
		// Notational convenience.
		int n = problem.getDimensionality();
		double[] x = parameters;

		assert n == x.length;

		// Iterator variables.
		int i, j;

		// Allocate output array. This is thread-safe and fast enough.
		double[] y = new double[n];

		// Matrix transformation y = A * x + b
		for (i = 0; i < n; i++) {
			y[i] = b[i];

			for (j = 0; j < n; j++) {
				y[i] += A[i][j] * x[j];
			}
		}

		// Diffusion.
		for (i = 0; i < n; i++) {
			y[i] += Globals.random.nextGaussian(0, diffusion);
		}

		// Compute fitness.
		double fitness = problem.fitness(y, fitnessLimit, oldFeasible,
				newFeasible);

		// Fitness noise.
		double noise = Math.abs(Globals.random.nextGaussian()) * fitnessNoise + 1;
		fitness *= noise;

		// Compute and return fitness of displaced parameters.
		return fitness;
	}

	@Override
	public boolean hasGradient() {
		return false;
	}

	@Override
	public int gradient(double[] x, double[] v) {
		throw new java.lang.UnsupportedOperationException();
	}

	@Override
	public void beginOptimizationRun() {
		// Notational convenience.
		int n = problem.getDimensionality();
		double[] lowerBound = problem.getLowerBound();
		double[] upperBound = problem.getUpperBound();

		// Iterator variables.
		int i, j;

		// Initialize transformation matrix.
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				// The diagonal of the transformation matrix is one, the
				// remainder
				// is chosen randomly.
				A[i][j] = (i == j) ? (1) : (Globals.random.nextGaussian(0, spillover));
			}
		}

		// Initialize displacement array.
		for (i = 0; i < n; i++) {
			double range = upperBound[i] - lowerBound[i];
			double d = displacement * Globals.random.nextUniform(-range, range);
			b[i] = d;
		}

		// Call through problem-chain.
		problem.beginOptimizationRun();
	}
}
