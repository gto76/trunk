// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Penalized2 benchmark problem. */
public class Penalized2 extends Penalized {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Penalized2(int dimensionality, int maxIterations) {
		super(dimensionality, -50, 50, -5, 50, maxIterations);
	}

	@Override
	public String getName() {
		return "Penalized2";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double fitness(double[] x) {
		int n = getDimensionality();

		assert x != null && x.length == n;

		// Compute main fitness value ...
		double value = getSinX(x[0], 3.0);

		int i;
		for (i = 0; i < n - 1; i++) {
			double elm = x[i];
			double elmMinusOne = elm - 1;
			double elmSin = getSinX(x[i + 1], 3.0);

			value += (elmMinusOne * elmMinusOne) * (1 + elmSin);
		}

		// Add last term.
		{
			double elm = x[n - 1];
			double elmMinusOne = elm - 1;
			double elmSin = getSinX(elm, 2.0);

			value += elmMinusOne * elmMinusOne * (1 + elmSin);
		}

		// Compute penalty.
		double penalty = 0;

		for (i = 0; i < n; i++) {
			double elm = x[i];

			penalty += u(elm, 5.0, 100.0, 4.0);
		}

		return 0.1 * value + penalty;
	}

	/**
	 * Helper-method used in the fitness-method.
	 */
	protected double getSinX(double x, double factor) {
		double elmSin = Math.sin(factor * Math.PI * x);

		return elmSin * elmSin;
	}
}
