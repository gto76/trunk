// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

package swarmops.problems;

/** The Rosenbrock benchmark problem. */
public class Rosenbrock extends Benchmark {
	/**
	 * Construct the object.
	 * 
	 * @param dimensionality
	 *            dimensionality of the search-space.
	 * 
	 * @param maxIterations
	 *            maximum number of iterations (i.e. fitness evaluations) to
	 *            perform.
	 */
	public Rosenbrock(int dimensionality, int maxIterations) {
		super(dimensionality, -100, 100, 15, 30, maxIterations);
	}

	@Override
	public String getName() {
		return "Rosenbrock";
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double fitness(double[] x) {
		int n = getDimensionality();

		assert x != null && x.length == n;

		double value = 0;

		for (int i = 0; i < n - 1; i++) {
			double elm = x[i];
			double nextElm = x[i + 1];

			double minusOne = elm - 1;
			double nextMinusSqr = nextElm - elm * elm;

			value += 100 * nextMinusSqr * nextMinusSqr + minusOne * minusOne;
		}

		return value;
	}

	@Override
	public boolean hasGradient() {
		return true;
	}

	@Override
	public int gradient(double[] x, double[] v) {
		int n = getDimensionality();

		assert x != null && x.length == n;
		assert v != null && v.length == n;

		for (int i = 0; i < n - 1; i++) {
			double elm = x[i];
			double nextElm = x[i + 1];

			v[i] = -400 * (nextElm - elm * elm) * elm + 2 * (elm - 1);
		}

		// Gradient for the last dimension.
		{
			double elm = x[n - 1];
			double prevElm = x[n - 2];

			v[n - 1] = 200 * (elm - prevElm * prevElm);
		}

		return 0;
	}
}
