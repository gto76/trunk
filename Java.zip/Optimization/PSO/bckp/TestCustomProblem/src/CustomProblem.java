// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

import swarmops.Problem;
import swarmops.Tools;

/**
 * Constrained optimization problem, example. This is the 2-dimensional
 * Rosenbrock problem with some example constraints. The optimal feasible
 * solution seems to be: a ~ 1.5937, b ~ 2.5416
 */
public class CustomProblem extends Problem {
	/**
	 * Construct the object.
	 */
	public CustomProblem() {
		super();
	}

	/**
	 * Get parameter A.
	 */
	public double getA(double[] parameters) {
		return parameters[0];
	}

	/**
	 * Get parameter B.
	 */
	public double getB(double[] parameters) {
		return parameters[1];
	}

	@Override
	public String getName() {
		return "CustomProblem";
	}

	@Override
	public int getDimensionality() {
		return 2;
	}

	private static final double[] lowerBound = { -100, -100 };

	@Override
	public double[] getLowerBound() {
		return lowerBound;
	}

	private static final double[] upperBound = { 100, 100 };

	@Override
	public double[] getUpperBound() {
		return upperBound;
	}

	@Override
	public double[] getLowerInit() {
		return getLowerBound();
	}

	@Override
	public double[] getUpperInit() {
		return getUpperBound();
	}

	@Override
	public double getMinFitness() {
		return 0;
	}

	@Override
	public double getAcceptableFitness() {
		return 0.4;
	}

	String[] parameterName = { "a", "b" };

	@Override
	public String[] getParameterName() {
		return parameterName;
	}

	@Override
	public double fitness(double[] x) {
		assert x != null && x.length == getDimensionality();

		double a = getA(x);
		double b = getB(x);
		double t1 = 1 - a;
		double t2 = b - a * a;

		return t1 * t1 + 100 * t2 * t2;
	}

	@Override
	public boolean enforceConstraints(double[] x) {
		// Enforce boundaries.
		Tools.bound(x, getLowerBound(), getUpperBound());

		// Return feasibility.
		return isFeasible(x);
	}

	@Override
	public boolean isFeasible(double[] x) {
		assert x != null && x.length == getDimensionality();

		double a = getA(x);
		double b = getB(x);

		// Radius.
		double r = Math.sqrt(a * a + b * b);

		return ((r < 0.7) || ((r > 3) && (r < 5))) && (a < b * b);
	}
}
