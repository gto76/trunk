// ------------------------------------------------------
// SwarmOps - Numeric and heuristic optimization for Java
// Copyright (C) 2003-2011 Magnus Erik Hvass Pedersen.
// Please see the file license.txt for license details.
// SwarmOps on the internet: http://www.Hvass-Labs.org/
// ------------------------------------------------------

import java.io.IOException;
import swarmops.*;
import swarmops.optimizers.*;
import swarmops.problems.*;

/**
 * Test meta-optimization, that is, tuning of control parameters for an
 * optimizer by applying an additional layer of optimization. See
 * TestParallelMetaBenchmarks for the parallel version of this.
 */
public class Program {
	// Settings for the optimization layer.
	static final int numRuns = 50;
	static final int dim = 5;
	static final int dimFactor = 2000;
	static final int numIterations = dimFactor * dim;

	// Mangle search-space.
	static final boolean UseMangler = false;
	static final double Spillover = 0.05; // E.g. 0.05
	static final double Displacement = 0.1; // E.g. 0.1
	static final double Diffusion = 0.01; // E.g. 0.01
	static final double FitnessNoise = 0.01; // E.g. 0.01

	// Wrap problem-object in search-space mangler.
	static Problem Mangle(Problem problem) {
		return (UseMangler) ? (new Mangler(problem, Diffusion, Displacement,
				Spillover, FitnessNoise)) : (problem);
	}

	// The optimizer whose control parameters are to be tuned.
	static Optimizer optimizer = new MOL();
//	static Optimizer optimizer = new DESuite(DECrossover.Variant.Rand1Bin, DESuite.DitherVariant.Element);

	// Problems to optimize. That is, the optimizer is having its control
	// parameters tuned to work well on these problems. The numbers are weights
	// that signify mutual importance of the problems in tuning. Higher weight
	// means more importance.
	static WeightedProblem[] weightedProblems = new WeightedProblem[] {
			new WeightedProblem(1.0, Mangle(new Ackley(dim, numIterations))),
			new WeightedProblem(1.0, Mangle(new Griewank(dim, numIterations))),
			// new WeightedProblem(1.0, Mangle(new Penalized1(dim,
			// numIterations))),
			// new WeightedProblem(1.0, Mangle(new Penalized2(dim,
			// numIterations))),
			// new WeightedProblem(1.0, Mangle(new QuarticNoise(dim,
			// numIterations))),
			// new WeightedProblem(1.0, Mangle(new Rastrigin(dim,
			// numIterations))),
			new WeightedProblem(1.0, Mangle(new Rosenbrock(dim, numIterations))),
			new WeightedProblem(1.0, Mangle(new Schwefel12(dim, numIterations))),
			// new WeightedProblem(1.0, Mangle(new Schwefel221(dim,
			// numIterations))),
			// new WeightedProblem(1.0, Mangle(new Schwefel222(dim,
			// numIterations))),
			// new WeightedProblem(1.0, Mangle(new Sphere(dim, numIterations))),
			new WeightedProblem(1.0, Mangle(new Step(dim, numIterations))), };

	// Settings for the meta-optimization layer.
	static final int metaNumRuns = 5;
	static final int metaDim = optimizer.getDimensionality();
	static final int metaDimFactor = 20;
	static final int metaNumIterations = metaDimFactor * metaDim;

	// The meta-fitness consists of computing optimization performance
	// for the problems listed above over several optimization runs and
	// sum the results, so we wrap the Optimizer-object in a
	// MetaFitness-object which takes of this.
	static MetaFitness metaFitness = new MetaFitness(optimizer,
			weightedProblems, numRuns, metaNumIterations);

	// Print meta-optimization progress.
	static FitnessPrint metaFitnessPrint = new FitnessPrint(metaFitness);

	// Log all candidate solutions.
	static int logCapacity = 20;
	static boolean logOnlyFeasible = false;
	static LogSolutions logSolutions = new LogSolutions(metaFitnessPrint,
			logCapacity, logOnlyFeasible);

	// The meta-optimizer.
	static Optimizer metaOptimizer = new LUS(logSolutions);

	// Control parameters to use for the meta-optimizer.
	static double[] metaParameters = metaOptimizer.getDefaultParameters();

	// If using DE as meta-optimizer, use these control parameters.
	// static double[] MetaParameters = DE.Parameters.forMetaOptimization;

	// Wrap the meta-optimizer in a Statistics object for logging results.
	static final boolean statisticsOnlyFeasible = true;
	static Statistics statistics = new Statistics(metaOptimizer,
			statisticsOnlyFeasible);

	// Repeat a number of meta-optimization runs.
	static Repeat metaRepeat = new RepeatMin(statistics, metaNumRuns);

	public static void main(String[] args) throws IOException {
		// Initialize the PRNG.
		Globals.random = new swarmops.random.MersenneTwister();

		// Create a fitness trace for tracing the progress of
		// meta-optimization.
		int maxMeanIntervals = 3000;
		FitnessTrace fitnessTrace = new FitnessTraceMean(metaNumIterations,
				maxMeanIntervals);
		FeasibleTrace feasibleTrace = new FeasibleTrace(metaNumIterations,
				maxMeanIntervals, fitnessTrace);

		// Assign the fitness trace to the meta-optimizer.
		metaOptimizer.fitnessTrace = feasibleTrace;

		// Output settings.
		System.out.printf("Meta-Optimization of benchmark problems.\n");
		System.out.printf("\n");
		System.out.printf("Meta-method: %s\n", metaOptimizer.getName());
		System.out.printf("Using following parameters:\n");
		Tools.printParameters(metaOptimizer, metaParameters);
		System.out.printf("Number of meta-runs: %d\n", metaNumRuns);
		System.out.printf("Number of meta-iterations: %d\n", metaNumIterations);
		System.out.printf("\n");
		System.out.printf("Method to be meta-optimized: %s\n",
				optimizer.getName());
		System.out.printf("Number of benchmark problems: %d\n",
				weightedProblems.length);

		for (int i = 0; i < weightedProblems.length; i++) {
			Problem problem = weightedProblems[i].problem;
			double weight = weightedProblems[i].weight;

			System.out.printf("\t(%f)\t%s\n", weight, problem.getName());
		}

		System.out.printf("Dimensionality for each benchmark problem: %d\n",
				dim);
		System.out
				.printf("Number of runs per benchmark problem: %d\n", numRuns);
		System.out.printf("Number of iterations per run: %d\n", numIterations);
		if (UseMangler) {
			System.out.printf("Mangle search-space:\n");
			System.out.printf("\tSpillover:     %f\n", Spillover);
			System.out.printf("\tDisplacement:  %f\n", Displacement);
			System.out.printf("\tDiffusion:     %f\n", Diffusion);
			System.out.printf("\tFitnessNoise:  %f\n", FitnessNoise);
		} else {
			System.out.printf("Mangle search-space: No\n");
		}
		System.out.printf("\n");

		System.out
				.printf("0/1 boolean whether optimizer's control parameters are feasible.\n");
		System.out
				.printf("*** Indicates meta-fitness/feasibility is an improvement.\n");

		// Start-time.
		long t1 = System.currentTimeMillis();

		// Perform the meta-optimization runs.
		metaRepeat.fitness(metaParameters);

		// End-time.
		long t2 = System.currentTimeMillis();

		// Compute result-statistics.
		statistics.compute();

		// Retrieve best-found control parameters for the optimizer.
		double[] bestParameters = statistics.bestResult.parameters;

		// Output results and statistics.
		System.out.printf("\n");
		System.out.printf("Best found parameters for %s optimizer:\n",
				optimizer.getName());
		Tools.printParameters(optimizer, bestParameters);
		System.out.printf("Parameters written in array notation:\n\t%s\n",
				Tools.arrayToString(bestParameters));
		System.out.printf("Best parameters have meta-fitness: %s\n",
				Tools.formatNumber(statistics.fitnessStatistics.getMin()));
		System.out.printf("Worst meta-fitness: %s\n",
				Tools.formatNumber(statistics.fitnessStatistics.getMax()));
		System.out.printf("Mean meta-fitness: %s\n",
				Tools.formatNumber(statistics.fitnessStatistics.getMean()));
		System.out.printf("StdDev for meta-fitness: %s\n", Tools
				.formatNumber(statistics.fitnessStatistics
						.getStandardDeviation()));

		// Output best found parameters.
		System.out.printf("\n");
		System.out.printf("Best %d found parameters:\n", logSolutions.capacity);
		for (int i = 0; i < logSolutions.log.size(); i++) {
			Solution candidateSolution = logSolutions.log.get(i);
			System.out.printf("\t%s\t%s\t%d\n",
					Tools.arrayToStringRaw(candidateSolution.parameters),
					Tools.formatNumber(candidateSolution.fitness),
					(candidateSolution.feasible) ? (1) : (0));
		}

		// Output time-usage.
		System.out.printf("\n");
		System.out.printf("Time usage: %.2f seconds\n",
				(double) (t2 - t1) / 1000);

		// Output fitness trace.
		String traceFilename = metaOptimizer.getName() + "-"
				+ optimizer.getName() + "-" + weightedProblems.length + "Bnch"
				+ "-" + dimFactor + "xDim.txt";
		fitnessTrace.writeToFile("MetaFitnessTrace-" + traceFilename);
		feasibleTrace.writeToFile("MetaFeasibleTrace-" + traceFilename);
	}
}
