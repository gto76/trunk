import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.*;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import java.util.Arrays;




class ParseFile {


	static int stLjudi;
	static int[] mizeTemp;
	static int[] mize;
	static int im = 0;
	static int[][] s;
	static int is = 0;

	public static void parse(String fileName) {

	    //File file = new File("C:\\MyFile.txt");
	    File file = new File(fileName);
	    FileInputStream fis = null;
	    BufferedInputStream bis = null;
	    DataInputStream dis = null;
	    String line;



		//s = new int[2000][2];
		mizeTemp = new int[100];

	    try {
		      fis = new FileInputStream(file);

		      // Here BufferedInputStream is added for fast reading.
		      bis = new BufferedInputStream(fis);
		      dis = new DataInputStream(bis);

		      // dis.available() returns 0 if the file does not have more lines.


		      // prebere st ljudi
		      if (dis.available() != 0) {
		      		line = dis.readLine();
		      		try {
		      			stLjudi = Integer.valueOf( line ).intValue();
		      			//System.out.println(stLjudi);
		      		}
		      		catch (NumberFormatException e) {
	      				e.printStackTrace();
	    			}

		      }


			s = new int[stLjudi+1][stLjudi+1];

			for ( int i = 1; i <= stLjudi; i++) {
				for ( int j = 1; j <= stLjudi; j++) {
					s[i][j] = 0;
				}
			}


		      // prebere mize
		      if (dis.available() != 0) {

		      		line = dis.readLine();
		        	StringTokenizer st = new StringTokenizer(line);
		      		try {
	     				while (st.hasMoreTokens()) {
	         				mizeTemp[im++] = Integer.valueOf( st.nextToken() ).intValue();
	         				//System.out.print(mize[im-1] + " ");
	     				}
					}
		      		catch (NumberFormatException e) {
	      				e.printStackTrace();
	    			}
		        	catch (NoSuchElementException e) {
	    				e.printStackTrace();
	    			}
	    			//System.out.println();

		      }

		      mize = new int[im];
		      mize = Arrays.copyOf(mizeTemp, im);

		      // prebere sovrastva
		      while (dis.available() != 0) {

		      		line = dis.readLine();
		      		StringTokenizer st = new StringTokenizer(line);
		      		try {
	     				s[Integer.valueOf( st.nextToken() ).intValue() - 1]
	     				 [Integer.valueOf( st.nextToken() ).intValue() - 1] = 1;
	     				//System.out.print(s[is-1][0] + " ");
	     				//System.out.println(s[is-1][1]);
					}
		      		catch (NumberFormatException e) {
	      				e.printStackTrace();
	    			}

		      }

		      // dispose all the resources after using them.
		      fis.close();
		      bis.close();
		      dis.close();

	    } catch (FileNotFoundException e) {
	      	e.printStackTrace();
	    } catch (IOException e) {
	      	e.printStackTrace();
	    }
  	}



}