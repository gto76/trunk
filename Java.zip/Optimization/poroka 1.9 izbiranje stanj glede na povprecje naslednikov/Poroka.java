import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Arrays;



class Poroka {

	static int[] miza; //array miz (za kolioko ljudi ima vsaka prostora)
	static int ljudi; // st. ljudi
	static int s[][]; // matrika sovraztev
	static int[] ljudje; // {0 - ljudi}


	static int[][] m; //tabela moznih razporeditev stevila ljudi za mize
	static int im; //iterator ki pove koliko moznih razporeditev je ze shranjenih

    static double[][] tabelaRazdalj;

    static int minKazTock; // najmanj kazenskih tock v iteraciji ?
    static int[][] minKazTockKomb; // kombinacija z najmanj kazenskimi tockami v iteraciji ?

    static int minKazTockSKUPI; // najmanj kazenskih tock dozdej
    static int[][] minKazTockKombSKUPI; // kombinacija z najmanj kazenskimi tockami dozdej


	static 	int pmax=100;  //maks stevilo ljudi
	//static 	int nmax = 1000; // maks stevilo dimenzij

	static int[] kolkJeKdoZatezen = new int[pmax];
	static int najvecjiZatezenec;

	static int casIskanjaLokMin;
	static int najdiLokalniMinRekurzivnihKlicev;
	static int najdiLokalniMinKlicev;
	
	static int stevecPoskusov = 0;



	/************** PARAMETRI *****************/
	
	
	static boolean ANIMATE = false;

	static boolean SEARCH_ONLY_MOST_PROMISSING = false; //preisce vse resitve ce je true
	static double KONSTANTA_ZA_HATE_FAKTOR = 2.25;

	static int n = 8; 	// stevilo dimenzij //prej 9

	/*********************************************/
	
	static final int izvajalniCasSekund = 60;   		 //programa //1000 = 15 min

	static final double HITROST = 0.1 ; // hitrost premika (manjsa vrednost je hitrej) 
									//0.00001 10000 je jar lepo pocasi, ce je ena skacejo, 10 ne vec
									//0.1 je najhitrejsa mozna hitrost, vse manjse vrednosti so enako hitre

	/*********************************************/
	//TODO
	static int noOfFirstIter = 2; // stevilo iteracij ob prvem ciklu //4 //2
	static int noOfIterGeneral = noOfFirstIter; // stevilo premikov v enem iskanju (ostali cikli) // 590 //bilo je 20, 10, 2	// za sterko je blo dobr 200, 1
	
	static double bezanjeOdSov = 1; // bezanje od sovraznika, kolicnik (proti prijatelju je vedno 1.0) //1.0
	static double bezanjeOdDvSov = 2; // bezanje od dvojnega sovraznika //2.0
	static double pogojZaUstavitev = 0.00001;

	static boolean law = false; //Hovinga
	static boolean ISCI_LOKALNI_MIN = true;
	
	
	//static double robPreskoka = 1; // vec od 1 -> hitrej preskoci na levega// TREE NODE //1.5
	static double randomFaktor = 0.1; // s tem se pomno�i (random()-0.5), ki se pri�teje to�kam ob novih iteracijah
										//0.15 //0.2
	
	//static final int ST_ITERACIJ_ZA_PREGLED = 20;
	static final double ROB_ZA_ISKANJE_NAJBOLJSEGA_NODA = 0.9;
	
	/************** PARAMETRI *****************/

	
	

	static int stVelikihIteracij;

	static int p;		// stevilo ljudi

	static 	double pi=Math.PI;
	static 	double[][] po = new double[n][pmax];
	static 	double[][] pn = new double[n][pmax];
	static 	double[][] koordinate = new double[n][pmax];
	
	
	static 	double[][] ro = new double[pmax][pmax];
	static 	double[][] rn = new double[pmax][pmax];
	static  double	d;
	static  double	oldd=0;
	static  double	oldd1=1;
	static 	double	r = 0;
	static 	double	r1 = 0;
	static 	double	r2 = 0;
	static  int[][]	pnt = new int[pmax][pmax];
	static  int	pnt1;

	static int[][] enemie = new int[pmax][pmax]; // tabela sovrastev: 0 - friend, 1 -enemie, 2 - double enemie
	static int vsotaSovrastev;


	static double sestevekDinamike = 0;
	
	/*MESANJE*/
	static boolean MESAJ_NAKLJUCNO_Z_NAJBOLJSIM = false;

	// TREE NODE
	//static ArrayList<TreeNode> listaUspesnihPoskusov = new ArrayList<TreeNode>();
	static ArrayList<TreeNode> listaVsehPoskusov = new ArrayList<TreeNode>();
		
	static TreeNode trenutniNode;
	static boolean ROOT_SE_NI_USTVARJEN = true;
	
	static int stevecZaIzpisKoncaVrste = 0;
	static int stevecDobrihRezultatov = 0;
	static int stevecSlabihRezultatov = 0;
	
	static int zadnjaUspesnaIteracija = 0;
	
	static int steviloDreves = 0;
	
	
	
	/*********************INICIALIZACIJE**************************/
	/*************************************************************/

	/*
	 *-       --       --       --       --       --       -
	 * -     -  -     -  -     -  -     -  -     -  -     - 
	 *  -   -    -   -    -   -    -   -    -   -    -   -   
 	 *   - -      - -      - -      - -      - -      - -   
	 *    -        -        -        -        -        -    
	 */
	
	/*************************************************************/
	/************************MAIN*********************************/
	

	public static void main(String[] args) {


		ParseFile.parse("D:\\My Documents\\Java\\poroka_input.tar\\in\\in5.txt");



		ljudi = ParseFile.stLjudi;
		miza = ParseFile.mize;
		s = ParseFile.s;

		ljudje = new int[ljudi];
		for ( int i = 0; i < ljudi; i++) {
			ljudje[i] = i;
		}


		/* from hovinga */

		//p = ParseFile.stLjudi;
		p = ljudi;
		d = 1;

		initpoints();

		/*************/

		System.out.println("-------------");
		System.out.println("-------------");
		System.out.println("Stevilo ljudi: " + ljudi);
		vrniMozneKombinacijeMiz(ljudi);
		System.out.println("Mozne poseditve:");
		Utility.izpisi(m,im);
		System.out.println("-------------");

		/************/


		kreirajFolk();
		//tabelaRazdalj = dobiTabeloRazdalj();


		if ( ANIMATE ) {
			// Create application frame.
	        FcbFrame frame = new FcbFrame();

	        frame.setSize(1200, 700);
	        //frame.setExtendedState(frame.getExtendedState()|JFrame.MAXIMIZED_BOTH);
	        // Show frame.
	        frame.show();
		}

        //da prevec ne racuna lahko nastavimo min na neko manjso vrednost,
        //se pravi da nastavimo prag
        //minKazTock = (int)Math.round(ljudi*1.5);
        minKazTock = Poroka.ljudi * Poroka.ljudi * 2 + 1;
        minKazTockSKUPI = minKazTock;


		// izracunamo ce se splaca preiskat vse kombinacije:
		// pomnozimo vse mize in zraven tudi stevilo kombinacij im
		long product = im;
		for (int i = 0; i < miza.length; i++) {
			product *= miza[i];
			if ( product > 1000000 ) {
				SEARCH_ONLY_MOST_PROMISSING = true;
				System.out.println ("Izkljopljeno izcrpno preiskovanje.");
				break;
			}
		}
		//System.out.println ("produkt miz: " + product);

		// meja kdaj bomo nehali premikati clovecke:
		//Peer.LIMIT = ((double)ljudi/50.0) * 0.015;
		//System.out.println ("meja ko se ustavi: " + Peer.LIMIT);



	//	najdiNajboljsoResitev();
	//	izpisiNajboljsoResitev();


		int iteration = 0;
		stVelikihIteracij = 0;
		int wasStabilized = 0;
		//boolean allStopped = false;
		double dinamika;

		Date then = new Date();
		Date now;

		Date thenLokalniMin;
		Date nowLokalniMin;
		casIskanjaLokMin = 0;

		najdiLokalniMinRekurzivnihKlicev = 0;
		najdiLokalniMinKlicev = 0;


		int noOfIter;

		
		
		//Ustvari 30 rootov
		for ( int rooti = 0; rooti <= 30; rooti++ ) {
			initpoints();
			
			minKazTock = Poroka.ljudi * Poroka.ljudi * 2 + 1;
			
			int count = 0;
			
			while (  (count < noOfIterGeneral)  ) {

									
				
				/***********************/

				d=0;			// Actual algorithm
				for(int i=1;i<p;i++)		// for each point..
				{
					for(int k=0;k<i;k++)	// in relation to each other point..
					{
						//if ( enemie[i][k] > 0 ) { // za vsako sovrastvo
							r=1;
							for(int j=0;j<n;j++)  // in each dimension..
							{
								r-=po[j][i]*po[j][k];	// calculate the resulting distance
							}
							r1=Math.sqrt(2*r);	// r1 = mutual distance
							rn[i][k]=r1;	// Save mutual distance for later use
							rn[k][i]=r1;
							d+=r1;		// Calculate total distance
							double r3=r1;

							if ( law )
							{
								for(int j=1;j<n-1;j++) // in enabled follow 1/R^(n-1) law (else 1/R)
									r3*=r1;
							}
							else
									r3 *= HITROST; // ko je bla tle 1 je blo pr pr5 125!
									//r3 = HITROST; //linearno?


							//if ( enemie[i][k] == 0 )
							//	r3/= priblizevanjePrij;
							if ( enemie[i][k] == 1 )
								r3/= bezanjeOdSov;
							if ( enemie[i][k] == 2 )
								r3/= bezanjeOdDvSov;


							//r3*= ((double) vsotaSovrastev); //To neki dost ne spremeni

							for(int j=0;j<n;j++)
							{
								r2=(po[j][i]-po[j][k])/r3;   //n[i][k];  // move the 2 points to their new location
								if ( enemie[i][k] > 0 ) { // ce je sovraznik
									//r2=(po[j][i]-po[j][k])/r3; //!!!!
									pn[j][i]+=r2;
									pn[j][k]-=r2;
								}
								else {
									//r2=(po[j][i]-po[j][k])*r3; //!!!!!!
									pn[j][i] -= r2;
									pn[j][k] += r2;
								}

							}
							d+=r3; //nekaksen skupni naboj !!!!!
							//d+=Math.abs(r2);
						//}
					}
				}
				correct();	// Correct movements into spere with radius 1 and update them



				oldd = d;

				count++;

			}
			
			najdiNajboljsoResitev();
			najdiLokalniMinNajboljseResitve(); // NEW!!!
			
			ustvariRoot();
			System.out.println("Root Ustvarjen");
			
			steviloDreves++;
			
		}

		
		
		
		//VELIKI CIKEL:
		//Tocke se inicializirajo, iztece se srednji cikel in se spravi najboljsa resitev
		//zadnjega srednjega cikla. Prekine se ko potece cas.
		// glavna zanka v kateri se izvajajo iskanja dokler ne potece cas
		do {

			//stevecPoskusov++;

			d = 1;
			if ( MESAJ_NAKLJUCNO_Z_NAJBOLJSIM ) {
				shakePointsCooling(); //shakePoints();
			}
			else {
				initpoints();
			}
			
			boolean firstTime = true;
			iteration = 0;
			wasStabilized = 0;
			sestevekDinamike = 0;

			minKazTock = Poroka.ljudi * Poroka.ljudi * 2 + 1;

			
			//Tle se je ucasih zacel SREDNJI CIKEL:
			//Srednji cikel -> v njemu se prvo iztece mali cikel, nato se poisce resitev in 
			//�e je boljsa od prejsnjih (v tem srednjem ciklu) se izpise. Prekine se ko potece cas
			// podzanka vecjega cikla v katerem se vsi elementi premesajo
		

			int count = 0;
			oldd=1;
			dinamika = 1;

			if ( firstTime ) {
				noOfIter = noOfFirstIter;
				firstTime = false;
			}
			else
				noOfIter = noOfIterGeneral;

			

			
			//MALI CIKEL:
			//Mali cikel -> osnovni algoritem, ki premika tocke in se ustavi po dolocenem stevilu iteracij
			//ali ko pade dinamika pod doloceno mero
			// NEW!!! samo count.
			while (  (count < noOfIter)  ) {

									
				
				/***********************/

				d=0;			// Actual algorithm
				for(int i=1;i<p;i++)		// for each point..
				{
					for(int k=0;k<i;k++)	// in relation to each other point..
					{
						//if ( enemie[i][k] > 0 ) { // za vsako sovrastvo
							r=1;
							for(int j=0;j<n;j++)  // in each dimension..
							{
								r-=po[j][i]*po[j][k];	// calculate the resulting distance
							}
							r1=Math.sqrt(2*r);	// r1 = mutual distance
							rn[i][k]=r1;	// Save mutual distance for later use
							rn[k][i]=r1;
							d+=r1;		// Calculate total distance
							double r3=r1;

							if ( law )
							{
								for(int j=1;j<n-1;j++) // in enabled follow 1/R^(n-1) law (else 1/R)
									r3*=r1;
							}
							else
									r3 *= HITROST; // ko je bla tle 1 je blo pr pr5 125!
									//r3 = HITROST; //linearno?


							//if ( enemie[i][k] == 0 )
							//	r3/= priblizevanjePrij;
							if ( enemie[i][k] == 1 )
								r3/= bezanjeOdSov;
							if ( enemie[i][k] == 2 )
								r3/= bezanjeOdDvSov;


							//r3*= ((double) vsotaSovrastev); //To neki dost ne spremeni

							for(int j=0;j<n;j++)
							{
								r2=(po[j][i]-po[j][k])/r3;   //n[i][k];  // move the 2 points to their new location
								if ( enemie[i][k] > 0 ) { // ce je sovraznik
									//r2=(po[j][i]-po[j][k])/r3; //!!!!
									pn[j][i]+=r2;
									pn[j][k]-=r2;
								}
								else {
									//r2=(po[j][i]-po[j][k])*r3; //!!!!!!
									pn[j][i] -= r2;
									pn[j][k] += r2;
								}

							}
							d+=r3; //nekaksen skupni naboj !!!!!
							//d+=Math.abs(r2);
						//}
					}
				}
				correct();	// Correct movements into spere with radius 1 and update them

				/***********************/


				count++;

				dinamika = Math.abs(d - oldd);
				if ( (dinamika < pogojZaUstavitev) && (firstTime == false) ) { 
					// prvi krog se izvrsijo vse iteracije
					wasStabilized++;
					//break; 
				}
				//System.out.println (Math.abs(d - oldd));
				oldd = d;



			}

			//System.out.println ("Zdaj iscem najboljso resitev.");
			//System.out.println ("---------------");


			sestevekDinamike += dinamika;

			najdiNajboljsoResitev();

			thenLokalniMin = new Date();
			if ( ISCI_LOKALNI_MIN )
				najdiLokalniMinNajboljseResitve(); // NEW!!!
			nowLokalniMin = new Date();

			casIskanjaLokMin += nowLokalniMin.getTime() - thenLokalniMin.getTime();

			now = new Date();


			iteration++;

			if ( minKazTock < minKazTockSKUPI ) {
				minKazTockSKUPI = minKazTock;
				minKazTockKombSKUPI = minKazTockKomb;
				zadnjaUspesnaIteracija = stVelikihIteracij;
				
				izpisiNajboljsoResitev();

				System.out.println ("St velikih iteracij: " + (stVelikihIteracij+1));
				System.out.println ("St malih iteracij: "+iteration+", St umiritev: "+wasStabilized );
				System.out.format ("povprecni cas ene iteracije = %.3f%n", ((now.getTime() - then.getTime())/1000.0)/(iteration));
				System.out.format ("povprecje dinamike na koncu = %.5f%n", sestevekDinamike/iteration );
				System.out.format ("zadnja dinamika na koncu = %.5f%n", dinamika );
				System.out.format ("zadnja hitrost: %.1f%n", HITROST );
				System.out.println ("St dreves: " + steviloDreves);
				System.out.println ();
				
				
			}
			
			// TREE NODE
			if ( ROOT_SE_NI_USTVARJEN ) {
				ustvariRoot();
				steviloDreves++;
				System.out.println("NOVO DREVO ST. "+steviloDreves);
			}
			else {
			
				
				//verzija 2 - dinamicna
				//TODO ?
				
				// ce so trenutna drevesa se dovolj ucinkovita
				if ( /*(( (double)zadnjaUspesnaIteracija * (double)steviloDreves ) 
						/ (double)stVelikihIteracij) > 1.0 */ true ) {
					if ( (((double) minKazTockSKUPI / (double) minKazTock) > ROB_ZA_ISKANJE_NAJBOLJSEGA_NODA )
							&&
							(trenutniNode.kazTocke > minKazTock) //poskus boljsi od starsa
							) {
						//dober rezultat
						stevecDobrihRezultatov++;
						trenutniNode.putPoskus(minKazTock);
						trenutniNode = trenutniNode.ustvariOtroka(minKazTock,
								koordinate, minKazTockKomb);
						listaVsehPoskusov.add(trenutniNode);
						//problem ker se lahko zacikla ce je random 0.0

					} else {
						//slab rezultat
						stevecSlabihRezultatov++;
						trenutniNode.putPoskus(minKazTock);
						Collections.sort(listaVsehPoskusov);
						trenutniNode = listaVsehPoskusov.get(0);

					}
				}
				else {
					//v naslednjem ciklu ustvari novo drevo
					initpoints();
					ROOT_SE_NI_USTVARJEN = true;
					
				}
				
				
										
					
				/*
				if ( minKazTock < trenutniNode.kazTocke ) {
					if ( !trenutniNode.edenIzmedOtrokZeVsebujeRazporeditev(minKazTockKomb) ) {
						shraniNode();
					}
				}
				*/
			}
			
			//Tle je blo ucasih konc srednjega cikla

			stVelikihIteracij++;

			System.out.print( minKazTock+ ", ");
			if ( stevecZaIzpisKoncaVrste++ >= 13 ) {
				System.out.println();
				stevecZaIzpisKoncaVrste = 0;
			}
			
		
			MESAJ_NAKLJUCNO_Z_NAJBOLJSIM = true;

		} while ( ((now.getTime() - then.getTime())/1000) < izvajalniCasSekund );


		
		int vsotaRezultatovVelikihIteracij = 0;
			
		//TREE NODE
		Utility.izpisiListoNodov(listaVsehPoskusov);
		izpisiNajboljsoResitev();
		System.out.println ("RESITEV: "+ minKazTockSKUPI);
		System.out.println("Stevilo dreves: "+steviloDreves);
		System.out.println ("St velikih iteracij: "+(stVelikihIteracij)+", St umiritev: "+wasStabilized );
		System.out.println ();
		System.out.println ("Dobri: "+stevecDobrihRezultatov+" / Slabi: "+stevecSlabihRezultatov);
		System.out.println ("Povprecje kazenskih tock v velikih iteracijah: " + (vsotaRezultatovVelikihIteracij / stVelikihIteracij) );
		System.out.format ("Povprecni cas male iteracije = %.3f%n", ((now.getTime() - then.getTime())/1000.0)/(iteration+1));
		System.out.format ("povprecje dinamike na koncu = %.5f%n", sestevekDinamike/iteration);
		//System.out.println ("Cas porabljen za iskanje lokalnega minimuma: " + (casIskanjaLokMin/1000.0));
		System.out.format ("Delez casa iskanja lok. min.: %.0f", ( (double) casIskanjaLokMin / (double) (now.getTime() - then.getTime())) * 100.0 );
		System.out.println ("%");
		System.out.println ("Stevilo klicev iskanja lokalnega minimuma: " + (najdiLokalniMinKlicev - najdiLokalniMinRekurzivnihKlicev) );
		System.out.println ("Stevilo rekurzivnih klicev lokalnega minimuma: " + najdiLokalniMinRekurzivnihKlicev);
		System.out.format ("Delez rekurzivnih klicev: %.0f", ((double) najdiLokalniMinRekurzivnihKlicev / (double) (najdiLokalniMinKlicev - najdiLokalniMinRekurzivnihKlicev)) * 100.0 );
		System.out.println ("%");
		System.out.format ("hitrost na koncu: %.1f%n", HITROST );
		System.out.println ();
		System.out.println ("Konec.");
		//izpisiNajboljsoResitev();


	}

	
	
	
	/*************************************************************/
	/************************MAIN*********************************/

	/*
	 *-       --       --       --       --       --       -
	 * -     -  -     -  -     -  -     -  -     -  -     - 
	 *  -   -    -   -    -   -    -   -    -   -    -   -   
 	 *   - -      - -      - -      - -      - -      - -   
	 *    -        -        -        -        -        -    
	 */
	
	/*************************************************************/
	/*******************METODE IN FUNKCIJE************************/
	
	
	
	
	
	/************RACUNANJE KAZ. TOCK*********************/

	public static int stKazenskihTock( int[][] moznaResitev ) {
		// vrne stevilo kazaenskih tock za dano kombinacijo
		int vsota = 0;
		int oseba1, oseba2;

		for ( int i = 0; i < moznaResitev.length; i++) {

			if ( (moznaResitev[i] != null) && (moznaResitev[i].length > 1) ) {

				for ( int j = 1; j < moznaResitev[i].length; j++) {

					oseba1 = moznaResitev[i][j];

					for ( int k = j-1; k >= 0; k--) {
						oseba2 = moznaResitev[i][k];
						vsota += ( s[oseba1][oseba2] + s[oseba2][oseba1] );
					}

				}

			}

		}

		return vsota;
		
	}

	
	public static int stKazenskihTock( int[] moznaResitev) {
		// vrne stevilo kazaenskih tock za dano kombinacijo
		// ce imas prvega cloveka oznacenega z 1
		int vsota = 0;
		int oseba1, oseba2;

		if ( moznaResitev.length > 1 ) {

			for ( int j = 1; j < moznaResitev.length; j++) {

				oseba1 = moznaResitev[j];

				for ( int k = j-1; k >= 0; k--) {
					oseba2 = moznaResitev[k];
					vsota += ( s[oseba1][oseba2] + s[oseba2][oseba1] );
				}

			}

		}

		return vsota;

	}

	/************RACUNANJE KAZ. TOCK*********************/

	/************ISKANJE KOMBINACIJ MIZ***************************/

	private static int[][] vrniMozneKombinacijeMiz(int ljudi) {

		//Utility.izpisi(miza);
		Arrays.sort(miza);
		//Utility.izpisi(miza);
		Utility.obrni(miza);
		System.out.println("Miza: " + Arrays.toString(miza));

		m = new int[10000][miza.length];
		int[] comb1 = new int[miza.length];


		// ce je miz enako ali vec kot je ljudi
		if ( miza.length >= ljudi ) {
			int i = 0;
			for ( ; i < ljudi; i++) {
				comb1[i] = 1;
			}
			for ( ; i < miza.length; i++) {
				comb1[i] = 0;
			}
			return m;
		}

		//drugace za vsako mizo posedimo enega cloveka
		for ( int i = 0; i < miza.length; i++) {
			comb1[i] = 1;
		}

		// ostale mize napolnimo po vrsti od najvecje proti najmansi, dokler gre
		int lj = ljudi - miza.length; // odstejemo ze posedene
		for ( int i = 0; (i < miza.length) && (lj > 0); i++) {

			for ( int j = 1; (j < miza[i]) && (lj > 0); j++) {
				comb1[i]++;
				--lj;
				//System.out.println(lj + " " + i);
			}

		}

		//prekopiramo comb1 v prvo mesto od m
		m[0] = Arrays.copyOf(comb1, comb1.length);
		im = 1;

		// zacnemo z premetavanjem
		//for ( int i = comb1.length-1; i >= 0; i--)
		//	premeci(i,Arrays.copyOf(comb1, comb1.length));
		premeci(0,Arrays.copyOf(comb1, comb1.length));

		return m;

	}


	private static void premeci(int iz, int[] tmp) {
		// premesca ljudi od leve proti desni in sproti shranjuje nove kombinacije
		// v tabelo m.

		while ( true ) {


			// poisce prosto mesto
			int nas = najdiProstoMesto(iz, tmp);

			if ( iz == tmp.length-1 )
				return;

			if ( nas != -1 ) {
				tmp[iz]--; //prestavi enega cloveka iz trenutne pozicije na prosto mesto
				tmp[nas]++;
				m[im++] = Arrays.copyOf(tmp, tmp.length); //shrani razporeditev
			}


			//REKURZIVNI KLIC z iz+1 in kopijo trenutnega stanja (isto ponovi za eno mizo desno)
			premeci ( iz+1, Arrays.copyOf(tmp, tmp.length) );


			// ce je za desno mizo isto stevilo ljudi kot za trenutno
			if (tmp[iz] == tmp[iz+1]) {

				// pogleda do katere mize sedi isto ljudi
				int i = iz+1;
				for ( ; ( i < tmp.length - 2 ) && (tmp[i] == tmp[i+1]) ; i++);

				// od te mize zdaj proba enega presest in tako vse do mize desno
				// od trenutne pozicije
				for ( ; (i > iz) && (najdiProstoMesto(i, tmp) != -1) ; i--) {
						int nas2 = najdiProstoMesto(i, tmp);
						tmp[i]--;
						tmp[nas2]++;
				}

				// ce rata vse presest
				if ( tmp[iz] > tmp[iz+1] ) {
					// shrani trenutno razporeditev v tabelo m, ce ni ze shranjena na prejsnjem mestu
					if ( !Arrays.equals( m[im-1], tmp ) ) {
						m[im++] = Arrays.copyOf(tmp, tmp.length);
					}
					nas = 0;
				}

			}

			// ce ne najde prostega mesta se izvajanje funkcije prekine
			if ( nas == -1 ) {
				return;
			}


		}

	}


	private static int najdiProstoMesto(int iz, int[] tmp) {
		//poisce mizo z prostim mestom

		// isci od trenutne pozicije + 1 do konca polja
		for ( int i = iz+1; i < tmp.length; i++) {
			// ce je trenutna pozicija vecja vsaj za dva od iskane
			// in iskana ni napolnjena do konca
			// in je pozicija levo od iskane vecja od iskane
			// in je trenutna vecja od njene desne,
			// potem vrni iskano
			if ( (tmp[iz] >= tmp[i]+2) && (tmp[i] < miza[i])
					&& (tmp[i-1] > tmp[i]) && (tmp[iz] > tmp [iz+1]) ) {
				return i;
			}
		}

		// ce ne najdes primerne pozicije vrni -1
		return -1;

	}

	/************ISKANJE KOMBINACIJ MIZ***************************/

	/********************************FOLK****************************/

    private static void kreirajFolk() {
    	//kreiranje folka

		vsotaSovrastev = 0;

        for ( Integer i = 0; i < Poroka.p; i++ ) {

        	kolkJeKdoZatezen[i] = 0;
        	for ( Integer j = i+1; j < Poroka.p; j++ ) {
        		if ( Poroka.s[i][j] == 1 && Poroka.s[j][i] == 1 ) {
        			Poroka.enemie[i][j] = 2;
        			Poroka.enemie[j][i] = 2;
        			vsotaSovrastev += 2;
        			kolkJeKdoZatezen[i] += 2;
  				}
        		else if ( Poroka.s[i][j] == 1 && Poroka.s[j][i] == 0 ) {
        			Poroka.enemie[i][j] = 1;
        			Poroka.enemie[j][i] = 1;
        			vsotaSovrastev++;
        			kolkJeKdoZatezen[i]++;
  				}
        		else if ( Poroka.s[i][j] == 0 && Poroka.s[j][i] == 1 ) {
        			Poroka.enemie[i][j] = 1;
        			Poroka.enemie[j][i] = 1;
        			vsotaSovrastev++;
        			kolkJeKdoZatezen[i]++;
  				}
        	}
        }

        najdiNajvecjegaZatezenca();

    }


    private static void najdiNajvecjegaZatezenca() {

    	int[] tmp = kolkJeKdoZatezen;
    	java.util.Arrays.sort(tmp, 0, p-1);
    	najvecjiZatezenec = java.util.Arrays.binarySearch(kolkJeKdoZatezen, tmp[p-1]); //vrne indeks

    }

	/********************************FOLK****************************/

    /*****************ISKANJE RESITVE****************************/

    //NEW !!!
    public static void najdiLokalniMinNajboljseResitve() {

    	najdiLokalniMinKlicev++;

        //static int minKazTock; // najmanj kazenskih tock dozdej
    	//static int[][] minKazTockKomb; // kombinacija z najmanj kazenskimi tockami dozdej

        int minDelovni; // najmanj kazenskih tock dozdej
    	int[][] resitevDelovna; // kombinacija z najmanj kazenskimi tockami dozdej

    	//Shrani vse resitve z eno zamenjavo ljudi, ki dajo boljsi rezultat od minKazTock,
    	//in rekurzivno isci naprej...
    	
    	//za hitrejse izvajanje
    	int[] kazTockPoMizah = new int[minKazTockKomb.length];
    	for ( int i = 0; i < minKazTockKomb.length; i++) {
    		kazTockPoMizah[i] = stKazenskihTock( minKazTockKomb[i] );
    	}
    	int kazTockTemp = 0;
    	int kazTockBrezMizeI = 0;
    	int[][] tempRazporeditev;

    	
    	minDelovni = minKazTock;
		resitevDelovna = minKazTockKomb;

		for ( int i = 0; i < minKazTockKomb.length - 1; i++) {
			kazTockBrezMizeI = minKazTock - kazTockPoMizah[i];
			for ( int j = 0; j < minKazTockKomb[i].length; j++) {
				// gre po vseh elementih matrike in proba najdet uredu zamenjavo na drugih mizah

				for ( int k = i+1; k < minKazTockKomb.length; k++) {
					for ( int l = 0; l < minKazTockKomb[k].length; l++) {

						//zamenjaj m[i][j] z m[k][l] in preveri ce da boljso resitev in ce jo
						//jo spravi v minDelovni

						kazTockTemp = kazTockBrezMizeI - kazTockPoMizah[k];	
						tempRazporeditev = Utility.zamenjaj( minKazTockKomb, i, j, k, l);
						kazTockTemp += stKazenskihTock( tempRazporeditev[i] ) +
										stKazenskihTock( tempRazporeditev[k] );
						
						if ( kazTockTemp < minDelovni ) {

								minDelovni = kazTockTemp;
								resitevDelovna = tempRazporeditev;

						}

					}

					//ce miza za katero ga hocemo posedet se ni polna, ga probamo posedit (brez zamenjave)

					if ( miza[k] > minKazTockKomb[k].length ) {

						if ( stKazenskihTock( Utility.premakni( minKazTockKomb, i, j, k) ) < minDelovni ) {

								minDelovni = stKazenskihTock( Utility.premakni( minKazTockKomb, i, j, k) );
								resitevDelovna = Utility.premakni( minKazTockKomb, i, j, k);

						}

					}


				}

			}
		}

		// preveri ce je nasel boljso resitev
		if ( minDelovni < minKazTock ) {

			minKazTock = minDelovni;
			minKazTockKomb = resitevDelovna;

			najdiLokalniMinRekurzivnihKlicev++;

			najdiLokalniMinNajboljseResitve(); // se rekurzivno se enkrat izvede

		}


	}


	public static void najdiNajboljsoResitev(){

		tabelaRazdalj = dobiTabeloRazdalj();

		// za vsako razporeditev najdi najboljso resitev
		for (int i = 0; i < Poroka.im; i++) {
			// ( polje kjer se bo shranjevalo posedene ljudi, razporeditev miz, indeks pri keri mizi smo )
			najdiResitev(new int[Poroka.m[i].length][], Poroka.m[i], 0, 0);
		}
	}


	private static void najdiResitev ( int[][] posedeniLjudje, int[] razporeditevMiz, int indeks, int kazTocke ) {
		// ( polje kjer se bo shranjevalo posedene ljudi, razporeditev miz, indeks pri keri mizi smo )

		// robni pogoj 1
		if ( razporeditevMiz[indeks] == 1 ) {
			// ce je ostalo isto miz kot ljudi

			if ( kazTocke < minKazTock ) {
				minKazTock = kazTocke;


				int[] neposedeni = Utility.prviBrezDrugih( ljudje, Utility.twoDToOneD(posedeniLjudje)  );
				int in = 0;

				// posedimo se preostale ljudi vsakega za svojo mizo
				for (int i = indeks; i < razporeditevMiz.length; i++) {
					posedeniLjudje[i] = new int[1];
					posedeniLjudje[i][0] = neposedeni[in++];
				}

				minKazTockKomb = posedeniLjudje;
			}
			return;
		}

		// robni pogoj 2
		if ( indeks == razporeditevMiz.length-1 ) {
			// ce smo pri zadnji mizi

			posedeniLjudje[indeks] = Utility.prviBrezDrugih( ljudje, Utility.twoDToOneD(posedeniLjudje)  );
			kazTocke = kazTocke + stKazenskihTock( posedeniLjudje[indeks] );

			if ( kazTocke < minKazTock ) {
				minKazTock = kazTocke;
				minKazTockKomb = posedeniLjudje;
			}
			return;
		}


		// dobi vse grupe ljudi z dolocenim stevilom ljudi
		int[][][] grupeOmejeneVelikosti = dobiGrupeDoloceneVelikosti ( razporeditevMiz[indeks], posedeniLjudje );

		if ( (!SEARCH_ONLY_MOST_PROMISSING)
			/*	|| ( (produktPreostalihMiz(razporeditevMiz,indeks) < 50) ) */) {

			//System.out.println (produktPreostalihMiz(razporeditevMiz,indeks));

			for (int i = 0; i  < grupeOmejeneVelikosti.length; i++) {

				//if ( !Utility.vsebuje(posedeniLjudje, grupeOmejeneVelikosti[i]) ) {

					int kazTockeNew = kazTocke + grupeOmejeneVelikosti[i][1][0];

					if ( kazTockeNew < minKazTock ) {

						int[][] umesnaResitev = Arrays.copyOf(posedeniLjudje, posedeniLjudje.length);
						umesnaResitev[indeks] = grupeOmejeneVelikosti[i][0];

						// REKURZIVNI KLIC:
						najdiResitev (umesnaResitev, razporeditevMiz, indeks+1, kazTockeNew );
					}
				//}
			}
		}
		else {

			//int minKaz = 1000000;
			int hateFaktorGrupe;
			int kazenskeTockeGrupe;
			double ocenaGrupe;
			double maxOcena = -1000000;
			int indeksMaxOcena = 0;

			// nadaljuje rekurzijo samo z grupami z najmanj kaz tockami in najboljsim hateFaktorjem
			for (int i = 0; i < grupeOmejeneVelikosti.length; i++) {
				kazenskeTockeGrupe = grupeOmejeneVelikosti[i][1][0];
				hateFaktorGrupe = dobiHateFaktorGrupe ( grupeOmejeneVelikosti[i][0],
														Utility.twoDToOneD(posedeniLjudje) );
				//hateFaktorGrupe = hateFaktorGrupe - kazenskeTockeGrupe; //odstejemo medsebojna sovrastva


				int stNeposedenih = ljudi - Utility.twoDToOneD(posedeniLjudje).length;

				// ocenimo vrednost grupe z enacbo:
				//ocenaGrupe =  ( ((double)hateFaktorGrupe / ljudi) * 2.25 )
				//			- ( ((double)kazenskeTockeGrupe / grupeOmejeneVelikosti[i][0].length )   );

				ocenaGrupe =  ( ((double)hateFaktorGrupe / stNeposedenih) * KONSTANTA_ZA_HATE_FAKTOR)
							- ( ((double)kazenskeTockeGrupe / grupeOmejeneVelikosti[i][0].length )   );


				if ( ocenaGrupe > maxOcena ) {
					maxOcena = ocenaGrupe;
					indeksMaxOcena = i;

				}

			}


			int kazTockeNew = kazTocke + grupeOmejeneVelikosti[indeksMaxOcena][1][0];

			if ( kazTockeNew < minKazTock ) {

				int[][] umesnaResitev = Arrays.copyOf(posedeniLjudje, posedeniLjudje.length);
				umesnaResitev[indeks] = grupeOmejeneVelikosti[indeksMaxOcena][0];

				// REKURZIVNI KLIC:
				najdiResitev (umesnaResitev, razporeditevMiz, indeks+1, kazTockeNew );
			}

		}

	}


	private static int dobiHateFaktorGrupe ( int[] grupa, int[] posedeni ) {

		int[] ljudjeKiJihNeUpostevamo = Utility.concat (grupa, posedeni);
		int[] ljudjeKiJihUpostevamo = Utility.prviBrezDrugih(ljudje, ljudjeKiJihNeUpostevamo);

		int hateSum = 0;
		int indeks1, indeks2;

		// sesteje hate faktor vseh v grupi
		for (int i = 0; i < grupa.length; i++) {
			for (int j = 0; j < ljudjeKiJihUpostevamo.length; j++) {
				indeks1 = grupa[i];
				indeks2 = ljudjeKiJihUpostevamo[j];
				if ( enemie[indeks1][indeks2] == 1/*folk[indeks1].isEnemie(folk[indeks2])*/ )
					hateSum++;
				if ( enemie[indeks1][indeks2] == 2/*folk[indeks1].isDoubleEnemie(folk[indeks2])*/ )
					hateSum += 2;
			}

		}

		return hateSum;
		
	}


	private static int[][][] dobiGrupeDoloceneVelikosti ( int velikost, int[][] posedeniLjudje ) {

		if ( velikost == 1 )
			System.out.println ("Velikost je ena!!!!!!!!!!!");


		int[] posedeniLjudje1D = Utility.twoDToOneD(posedeniLjudje);
		int[] neposedeniLjudje = Utility.prviBrezDrugih( ljudje, posedeniLjudje1D );

		int[][][] resitev = new int[neposedeniLjudje.length][][];
		int ir = 0;
		int[] temp;
		boolean flag;


		for ( int i = 0; i < neposedeniLjudje.length; i++ ) {

			temp = dobiGrupoSosedov ( neposedeniLjudje[i], neposedeniLjudje, velikost );

			Arrays.sort(temp);
			// preverimo ce imamo dano kombinacijo ze shranjeno
			flag = false;
			for (int k = 0; k < ir; k++) {
				if ( (resitev[k][0] != null) && (resitev[k][0].equals( temp )) ) {
					flag = true;
					break;
				}
			}

			// ce dana kombinacija se ne obstaja jo shranimo
			if ( flag == false ) {

				resitev[ir] = new int[2][];
				resitev[ir][0] = temp;
				resitev[ir][1] = new int[1];
				resitev[ir][1][0] = Poroka.stKazenskihTock ( temp );

				ir++;
			}

		}

		resitev = Arrays.copyOf(resitev,ir);

		return resitev;

	}


	public static int[] dobiGrupoSosedov ( int clovk, int[] mnozicaLjudi, int stLjudi ) {
		// clovk skupi z najbljizimi stLjudi-1 sosedi iz mnoziceLjudi

		int[] grupa = new int[stLjudi];
		grupa[0] = clovk;
		double minRazdalja, zadnjaRazdalja;

		// najdemo <stLjudi-1> najbljizjih
		for (int i = 1; i < stLjudi; i++) {

			//minRazdalja = Sphere.R*2;
			minRazdalja = 10000000;

			int zadnjiClovk = grupa[i-1];
			zadnjaRazdalja = tabelaRazdalj[clovk][zadnjiClovk];

			for (int j = 0; j < mnozicaLjudi.length; j++) { // tle je blo prej j = 0

				int clovk2 = mnozicaLjudi[j];
				if ( clovk2 != clovk ) { // da ne primerjamo samega s seboj

					if ( (tabelaRazdalj[clovk][clovk2] < minRazdalja)
							&& (tabelaRazdalj[clovk][clovk2] > zadnjaRazdalja) ) {
						grupa[i] = clovk2;
						minRazdalja = tabelaRazdalj[clovk][clovk2];
					}
				}
			}
		}

		return grupa;
		
	}


	public static int[] dobiVseRazliciceMizBrez1() {
		// vrne vse moznosti kolk ljudi lahko sedi za eno mizo brez ena
		int[] vseRazlicice = new int[1000];
		int ir = 0;
		boolean obstaja;

		for ( int i = 0; i < Poroka.im; i++ ) {
			for (int j = 0; j < Poroka.m[i].length; j++) {


				obstaja = false;
				for (int k = 0; k <= ir; k++) {
					if ( vseRazlicice[k] == Poroka.m[i][j] ) {
						obstaja = true;
					}
				}
				if ( obstaja == false ) {
					vseRazlicice[ir++] = Poroka.m[i][j];
				}

			}
		}

		vseRazlicice = Arrays.copyOf(vseRazlicice, ir);
		Arrays.sort(vseRazlicice);
		// odstranimo enko
		if ( vseRazlicice[0] == 1 )
			vseRazlicice = Arrays.copyOfRange(vseRazlicice, 1, ir);
		
		return vseRazlicice;

	}


	private static double[][] dobiTabeloRazdalj() {
		// vrne matriko velikosti ljudi*ljudi z razdaljami med njimi
		double[][] tabelaRazdalj = new double[Poroka.ljudi][Poroka.ljudi];

		for ( int i = 0; i < Poroka.ljudi; i++ ) {
			for ( int j = 0; j < Poroka.ljudi; j++ ) {
				tabelaRazdalj[i][j] = rn[i][j];//folk[i].getDistance(folk[j]);
			}

		}

		return tabelaRazdalj;

	}

	
	public static void izpisiNajboljsoResitev() {

		System.out.println ();
		System.out.println ("Najboljsa razporeditev: ");
		Utility.izpisiObrnjenoIndeksPlusEna(minKazTockKombSKUPI);
		System.out.println ("Kazenskih tock: " + minKazTockSKUPI);
		System.out.println ("---------------");

	}

	
	public static void izpisiNajboljsiRezultat() {

		System.out.println ("Kazenskih tock: " + minKazTock);
		System.out.println ("---------------");

	}

    /*****************ISKANJE RESITVE****************************/

	/*****************HOVINGA*****************/

	static public void initpoints()
	{
		
		for(int i=0;i<p;i++)
		{
			r=0;
			for(int j=0;j<n;j++)
			{
				pn[j][i]=Math.random()-0.5; //NEW -0.5 da so lepo porazdeljeni, prej so bli vsi v enem kvartilu
				r+=pn[j][i]*pn[j][i];
			}
			for(int j=0;j<n;j++)
			{
				pn[j][i]/=Math.sqrt(r); //jih polozi na kroglo
				po[j][i]=pn[j][i];
			}
		}
		correct();

				
		oldd=0;
		oldd1=1;

	}
	
	
	static private void shakePoints() {
		
		for(int i=0;i<p;i++)
		{
			r=0;
			for(int j=0;j<n;j++)
			{
				// zmesa trenutne pozicije tock z doloceno kolicino randoma
				pn[j][i]= ( ((Math.random()-0.5) * randomFaktor ) + trenutniNode.pozicijeTock[j][i])  / 2.0;
				r+=pn[j][i]*pn[j][i];
			}
			for(int j=0;j<n;j++)
			{
				pn[j][i]/=Math.sqrt(r); //jih polozi na kroglo
				po[j][i]=pn[j][i];
			}
		}
		correct();
	
		oldd=0;
		oldd1=1;

	}
	
	static private void shakePointsCooling() {
		
		for(int i=0;i<p;i++)
		{
			r=0;
			for(int j=0;j<n;j++)
			{
				// zmesa trenutne pozicije tock z doloceno kolicino randoma
				pn[j][i]= ( ((Math.random()-0.5) / (trenutniNode.level+1) ) + trenutniNode.pozicijeTock[j][i])  / 2.0;
				r+=pn[j][i]*pn[j][i];
			}
			for(int j=0;j<n;j++)
			{
				pn[j][i]/=Math.sqrt(r); //jih polozi na kroglo
				po[j][i]=pn[j][i];
			}
		}
		correct();
	
		oldd=0;
		oldd1=1;

	}
	
	static public void correct()
	{
		for(int i=0;i<p;i++)	// Correct data within radius 1 sphere and update model
		{
			r=0;
			for(int j=0;j<n;j++)
			{
				r+=pn[j][i]*pn[j][i];
			}
			r=Math.sqrt(r);
			for(int j=0;j<n;j++)
			{
				pn[j][i]/=r;
				po[j][i]=pn[j][i];
				koordinate[j][i]=pn[j][i];
			}
			for(int j=0;j<p;j++)
			{
				ro[i][j]=rn[i][j];
			}

			//d+=Math.abs(r-1.0);
		}
	}

	/*****************HOVINGA*****************/
	
	/********************TREE NODE****************************/
	
	/*
	static public void shraniNode() {			
		
		// shreni novo razporeditev kot otroka prejsnje in ga vstavi v Listo
		// in jo sortira po stevilu kazenskih tock poskusa
		//trenutniNode.stevecPoskusov++;
		trenutniNode.putPoskus(minKazTock);
		trenutniNode = trenutniNode.ustvariOtroka( minKazTock, koordinate, minKazTockKomb );
		listaVsehPoskusov.add(trenutniNode);
		Collections.sort(listaVsehPoskusov);
			
	}
	*/
	
	static public void ustvariRoot() {
		
		//TreeNode randomRoot = new TreeNode( null, Integer.MAX_VALUE, null, null);
		
		
		// ce se ni shranjena nobena razporeditev naredi root drevesa razporeditev
		trenutniNode = new TreeNode( null , minKazTock, koordinate, minKazTockKomb );
		listaVsehPoskusov.add(trenutniNode);
		ROOT_SE_NI_USTVARJEN = false;
		
	}
	
	/********************TREE NODE****************************/

}