import java.util.ArrayList;



public class TreeNode implements Comparable<TreeNode> {

	final TreeNode stars;
	final ArrayList<TreeNode> otroci;
	final int kazTocke;
	final double[][] pozicijeTock;
	final int[][] razporeditevPoMizah;
	final int level;
	
	
	int stevecPoskusov;
	double povprecjePoskusov;
	int vsotaPoskusov;
	int kazenskeTockeNajboljsegaOtroka;
	//ArrayList<Integer> rezultatiPoskusov;
	
	public TreeNode( TreeNode stars, int kazTocke, double[][] pozicijeTock, int[][] razporeditevPoMizah ) {
		this.stars = stars;
		this.otroci = new ArrayList<TreeNode>();
		this.kazTocke = kazTocke;
		this.stevecPoskusov = 0;
		this.pozicijeTock = pozicijeTock;
		this.razporeditevPoMizah = razporeditevPoMizah;
		
		//this.rezultatiPoskusov = new ArrayList<Integer>();
		this.vsotaPoskusov = 0;
		this.kazenskeTockeNajboljsegaOtroka = Integer.MAX_VALUE;
		if ( stars == null ) {
			level = 0;
		}
		else {
			level = stars.level+1;
		}
		this.povprecjePoskusov = kazTocke;
	}
	
	public TreeNode ustvariOtroka( int kazTockeOtr, double[][] pozicijeTock, int[][] razporeditevPoMizah ) {
		TreeNode otrok = new TreeNode( this, kazTockeOtr, pozicijeTock, razporeditevPoMizah );
		otroci.add(otrok);
		if ( kazenskeTockeNajboljsegaOtroka > kazTockeOtr ) {
			kazenskeTockeNajboljsegaOtroka = kazTockeOtr;
		}
		return otrok;
	}
	
	public void putPoskus(int kazTockePos) {
		//rezultatiPoskusov.add(kazTocke);
		vsotaPoskusov += kazTockePos;
		stevecPoskusov++;
		povprecjePoskusov = (double)vsotaPoskusov / (double)stevecPoskusov;
		if ( kazenskeTockeNajboljsegaOtroka > kazTockePos ) {
			kazenskeTockeNajboljsegaOtroka = kazTockePos;
		}
	}
	
	public double dobiIndeksUspesnosti() {
		
		double procentualniZaostanek = (((double)kazTocke - ((double)Poroka.minKazTockSKUPI-1)) 
										/ 
										(double)kazTocke);
		
		//if ( procentualniZaostanek == 0 )
		//	System.out.print("procentualniZaostanek == 0!!!!");
		
		double indeksUspesnosti =
			(((double)stevecPoskusov+1.0) / (((double)otroci.size())+1.0)*2.0)
			*
			(1+procentualniZaostanek);
		
		//System.out.print(indeksUspesnosti+" ");

		
		return indeksUspesnosti;
		
	}
	
	public double dobiIndeksUspesnosti2() {
		
		return povprecjePoskusov;		
		
	}
	
	
	
	public boolean edenIzmedOtrokZeVsebujeRazporeditev( int[][] razporeditevPoMizah ) {
		
		for ( TreeNode otrok : otroci ) {		
			if ( java.util.Arrays.deepEquals( razporeditevPoMizah, otrok.razporeditevPoMizah) ) {
				System.out.println();
				System.out.println("Eden izmed otrok ze vsebuje Razporeditev!!! dump: this.kazTocke: "
									+ kazTocke + " otrok.kazTocke: " + otrok.kazTocke);
				return true;
			}
		}
		
		return false;
		
	}

	
	private int dobiFaktor() {
		return (int) (povprecjePoskusov + (((double)stevecPoskusov/(double)Poroka.stVelikihIteracij)*(double)Poroka.minKazTockSKUPI));
	}

	/*
	private int dobiFaktor() {
		return kazTocke + stevecPoskusov;
	}
	*/
	/*
	private int dobiFaktor() {
		return kazenskeTockeNajboljsegaOtroka + stevecPoskusov;
	}
*/
	//Compares this object with the specified object for order. 
	//Returns a negative integer, zero, or a positive integer as this object is 
	//less than, equal to, or greater than the specified object. 
	/*
	public int compareTo(TreeNode o) {
		if ( this.kazTocke < o.kazTocke ) return -1;
		else if ( this.kazTocke == o.kazTocke ) return 0;
		else return 1;
	}
	*/
/*
	public int compareTo(TreeNode o) {
		if ( this.povprecjePoskusov < o.povprecjePoskusov ) return -1;
		else if ( this.povprecjePoskusov == o.povprecjePoskusov ) return 0;
		else return 1;
	}
	*/

	public int compareTo(TreeNode o) {
		if ( this.dobiFaktor() < o.dobiFaktor() ) return -1;
		else if ( this.dobiFaktor() == o.dobiFaktor() ) return 0;
		else return 1;
	}
	
	
}
