package sso.gauss;

public class PointContainer {
	
	public Point p;

	public PointContainer() {
	}
	
}
