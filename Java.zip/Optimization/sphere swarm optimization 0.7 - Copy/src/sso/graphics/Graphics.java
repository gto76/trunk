package sso.graphics;

public class Graphics {

}
