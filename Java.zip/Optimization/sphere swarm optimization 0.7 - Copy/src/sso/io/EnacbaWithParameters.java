package sso.io;

import sso.functions.Function;

public class EnacbaWithParameters {
	public final Function enacba;
	public final Parameters paremeters;
	public EnacbaWithParameters(Function enacba, Parameters paremeters) {
		this.enacba = enacba;
		this.paremeters = paremeters;
	}
}
	
