package sso.io;

public class WeddingProblem {

	public final int stLjudi;
	public final int[] mize;
	public int im;
	public final int[][] s;
	public final int is;
	
	public WeddingProblem(int stLjudi, int[] mize, int im,
			int[][] s, int is) {
		super();
		this.stLjudi = stLjudi;
		this.mize = mize;
		this.im = im;
		this.s = s;
		this.is = is;
	}
	

	
}
