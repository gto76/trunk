import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

class Objekt {
	int poX, poY;
	String ch;
	boolean trdnost;
	Objekt (int x, int y, char c, boolean t) {
		poX = x;
		poY = y;
		char cc[] = {c};
		ch = new String(cc);
		trdnost = t;
	}
}
	