import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

class Zid extends Objekt {
	Zid (int x, int y) {
		super(x, y, '#', true);
	}
}



	