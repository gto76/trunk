import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

class Stevilo extends Objekt{
	int prejX, prejY, krog = 1;
	long start, end;
	boolean left = false, right = false, up = false, down = false;
	Stevilo (int x, int y, char c) {
		super(x, y, c, false);
		prejX = x;
		prejY = y;
	}
	
	void levo() {
		if(left == false) {
			
				prejX = poX;
				prejY = poY;
				poX--;
				left = true;
		}
	}
	void desno() {
		if(right == false) {
			prejX = poX;
			prejY = poY;
			poX++;
			right = true;
		}
	}
	void gor() {
		if(up == false) {
			prejY = poY;
			prejX = poX;
			poY--;
			up = true;
		}
	}			
	void dol() {
		if(down == false) {
			prejY = poY;
			prejX = poX;
			poY++;
			down = true;
		}
	}
}
	