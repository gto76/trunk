

import java.text.DecimalFormat;
import java.util.EventObject;

import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Cell implements ChangeListener, DoubleChangedClassListener {

	/**
	 * Faktor s katerim se preslikava med vrednostjo cella in vrednostjo
	 * sliderja.
	 */
	public static final int FACTOR = InteractiveWeightTable.FACTOR;
    /**
     * Format izpisa vrednosti cella
     */
	public static final DecimalFormat df = new DecimalFormat("#.##");
	
	//HashBasedTable hbt;
	
	JSlider slider;
	JLabel label;
	JLabel nameLabel;
	MutableDouble value;
	
	public MutableDouble getValue() {
		return value;
	}

	public void setValue(MutableDouble value) {
		this.value = value;
	}

	Cell() {
		slider = new JSlider();
		label = new JLabel();
	}
	
	public Cell(JSlider slider, JLabel label, MutableDouble value, JLabel nameLabel) {
		this.slider = slider;
		this.label = label;
		this.value = value;
		this.nameLabel = nameLabel;
		
		InteractiveWeightTable.setMinMaxOfSlider(slider);;
		slider.setValue((int) (value.getValue()*FACTOR));
		slider.addChangeListener(this);
		
		value.addEventListener(this);
		
		sliderSays();
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		sliderSays();
	}

	@Override
	public void handleDoubleChangedClassEvent(EventObject e) {
		doubleSays();		
	}
	
	private void sliderSays() {
		int newValue = slider.getValue();
		Double newValueNormalised = (double)newValue/FACTOR;
        String formatedValue = df.format(newValueNormalised);
		label.setText(""+formatedValue);
		value.setValue(newValueNormalised);
	}

	private void doubleSays() {		
		double newValue = value.getValue();
		int newValueDeNormalised = (int)(newValue*FACTOR);
		slider.setValue(newValueDeNormalised);
        String formatedValue = df.format(newValue);
		label.setText(""+formatedValue);
	}
	

	
	public JSlider getSlider() {
		return slider;
	}
/*
	public void setSlider(JSlider slider) {
		this.slider = slider;
	}
*/
	public JLabel getLabel() {
		return label;
	}
	
	public JLabel getNameLabel() {
		return nameLabel;
	}
/*
	public void setPanel(JLabel label) {
		this.label = label;
	}
*/


	
}
