

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JSlider;


public class ExtendedInteractiveWeightTable extends InteractiveWeightTable {

	private static final boolean DEBUG = false;
	Map<Enum, HeaderCell> headersV;
	Map<Enum, HeaderCell> headersC;
	
	public ExtendedInteractiveWeightTable() {
		super();
		//Table<Visibility, Category, Double> influenceMatrix = super.getTable();
		//slidersAndLabels = createMatrix();
		headersV = setHeadersV();
		headersC = setHeadersC();
	}

	private Map<Visibility, HeaderCell> setHeadersV() {
		Map<Visibility, HeaderCell> out = new HashMap<Visibility, HeaderCell>();
		for (Visibility vis : Visibility.values()) {
			// Slider:
         	JSlider slider = new JSlider();	
         	// Label:
         	JLabel nameLabel = new JLabel(vis.toString().toUpperCase());

         	cells = super.getCells();
         	Map<SolrCoreEntities,Cell> cc = cells.row(vis);
         	Collection<Cell> ccc = cc.values();
         	if (DEBUG) _.p("Cells: "+ ccc);
			HeaderCell hc = new HeaderCell(slider, nameLabel, ccc);
			out.put(vis, hc);
		}
		return out;
	}
	
	private Map<SolrCoreEntities, HeaderCell> setHeadersC() {
		Map<SolrCoreEntities, HeaderCell> out = new HashMap<SolrCoreEntities, HeaderCell>();
		for (SolrCoreEntities cat : SolrCoreEntities.values()) {
			// Slider:
         	JSlider slider = new JSlider();	
         	// Label:
         	JLabel nameLabel = new JLabel(cat.toString().toUpperCase());

         	cells = super.getCells();
			HeaderCell hc = new HeaderCell(slider, nameLabel, cells.column(cat).values());
			out.put(cat, hc);
		}
		return out;
	}
	

	public JSlider getSlider(Visibility vis) {
		return headersV.get(vis).getSlider();
	}

	public JSlider getSlider(SolrCoreEntities cat) {
		return headersC.get(cat).getSlider();
	}
	
	public JLabel getNameLabel(Visibility vis) {
		return headersV.get(vis).getNameLabel();
	}

	public JLabel getNameLabel(SolrCoreEntities cat) {
		return headersC.get(cat).getNameLabel();
	}

}
