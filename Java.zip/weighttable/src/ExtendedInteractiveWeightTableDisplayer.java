

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;

import si.hekovnik.btw.Conf;
import si.hekovnik.btw._;
import si.hekovnik.btw.categories.Subject;
import si.hekovnik.btw.common.Random_;
import si.hekovnik.btw.db.DB_Subject;
import si.hekovnik.btw.db.DB_User;
import si.hekovnik.btw.subproject.solrj.MulticoreSearchAccumulate;
import si.hekovnik.btw.subproject.solrj.enums.SolrCoreEntities;
import si.hekovnik.btw.subproject.solrj.enums.Visibility;
import si.hekovnik.btw.subproject.solrj.util.SolrDocumentListUtil;
import si.hekovnik.btw.subproject.solrj.util.SwingTableFactory;

public class ExtendedInteractiveWeightTableDisplayer {
	
	static boolean DEBUG = true;
	public static void setDebug(boolean b) {
		DEBUG = b;
	}
	
	static int WINDOW_WIDTH = 900;
	static int WINDOW_HEIGHT = 600;
	static int MATRIX_WINDOW_WIDTH = 1130;
	static int MATRIX_WINDOW_HEIGHT = 430;

	private static final String BUTTON = "Apply";
		
		
	private JTextField textField;
	private JTable table;
	private JLabel status;
	private JScrollPane scrollPane;
	
	private JFrame mainFrame;
	private JFrame matrixFrame;

	private ExtendedInteractiveWeightTable influenceMatrix;
	
	private int rows;
	private int columns;
	
	
	public static void main(String[] args) {
		new ExtendedInteractiveWeightTableDisplayer();
	}

	public ExtendedInteractiveWeightTableDisplayer() {
		
		influenceMatrix = new ExtendedInteractiveWeightTable();
				
		//////////////////
		// MATRIX FRAME //
		//////////////////
		matrixFrame = new JFrame("Control Frame");
		matrixFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Matrix manipulator
        rows = influenceMatrix.getVisibilityCount()+1;
		columns = influenceMatrix.getCategoryCount()+1;
		
		GridLayout layout = new GridLayout(rows, columns);
		layout.setHgap(20);
        layout.setVgap(20);
		
		Container pane = new Container();
		pane.setLayout(layout);
		
		// 1: naslovna vrstica
		pane.add(new JPanel());
				
		for ( SolrCoreEntities cat : SolrCoreEntities.values() ) {
			JPanel p = new JPanel();
			JLabel nameLabel = influenceMatrix.getNameLabel(cat);
    		p.add(nameLabel);
    		JSlider slider = influenceMatrix.getSlider(cat);
    		p.add(slider);    		
    		pane.add(p);			
		}
		
		// 2: ostale vrstice
        for ( Visibility vis : Visibility.values() ) {
        	JPanel p = new JPanel();
			JLabel nameLabel = influenceMatrix.getNameLabel(vis);
    		p.add(nameLabel);
    		JSlider slider = influenceMatrix.getSlider(vis);
    		p.add(slider);    		
    		pane.add(p);			
    		
        	
        	for ( SolrCoreEntities cat : SolrCoreEntities.values() ) {
        		p = new JPanel();
        		nameLabel = influenceMatrix.getNameLabel(vis, cat);
        		p.add(nameLabel);        		
        		slider = influenceMatrix.getSlider(vis, cat);
        		p.add(slider);
        		JLabel label = influenceMatrix.getLabel(vis, cat);
        		p.add(label);        		
        		pane.add(p);
        	}
        }
		
        //superPane.add(pane);
        matrixFrame.add(pane, BorderLayout.CENTER);

        //matrixFrame.add(superPane);
        matrixFrame.setSize(MATRIX_WINDOW_WIDTH, MATRIX_WINDOW_HEIGHT);
		matrixFrame.setVisible(true);
	}

	

 
}
