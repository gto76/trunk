

import java.util.ArrayList;
import java.util.Collection;
import java.util.EventObject;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class HeaderCell implements DoubleChangedClassListener,
		ChangeListener {

	public static final int FACTOR = InteractiveWeightTable.FACTOR;

	private static final boolean DEBUG = false;
	
	//List<Cell> ccc;
	List<MutableDouble> values;

	JSlider slider;
	//JLabel label;
	JLabel nameLabel;
	MutableDouble value;

	private boolean ignoreEvents = false;
	
	
	public HeaderCell(JSlider slider, JLabel nameLabel, Collection<Cell> cells) {
		this.slider = slider;
		this.nameLabel = nameLabel;
		
		values = new ArrayList<MutableDouble>();
		addActionListeners(cells);

		value = new MutableDouble(getAvg());
		value.addEventListener(new DoubleChangedClassListener() {
			// value of this cell was changed
			@Override
			public void handleDoubleChangedClassEvent(EventObject e) {
				if (ignoreEvents) return;
				ignoreEvents = true;
				if (DEBUG) _.p("DoubleChanged Event Fired!!! : "+ e);
				valueSays();
				ignoreEvents = false;
			}
		});
		
		InteractiveWeightTable.setMinMaxOfSlider(slider);
		slider.setValue((int) (value.getValue()*FACTOR));
		slider.addChangeListener(this);
	}



	private void addActionListeners(Collection<Cell> ccc2) {
		if (DEBUG) _.p("\naddActionListeners: " + ccc2);
		for ( Cell c : ccc2 ) {
			MutableDouble md = c.getValue();
			values.add(md);
			if (DEBUG) _.p("New walue added to Header cell: " + values);
			md.addEventListener(this);
		}
	}

	// one of the doubles in row/column has changed
	@Override
	public void handleDoubleChangedClassEvent(EventObject e) {
		if (ignoreEvents) return;
		ignoreEvents = true;
		double avg = getAvg();
		value.setValue(avg);
		valueSays(); //NEW NEW NEW!!! TO_TEST
		ignoreEvents = false;
	}
	
	// slider was moved
	@Override
	public void stateChanged(ChangeEvent e) {
		if (ignoreEvents) return;
		ignoreEvents = true;
		if (DEBUG) _.p("StateChanged event fired by Slider :"+e);
		sliderSays();
		ignoreEvents = false;
	}
	
	protected void valueSays() {
		double newValue = value.getValue();//slider.getValue();
		double newValueDeNormalised = (double)newValue*FACTOR;
		slider.setValue((int)newValueDeNormalised);
	}
	
	private void sliderSays() {
		int newValue = slider.getValue();
		Double newValueNormalised = (double)newValue/FACTOR;
		value.setValue(newValueNormalised);
		setAll(newValueNormalised);
	}
	
	private void setAll(double a) {
		double sum = getSum();
		if (sum == 0) {
			sum = 0.01;
		}
		double constant = a * values.size() / sum;
		for (MutableDouble val : values) {
			double newValue = val.getValue() * constant;
			if (newValue > 1.0) {
				newValue = 1.0;
			}
			else if (newValue < 0.0) {
				newValue = 0.0;
			}
			val.setValue(newValue);
		}
	}
		
	private Double getSum() {
		if (values == null) {
			if (DEBUG) _.p("VALUES ARE NULL!!!");
			return null;
		}
		double sum = 0;
		for (MutableDouble val : values) {
			sum += val.getValue();
		}
		return sum;
	}

	private double getAvg() {
		if (values == null) {
			if (DEBUG) _.p("Values == null");
		}
		if (DEBUG) _.p("Called getAvg. Values: "+values);
		return getSum() / values.size();
	}

	public JSlider getSlider() {
		return slider;
	}

	public JLabel getNameLabel() {
		return nameLabel;
	}
}
