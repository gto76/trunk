

import javax.swing.JLabel;
import javax.swing.JSlider;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;


public class InteractiveWeightTable extends WeightTable {

	public static final int FACTOR = 100;
	public static final double MIN = 0;
	public static final double MAX = 1;
	
	Table<Visibility, SolrCoreEntities, Cell>  cells;
	
	protected Table<Visibility, SolrCoreEntities, Cell> getCells() {
		return cells;
	}

	public InteractiveWeightTable() {
		super();
		//Table<Visibility, Category, Double> influenceMatrix = super.getTable();
		cells = createMatrix();		
	}
	
	public JSlider getSlider(Visibility vis, SolrCoreEntities cat) {
		return cells.get(vis, cat).getSlider();
	}
	
	public JLabel getLabel(Visibility vis, SolrCoreEntities cat) {
		return cells.get(vis, cat).getLabel();
	}

	public JLabel getNameLabel(Visibility vis, SolrCoreEntities cat) {
		return cells.get(vis, cat).getNameLabel();
	}
	
	private Table<Visibility, SolrCoreEntities, Cell> createMatrix () {
	
		Table<Visibility, SolrCoreEntities, Cell> matrixOut = HashBasedTable.create();
	
		for (Visibility vis : Visibility.values()) {
			for (SolrCoreEntities cat : SolrCoreEntities.values()) {    	
				// Slider:
            	JSlider slider = new JSlider();
            	// Panel:
        		JLabel jl = new JLabel();
            	jl.setText("label");       	
            	            
            	MutableDouble value = super.getMutable(vis, cat);
        		JLabel nameLabel = new JLabel((vis.toString() +" "+
        										cat.toString()).toLowerCase());
        		
            	Cell sal = new Cell(slider, jl, value, nameLabel);
				matrixOut.put(vis, cat, sal);
			}
		}
		return matrixOut;
	}

	public static void setMinMaxOfSlider(JSlider slider) {
		slider.setMinimum((int)(MIN*FACTOR));
		slider.setMaximum((int)(MAX*FACTOR));
	}


}
