import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;


public class KaoNekTable<EnumX extends Enum<EnumX>> {
	
	@SuppressWarnings("unchecked")
	public void izpisiVseEnume() throws IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Class<EnumX> cls = (Class<EnumX>) 
				((ParameterizedType) 
						getClass().getGenericSuperclass()).getActualTypeArguments()[0];
		EnumX e = cls.getConstructor(String.class).newInstance("Gate");
		
		for (Enum<?> value : e.getClass().getEnumConstants()) {
			System.out.println(value);
		}
	}
}
