

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class WeightTable/*<RowEnum extends Enum<RowEnum>, Enum<?> extends Enum<Enum<?>>>*/ {

	public static final DecimalFormat df = new DecimalFormat("#.##");
	public static final double DEFAULT_VALUE = 1.0;
	private static final boolean DEBUG = false;
	
	
	Table<Enum<?>, Enum<?>, MutableDouble> weightTable = HashBasedTable.create();

	private Map<Enum<?>, MutableDouble> columnWeightMap = new HashMap<Enum<?>, MutableDouble>();
	private Map<Enum<?>, MutableDouble> rowWeightMap = new HashMap<Enum<?>, MutableDouble>();
	
	//private List<Enum<?>> columns;
	//private List<Enum<?>> rows;
	
	
	public WeightTable(List<Enum<?>> columns, List<Enum<?>> rows) {
		for (Enum<?> e : columns) {
			columnWeightMap.put(e, new MutableDouble(DEFAULT_VALUE));
		}
		for (Enum<?> e : rows) {
			rowWeightMap.put(e, new MutableDouble(DEFAULT_VALUE));
		}
		setTable();
	}
	
	private void setTable() {
		for (Enum<?> e : columnWeightMap.keySet()) {
			for (Enum<?> f : rowWeightMap.keySet()) {
				weightTable.put(e, f,  new MutableDouble(DEFAULT_VALUE));
			}
		}
	}
	

	// ################
	// ################
	// ################
	// ########### GET:

	public Double get(Enum<?> vis, Enum<?> cat) {
		MutableDouble mutableDouble = weightTable.get(vis, cat);
		if (DEBUG) System.out.println("muttable double = " + mutableDouble);
		if (mutableDouble == null) return 0.0;
		else return mutableDouble.getValue();		 
	}
	
	protected MutableDouble getMutable(Enum<?> vis, Enum<?> cat) {
		return weightTable.get(vis, cat);
	}

	public int getRowEnumCount() {
		 return weightTable.rowKeySet().size();
	}

	public int getCategoryCount() {
		return weightTable.columnKeySet().size();
	}


	// ################
	// ################
	// ################
	// ########### SET:

	/**
	 * Safest way to set fields.
	 */
	public void setFieldInfluence(Enum<?> cat, Enum<?> vis, double influence) {
		weightTable.put(vis, cat, new MutableDouble(influence));
	}
	
	

	/*
	public WeightTable() {
		initialize(false);
	}
	
	
	public WeightTable(boolean empty) {
		initialize(empty);
	}
	*/
	
	/*
	private void initialize(boolean empty) {
		if (!empty) {
			setDefaultCategoryWeightMap();
			setDefaultRowEnumWeightMap();
		}
		setInfluenceMatrixByMaxOfMaps();
	}
	*/
	
	//XXX: Vse te metode je treba se premislit
	/*
	public void setCategoryWeightMap(Map<Enum<?>, Double> categoryWeightMap) {
		this.columnWeightMap = categoryWeightMap;
		setInfluenceMatrixByMaxOfMaps();
	}
	public void setRowEnumWeightMap(Map<Enum<?>, Double> scopeWeightMap) {
		this.rowWeightMap = scopeWeightMap;
		setInfluenceMatrixByMaxOfMaps();
	}
	public void setRowEnumWeightMapAndUseProduct(Map<Enum<?>, Double> scopeWeightMap) {
		this.rowWeightMap = scopeWeightMap;
		setInfluenceMatrixByMultiplicationOfMaps();
	}
	public void setCategoryAndRowEnumWeightMap(Map<Enum<?>, Double> categoryWeightMap, Map<Enum<?>, Double> scopeWeightMap) {
		this.columnWeightMap = categoryWeightMap;
		this.rowWeightMap = scopeWeightMap;
		setInfluenceMatrixByMaxOfMaps();
	}
	// mal funky ker ne nasavi dveh mapov..
	private void setInfluenceMatrix(Table<Enum<?>, Enum<?>, MutableDouble> influenceMatrix) {
		this.influenceMatrix = influenceMatrix;
	}
	*/
	
	/*
	public void searchOnlyForColumns(Enum<?> ent) {
		for (Enum<?> vis : Enum<?>.values()) {
			RowEnumWeightMap.put(vis, DEFAULT_INF);
		}
		categoryWeightMap.clear();
		categoryWeightMap.put(ent, DEFAULT_INF);
		setInfluenceMatrixByMaxOfMaps();
	}
	
	public void searchOnlyForRows(Enum<?> vis) {
		for (Enum<?> c : Enum<?>.values()) {
			categoryWeightMap.put(c, DEFAULT_INF);
		}
		RowEnumWeightMap.clear();
		RowEnumWeightMap.put(vis, 1.0);
		setInfluenceMatrixByMaxOfMaps();
	}
	*/
	/*
	public void searchOnlyFor(Enum<?> cat, Enum<?> vis) {
		columnWeightMap.clear();
		columnWeightMap.put(cat, 1.0);
		rowWeightMap.clear();
		rowWeightMap.put(vis, 1.0);
		setInfluenceMatrixByMultiplicationOfMaps();
	}	
	*/
		
		
	//extends HashBasedTable<RowEnum, Category, Double> {

	/*
	InfluenceMatrix(
			Map<RowEnum, Map<Category, Double>> backingMap,
			com.google.common.collect.HashBasedTable.Factory<Category, Double> factory) {
		super(backingMap, factory);
		// TODO Auto-generated constructor stub
	}*/
	
	//Table<Vertex, Vertex, Double> weightedGraph = HashBasedTable.create();
	
	//Table<Aim, Aim, Aim> t;

	
	////////////
	// STATIC //
	////////////
	
	/**
	 * Returns Category influence map, mapping all existing categories 
	 * (as defined in Category enum) to double value of 1.0. 
	 */
	/*
	private void setDefaultCategoryWeightMap() {
		//categoryWeightMap.clear();
			
		for ( Entry<Enum<?>, Double> e : columnWeightMap.entrySet()) {
			e.setValue(DEFAULT_VALUE);
		}
	}
	*/
	
	/**
	 * Returns Scope influence map, mapping all existing scopes 
	 * (as defined in Scope enum) to double value of 1.0. 
	 */
	/*
	private void setDefaultRowEnumWeightMap() {
		for ( Entry<Enum<?>, Double> e : rowWeightMap.entrySet()) {
			e.setValue(DEFAULT_VALUE);
		}
	}
	*/
	
	/**
	 * Creates the influence matrix from category and scope influence maps (vectors).
	 * Value of each cell is the product of the column and row values.
	 */
	/*
	private void setInfluenceMatrixByMultiplicationOfMaps() {
		Aggreg aggreg = new Aggreg() {
			public double agg(Double d1, Double d2) {
				return d1 * d2;
			}
		};
		setInfluenceMatrix(aggreg);
	}
	*/
	
	/**
	 * Creates the influence matrix from category and scope influence maps (vectors).
	 * Value of each cell is max of the column and row values.
	 */
	/*
	private void setInfluenceMatrixByMaxOfMaps() {
		Aggreg aggreg = new Aggreg() {
			public double agg(Double d1, Double d2) {
				return Math.max(d1 , d2);
			}
		};
		setInfluenceMatrix(aggreg);
	}
	
	public interface Aggreg {
		public double agg(Double d1, Double d2);
	}
	*/
	/**
	 * Creates the influence matrix from category and scope influence maps (vectors).
	 * Value of each cell is the product of the column and row values.
	 */
	/*
	private void setInfluenceMatrix(Aggreg aggreg) {
		influenceMatrix.clear();
		for (Enum<?> scope : rowWeightMap.keySet()) {
			for (Enum<?> cat : columnWeightMap.keySet()) {
				// Multiplies the influence values of scope and category
				Double influenceValue = aggreg.agg( rowWeightMap.get(scope),
						columnWeightMap.get(cat) );
				if (DEBUG) System.out.println("INFLUENCE VALUE: "+influenceValue);
				MutableDouble ivMut = new MutableDouble(influenceValue);
				influenceMatrix.put(scope, cat, ivMut);
				if (DEBUG) System.out.println("just put: "+ivMut.getValue()+" in: "+scope+" "+cat);
				if (DEBUG) System.out.println("value is: "+influenceMatrix.get(scope, cat));
			}
		}
	}
	*/
	

	/*
	@Override
	public String toString() {
		//String out = "";
		StringBuffer sb = new StringBuffer();
		String t = "\t"; 
		sb.append(t);
		for (Enum<?> e : categoryWeightMap.keySet()) {
			sb.append(e + t);
		}
		/*
		for (Enum<?> cat : Enum<?>.values()) {
			if (cat.equals(Enum<?>.AIMS)) {
				sb.append(cat + t+t);
			} else {
				sb.append(cat + t);
			}
		}
		*/
		/*
		sb.append("\n");
		
		//NEW:
		for (Enum<?> e : categoryWeightMap.keySet()) {
			sb.append(e+t);
				
			enumsValues(Enum<?>.class);
			
			for (Enum<?> cat : Enum<?>.values()) {
				String val = df.format(get(vis, cat));
				sb.append(val+t+t);
			}
			sb.append("\n");
		}
		sb.append("\n");
		return "InfluenceMatrix: \n" + sb;
	}
	*/
	
	/*
	public Table<RowEnum, Category, Double> getTable() {
		return influenceMatrix;
	}
	 */
	
}
