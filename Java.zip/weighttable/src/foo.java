import java.lang.reflect.InvocationTargetException;


public class foo {
	
	enum EnumTest {
		TEST_ENA,
		TEST_DVA		
	}
	
	public static void main(String[] args) {
		//EnumTest testEna = EnumTest.TEST_ENA;
		//izpisiVseEnume(testEna);
		
		EnumTest e = EnumTest.TEST_ENA;
		EnumTest[] values = e.values();
		
		KaoNekTable t1 = new KaoNekTable<EnumTest>();
		System.out.println("Vsi enumi:");
		try {
			t1.izpisiVseEnume();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
