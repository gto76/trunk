Beyblade-script
===============
Bash scripts for extracting lines for specific character of the cartoon Beyblade.
