#Izpiše samo linije ki jih imaji LIKI!, ki so bili podani kot drugi, tretji,... argument.
#V prvem argumentu je ime datoteke scenarija

threeLinesBack=""
twoLinesBack=""
oneLineBack=""
line=""

foundFlag=false

while read -r lin
do
	threeLinesBack=$twoLinesBack
	twoLinesBack=$oneLineBack
	oneLineBack=$line
	line=$lin

	if $foundFlag; then
		foundFlag=false
		echo -e "$threeLinesBack\t $twoLinesBack\t $oneLineBack\t $line\t";		
	fi

	for arg in "$@"; do
		#if [[ "$arg" == "$line" ]]; then	
		if [ `echo "$line" | grep "$arg" | wc -l` -ne 0 ]; then
			foundFlag=true
		fi
	done

done < "$1"
