#Izpiše samo linije ki jih ima lik, ki je bil podan kot drugi argument.
#V prvem argumentu je ime datoteke scenarija


# grep -E "^[A-Z]+$"
# vrne samo vrstice z besedo iz samih velikih



threeLinesBack=""
twoLinesBack=""
oneLineBack=""
line=""

foundFlag=false

while read -r lin
do
	threeLinesBack=$twoLinesBack
	twoLinesBack=$oneLineBack
	oneLineBack=$line
	line=$lin

	if $foundFlag; then
		foundFlag=false
		echo "$name"		
		#echo -e "$threeLinesBack\t $twoLinesBack\t $oneLineBack\t $line\t";		
	fi
	
	name=`echo "$line" | grep -o -E "^[A-Z, ]+:" | sed 's/^\(.*\):$/\1/'`
	
	
#string="john_is_17_years_old"
#$ (IFS='_'; for word in $string; do echo "$word"; done)

	if [ "$name" != "" ]; then
		foundFlag=true		
#		for arg in "$@"; do
#			if [ "$arg" == "$name" ]; then	
#				foundFlag=false
#			fi
#		done
	fi

done < "$1"

