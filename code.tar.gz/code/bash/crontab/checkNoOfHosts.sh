#!/bin/bash
#Warns every user if someone else is on the network.
shopt -s expand_aliases
source /home/minerva/.bashrc

noOfHosts=`noh 10`
if [ $noOfHosts -gt 0 ]; then
	echo "You are not alone on network. There are $noOfHosts other entities." | wall
fi
