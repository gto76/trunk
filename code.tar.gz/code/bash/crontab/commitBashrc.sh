export SSH_AGENT_PID=`ps -e | grep ssh-agent | grep -o '[^0-9][0-9][0-9][0-9][0-9] ' | grep -o [0-9]*`
export SSH_AUTH_SOCK=`find /tmp/ -path '*keyring-*' -name '*ssh*' -print 2>/dev/null`
#Hack to get these two variables to cron bash session, so he can use ssh-agent to get passphrase of key

cd /home/minerva
#Try commiting to my home git repo, then also push to github.
git commit -am "Daily commit."
git push

