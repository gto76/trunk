Enyo-script
===========
Bash scripts for extracting lines for specific character of cartoon Enyo.
