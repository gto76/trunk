#Dobi imena vseh karakterjev

getNamesOfAllCharacters() {
	foundFlag=false
	while read -r line
	do
		if $foundFlag; then
			echo $line
			break
		fi

		if [[ "$line" == *Nastopajoči:* ]]; then
		  foundFlag=true
		fi
	done < "$1"
}

#Vsakega da v svojo vrstico,
#jih spremeni v velike crke in
#odstrani space
getNamesOfAllCharacters "$1" | tr ',' '\n' | tr '[a-z]' '[A-Z]' | sed -e 's/^[[:space:]]*//'
