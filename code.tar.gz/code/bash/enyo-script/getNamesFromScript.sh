
foundFlag=false

rm temp-33 &> /dev/null
touch temp-33

while read -r line
do
	name=`echo "$line" | grep -E "^[A-Z ]+$"`
	if [ "$name" != "" ]; then
		if [ "$name" != "NO DIALOGUE" ]; then
			echo "$name" >> temp-33
		fi
	fi
done < "$1"

sort temp-33 | uniq
rm temp-33 &> /dev/null
#rm temp-GetNamesFromScript &> /dev/null

