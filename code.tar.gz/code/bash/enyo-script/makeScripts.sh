#naredi folder imenovan po epizodi in v njega spravi za vsakega karakterja text posebi


tmp=${TMPDIR-/tmp}
	tmp=$tmp/somedir.$RANDOM.$RANDOM.$RANDOM.$$
	(umask 077 && mkdir $tmp) || {
		echo "Could not create temporary directory! Exiting." 1>&2 
		exit 1
	}

#array replik
#declare -a lineId
rm temp
rm temp2
rm temp3

pofockiVrstice() {
	vrstice=`echo "$1" | sed -n 's/\([[:digit:]]*[[:blank:]]\)\(.*$\)/\1/p' | sed -e 's/[^[:digit:]]*//'`
	#echo "$vrstice"

	echo "$vrstice" >> temp

	#SAVEIFS=$IFS
	#IFS=$(echo -en "\n\b")
	#for lineNum in $vrstice; do
	#	lineId[lineNum]=true
	#done
	#IFS=$SAVEIFS
}

#odstrani končnico iz fajla
dirName=${1%.*}

#convert from doc to txt
soffice --headless --convert-to txt:text "$1"
txtFileName="$dirName.txt"

#če dir ne obstaja ga naredi
if [ ! -d "$dirName" ]; then
	mkdir "$dirName"
fi

echo "episode name is: $dirName"
names=`./getNames.sh "$txtFileName"`

SAVEIFS=$IFS
IFS=$(echo -en "\n\b")
i=1
for name in $names; do
	IFS=$SAVEIFS

	echo "makeScriptName no $i is $name"
	let "i=$i+1"	
	skripta=`./getScriptFor.sh "$txtFileName" "$name"` 
	noOfLines=`echo "$skripta" | wc -l`	
	if [ $noOfLines -gt 1 ]; then
		pofockiVrstice "$skripta"
		echo "$skripta" > "$dirName"/"$dirName"-"$name".txt
	fi

	SAVEIFS=$IFS
	IFS=$(echo -en "\n\b")
done
IFS=$SAVEIFS

`cat temp | sed '/^$/d' | tr -d '\040\010\015' | sort -n -k 1 | uniq > temp2`

limit=`tail -2 temp2 | head -1`
echo "limit: $limit" 
for ((i=1; i<$limit; i++)); do
	if [ `grep "$i" temp2 | wc -l` -lt 1 ]; then
		#echo "$dirName"/temp3
		echo "$i" >> temp3	
	fi
done

mv temp3 "$dirName"/other

#grep -f temp3 temp2


#echo "IZPIS VRSTIC:"
#for vrst in $vrstice; do
#	echo "$vrst"
#done


