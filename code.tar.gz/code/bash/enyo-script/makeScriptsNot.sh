
for document in *.txt; do

	./getScriptNotFor.sh "$document" ENYO ODINA SHAMANI ITO AGAYA DAGOR CROWLER HUNGA MUNG "QUAG NAGA" "NO DIALOGUE"
> "hunga"-"$document"

doneq

