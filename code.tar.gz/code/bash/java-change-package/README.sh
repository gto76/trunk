Java-change-package
===================
Bash scripts that should change package declaration of all java files in the directory tree. Not 100% tested.
