for file in "$@"
do
	sed -i -e "1d" $file
	echo 'package si.gto76.javaphotoeditor' | cat - $file > temp && mv temp $file
done
