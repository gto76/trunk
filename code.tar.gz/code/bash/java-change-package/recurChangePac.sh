find . -name '*.java' | xargs ./changePackage.sh
