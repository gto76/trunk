int main() {
	int a = 5;
}
