#include<stdio.h>

int main() {
	int a = 5;
	printf("%d",a);
}
