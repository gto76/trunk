#include<stdio.h>

int main() {
	printf("%d", 5);
}
