int main() {
	asm("movl %ecx %eax"); 
}

