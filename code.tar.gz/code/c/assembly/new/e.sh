gcc Void.c
./a.out
