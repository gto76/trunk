//============================================================================
// Name        : cpp-test.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

// ask for a person's name, and greet the person
#include <iostream>
#include <string>
#include <vector>

int main() {

	int BOARD_SIZE = 3;
	std::vector<int> board;

	for (int i = 0; i < BOARD_SIZE; i++) {
		board.push_back(2);
	}

	std::cout << board[0];



	// ask for the person's name
//	std::cout << "Please enter your first name: ";
//	// read the name
//	std::string name;
//	std::cin >> name;
//	// define name
//	// read into
//	// write a greeting
//	std::cout << "Hello, " << name << "!" << std::endl;
	return 0;
}

