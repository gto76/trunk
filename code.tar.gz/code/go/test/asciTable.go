package main

func main() {
	for i:=2000; i<2500; i++ {
		print("\t\"" + string(i) + "\"\n", i)
		//print(string(i))
	}
}
