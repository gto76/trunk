package main

import (
	"time"
)
//CONSTRUCTOR
/*
func NewFile(fd int, name string) *File {
    if fd < 0 {
        return nil
    }
    f := File{fd, name, nil, 0}
    return &f
}
*/
var a = 0
var c chan int

func main() {
	c = make(chan int)
	go displayer()
	go rutina1()
	go rutina2()
	for { wait(1000) }
}

func rutina1() {
	for {
		a++
		c <- 1
		wait(140)
	}
	//go rutina1()
}

func rutina2() {
	for {
		a--
		c <- 1
		wait(150)
	}
	go rutina2()
}


func displayer() {
	<-c	
	print(a)
	go displayer()
}

func wait(sec int) {
	var ssec = time.Duration(sec*1000000)
	time.Sleep(ssec)
}

