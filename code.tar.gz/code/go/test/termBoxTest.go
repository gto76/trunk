//RUN WITH: go run hello.go
package main

import "github.com/nsf/termbox-go"

func main() {
    err := termbox.Init()
	if err != nil {
        panic(err)
	}
	defer termbox.Close()
	
	termbox.SetCell(10, 10, '@', 	termbox.ColorRed, 										termbox.ColorGreen)
	termbox.Flush()
	termbox.HideCursor()
z
loop:
	for {
		switch ev := termbox.PollEvent(); ev.Type {
		case termbox.EventKey:
			if ev.Key == termbox.KeyCtrlC {
				break loop
			}
		case termbox.EventError:
			panic(ev.Err)
		}	
	}

}
