common
======

My Java common.
