package si.gto76.common;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Test {
	/*
	private static final List<Method> methods = new ArrayList<Method>();
	
	public Test(List<Method> methods) {
		this.methods.addAll(methods);
	}
	
	public static boolean testAll() {
		boolean pass = true;
		for (Method m : methods) {
			try {
				if (!(boolean) m.invoke(null, null)) {
					_.p("TEST FAIL: "+m);
					pass = false;
				}
			} catch (IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return pass;
	}
	*/

}
