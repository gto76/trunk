package si.gto76.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.google.common.base.Charsets;
import com.google.common.base.Strings;
import com.google.common.io.Files;
import com.google.common.primitives.Chars;

public final class _ {
	private static final char[] separatorsCh = {'#','$','%','&','/','=','*','+','�','�','�','~',
			'\\','|','�','�','�','�','@'};
	private static final int SEPARATOR_LENGTH = 35;
	public static Random rand = new Random();
	
	/**
	 * System.out.println(o);
	 * @param o
	 */
	public static void p(Object o) {
		System.out.println(o);
	}
	
	public static void pp(Object o) {
		String className = getClassName(0);
		Character classSep = getSeparator(className);
		String methodName = getMethodName(0);
		Character methodSep = getSeparator(methodName);
		String allTogether = Strings.padStart("", 3, classSep) + " "
				+ className + "." + methodName + " ";
		allTogether = Strings.padEnd(allTogether, SEPARATOR_LENGTH, methodSep);
		System.out.println(allTogether+" :: "+o);
	}
	
	private static Character getSeparator(String source) {
		List<Character> separators = Chars.asList(separatorsCh);
		int hashCode = Math.abs(source.hashCode());
		int numOfSeparators = separators.size();
		
		int characterPosition = hashCode % numOfSeparators;
		return separators.get(characterPosition);
	}
		
	public static String getClassName()	{
		return getClassName(0);
	}
	private static String getClassName(final int depth)	{
		final StackTraceElement[] ste = getStackTraceElement();
		String longClassName = ste[ste.length - 2 - depth].getClassName();
		int beginIndex = longClassName.lastIndexOf('.');
		return longClassName.substring(beginIndex+1);
	}
	public static String getLongClassName()	{
		return getLongClassName(0);
	}
	private static String getLongClassName(final int depth)	{
		final StackTraceElement[] ste = getStackTraceElement();
		return ste[ste.length - 2 - depth].getClassName();
	}
	public static String getMethodName() {
		return getMethodName(0);
	}
	private static String getMethodName(final int depth)	{
		final StackTraceElement[] ste = getStackTraceElement();
		return ste[ste.length - 2 - depth].getMethodName(); //Thank you Tom Tresansky
	}
		
	public static StackTraceElement[] getStackTraceElement()	{
		return Thread.currentThread().getStackTrace();
	}
	
	public static List<Method> getDeclaredMethods() {
		String className = getLongClassName(-1);
		try {
			Class c = Class.forName(className);
			Method[] methods = c.getDeclaredMethods();
			return Arrays.asList(methods);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
       	return new ArrayList<>();
	}
	
	
	public static List<Method> removeMainMethod(List<Method> methods) {
		return removeMethod(methods, "main");
	}
	public static List<Method> removeMethod(List<Method> methods, String methodName) {
		List<Method> methodsOut = new ArrayList<>();
		for (Method m : methods) {
			String name = m.getName();
			if (!name.equals(methodName)) {
				methodsOut.add(m);
			}
		}
		return methodsOut;
	}

	
	public static String readFileAsString(String filePath)
	    throws java.io.IOException {
		String out = Files.toString(new File(filePath), Charsets.UTF_8);
		_.p(out);
		return out;
    }

	public static byte[] readFileAsBytes(String filePath)
	    throws java.io.IOException {
		return Files.toByteArray(new File(filePath));
    }
	
	public static void writeStringToFile(String string, String path) throws IOException {
		BufferedWriter writer = Files.newWriter(new File(path), Charsets.UTF_8);
		writer.append(string);
		writer.close();
	}
	
	public static void writeBytesToFile(byte[] data, String path) throws IOException {
		File file = new File(path);
		Files.write(data, file);
	}
	
	public static void makeDirs(String path) {
		File file = new File(path);
		file.mkdirs();
	}
	
	public static double devideSafely(double devidee, double devider) {
		if (devider == 0) return 0.0;
		return devidee / devider;
	}
	

	public static byte[] concat(byte[] in1, byte[] in2) {
		byte[] out = new byte[in1.length+in2.length];
		int i = 0;
		for (byte b : in1) {
			out[i++] = b;
		}
		for (byte b : in2) {
			out[i++] = b;
		}
		return out;
	}
	
}
