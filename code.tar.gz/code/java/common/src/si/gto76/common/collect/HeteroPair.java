package si.gto76.common.collect;

public class HeteroPair<X,Y> {

	private X x;
	private Y y;
	
	public HeteroPair(X x, Y y) {
		this.x = x;
		this.y = y;
	}
	public HeteroPair() {
	}
	
	public X getFirst() {
		return x;
	}
	public Y getSecond() {
		return y;
	}	
	
	public void setFirst(X x) {
		this.x = x;
	}
	public void setSecond(Y y) {
		this.y = y;
	}
	
	@Override
	public String toString() {
		return "HeteroPair [x=" + x + ", y=" + y + "]";
	}
	
}

