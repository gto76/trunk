package si.gto76.common.collect;

public class HomoPair<X> {
	
	private X x1;
	private X x2;
	
	public HomoPair(X x1, X x2) {
		this.x1 = x1;
		this.x2 = x2;
	}
	public HomoPair() {
	}
	
	public X getFirst() {
		return x1;
	}
	public X getSecond() {
		return x2;
	}

	public void setFirst(X x1) {
		this.x1 = x1;
	}
	public void setSecond(X x2) {
		this.x2 = x2;
	}
	
	@Override
	public String toString() {
		return "HomoPair [x1=" + x1 + ", x2=" + x2 + "]";
	}

}