package si.gto76.common.collect.mutabledouble;

	
public class DoubleChangedClass extends java.util.EventObject {
     
	private static final long serialVersionUID = 5532905698561632412L;

	//here's the constructor
    public DoubleChangedClass(Object source) {
        super(source);
    }
}


