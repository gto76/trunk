package si.gto76.common.collect.mutabledouble;


import java.util.EventObject;

public interface DoubleChangedClassListener {
    public void handleDoubleChangedClassEvent(EventObject e);

}
