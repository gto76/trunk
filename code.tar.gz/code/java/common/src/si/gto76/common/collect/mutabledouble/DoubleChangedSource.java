package si.gto76.common.collect.mutabledouble;


import java.util.ArrayList;
import java.util.List;



public class DoubleChangedSource {
	
  private List<DoubleChangedClassListener> _listeners = new ArrayList<DoubleChangedClassListener>();
  public synchronized void addEventListener(DoubleChangedClassListener listener)	{
    _listeners.add(listener);
  }
  public synchronized void removeEventListener(DoubleChangedClassListener listener)	{
    _listeners.remove(listener);
  }

  // call this method whenever you want to notify
  //the event listeners of the particular event
  /*
  private synchronized void fireEvent()	{
	  DoubleChangedClass event = new DoubleChangedClass(this);
	  Iterator<DoubleChangedClassListener> i = _listeners.iterator();
	  while(i.hasNext())	{
		 ( (DoubleChangedClassListener) i.next()).handleDoubleChangedClassEvent(event);
	  }
  }
  */
  

}






