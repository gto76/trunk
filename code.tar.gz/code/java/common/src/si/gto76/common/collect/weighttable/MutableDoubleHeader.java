package si.gto76.common.collect.weighttable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EventObject;
import java.util.List;

import si.gto76.common._;
import si.gto76.common.collect.mutabledouble.DoubleChangedClassListener;
import si.gto76.common.collect.mutabledouble.MutableDouble;

public class MutableDoubleHeader extends MutableDouble implements DoubleChangedClassListener {
	
	private static final boolean DEBUG = false;
	List<MutableDouble> values;
	
	private boolean ignoreEvents = false;
		
	public MutableDoubleHeader(Collection<MutableDouble> mmm) {
		super(WeightTable.DEFAULT_VALUE);
		values = new ArrayList<MutableDouble>(mmm);
		_.p("values: "+values);
		addActionListeners();
		set(getAvg());
	}
	
	private void addActionListeners() {
		if (DEBUG) _.p("\naddActionListeners: " + values);
		for ( MutableDouble m : values ) {
			m.addEventListener(this);
		}
		super.addEventListener(new DoubleChangedClassListener() {
			
			@Override
			public void handleDoubleChangedClassEvent(EventObject e) {
				// Nekdo je spremenil vrednost tega header cela.
				// Treba je na�timat vse podrejene Mutable Double:
				_.p("Nekdo je spremenil vrednost tega header cela.");
				setAll(get());
			}
		});
	}

	@Override
	public void handleDoubleChangedClassEvent(EventObject e) {
		if (ignoreEvents) return;
		ignoreEvents = true;
		double avg = getAvg();
		set(avg);
		ignoreEvents = false;
	}

	// ##
	// ## Util:
	// ##
	
	private void setAll(double a) {
		_.p("Set all z vrednostjo: "+a);
		double sum = getSum();
		_.p("sum je: "+sum);
		if (sum == 0) {
			sum = 0.01;
		}
		double constant = a * values.size() / sum;
		for (MutableDouble val : values) {
			double newValue = val.get() * constant;
			if (newValue > 1.0) {
				newValue = 1.0;
			}
			else if (newValue < 0.0) {
				newValue = 0.0;
			}
			val.set(newValue);
		}
	}
	
	private double getAvg() {
		if (values == null) {
			if (DEBUG) _.p("Values == null");
		}
		if (DEBUG) _.p("Called getAvg. Values: "+values);
		return getSum() / values.size();
	}

	private Double getSum() {
		if (values == null) {
			if (DEBUG) _.p("VALUES ARE NULL!!!");
			return null;
		}
		double sum = 0;
		for (MutableDouble val : values) {
			sum += val.get();
		}
		return sum;
	}

}
