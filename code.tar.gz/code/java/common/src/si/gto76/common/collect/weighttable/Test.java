package si.gto76.common.collect.weighttable;

import si.gto76.common._;


public class Test {

	enum Col {
		COL_1,
		COL_2,
		COL_3;
	}

	enum Row {
		ROW_1,
		ROW_2,
		ROW_3
	}
	
	public static void main(String[] args) {
		WeightTable wt = new WeightTable(Col.values(), Row.values());
		_.p(wt);
		//wt.set(Col.COL_1, Row.ROW_2, 0.5);
		/*
		_.p(wt);
		wt.setColumnHeaderValue(Col.COL_1, 0.2);
		_.p(wt);
		wt.set(Col.COL_3, Row.ROW_1, 0.63);
		_.p(wt);
		wt.setRowHeaderValue(Row.ROW_1, 0.2);
		_.p(wt);
		*/
	}
	
}
