package si.gto76.common.collect.weighttable;

import java.text.DecimalFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import si.gto76.common._;
import si.gto76.common.collect.mutabledouble.MutableDouble;
import si.gto76.common.strings.stringtable.StringTable;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class WeightTable {

	public static final double DEFAULT_VALUE = 1.0;
	private static final boolean DEBUG = false;
	public static final DecimalFormat df = new DecimalFormat("#.##");
	
	Table<Enum<?>, Enum<?>, MutableDouble> weightTable = HashBasedTable.create();

	private Map<Enum<?>, MutableDoubleHeader> columnHeaders = new HashMap<Enum<?>, MutableDoubleHeader>();
	private Map<Enum<?>, MutableDoubleHeader> rowHeaders = new HashMap<Enum<?>, MutableDoubleHeader>();
		
	
	public WeightTable(Enum<?>[] columns, Enum<?>[] rows) {
		// fill the cells:
		for (Enum<?> c : columns) {
			for (Enum<?> r : rows) {
				weightTable.put(c, r, new MutableDouble(DEFAULT_VALUE));
			}
		}
		
		// fill the headers:
		for ( Enum<?> c : weightTable.columnKeySet() ) {
			//Collection<MutableDouble> values = weightTable.row(r).values();
			Collection<MutableDouble> values = weightTable.column(c).values();
			
			_.p("##values: "+values);
			rowHeaders.put(c, new MutableDoubleHeader(values));
		}
		for ( Enum<?> r : weightTable.rowKeySet() ) {
			Collection<MutableDouble> values = weightTable.row(r).values();
			columnHeaders.put(r, new MutableDoubleHeader(values));
		}
		
	}
	
	// ################
	// ################
	// ########### GET:

	public Double get(Enum<?> c, Enum<?> r) {
		MutableDouble mutableDouble = weightTable.get(c, r);
		if (mutableDouble == null) return null;
		if (DEBUG) System.out.println("muttable double = " + mutableDouble);
		return mutableDouble.get();		 
	}
	
	protected MutableDouble getMutable(Enum<?> c, Enum<?> r) {
		return weightTable.get(c, r);
	}

	public int getColumnCount() {
		return weightTable.columnKeySet().size();
	}
	
	public int getRowCount() {
		 return weightTable.rowKeySet().size();
	}
	
	// ##
	
	public Double getColumnHeaderValue(Enum<?> c) {
		return columnHeaders.get(c).get();
	}
	
	public Double getRowHeaderValue(Enum<?> r) {
		return rowHeaders.get(r).get();
	}

	// ################
	// ################
	// ########### SET:

	public void set(Enum<?> c, Enum<?> r, double weight) {
		MutableDouble mutable = getMutable(c, r);
		mutable.set(weight);
	}

	// ##
	
	public void setColumnHeaderValue(Enum<?> c, double val) {
		columnHeaders.get(c).set(val);
	}
	
	public void setRowHeaderValue(Enum<?> r, double val) {
		rowHeaders.get(r).set(val);
	}

	// ################
	// ################
	// ##### TO STRING:
	
	public int colWidth = 15;
	
	@Override
	public String toString() {
		return toString(true, true);
	}
	
	public String toString(final boolean headerValues, final boolean borders) {
		StringTable st = new StringTable(columnHeaders.size()+1, colWidth);
		
		// Column headers:
		st.add(null, null);
		for (Enum<?> c : columnHeaders.keySet()) {
			if (headerValues == false) {
				st.add(c);
			} else {
				st.add(c.toString(), df.format(columnHeaders.get(c).get()));
			}
		}
		
		// Rows:
		for (Enum<?> r : rowHeaders.keySet()) {
			// Row header:
			if (headerValues == false) {
				st.add(r);
			} else {
				st.add(r.toString(), df.format(rowHeaders.get(r).get()));
			}
			
			// Row data:
			for (Enum<?> c : columnHeaders.keySet()) {
				Double double1 = get(c, r);
				if (double1 == null) double1 = -1.0;
				String val = df.format(double1);
				st.add(val);
			}
		}
		
		return "### WeightTable ###\n" + st.toString();
	}
	
	
}
