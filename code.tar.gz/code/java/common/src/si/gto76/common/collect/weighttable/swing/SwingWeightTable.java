package si.gto76.common.collect.weighttable.swing;

public class SwingWeightTable {

	// TODO: Narest se swing funkcionalnost.
}
