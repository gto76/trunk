package si.gto76.common.strings;

import java.util.List;

import com.google.common.primitives.Chars;

public final class StringUtil {

	// ##############################
	// ####### SHAVE THE CAT ########
	// ##############################
	
	// TODO: Narest da sta oba Object
	public static String shaveTheCat(int size) {
		return shaveTheCat(null, size);
	}
	public static String shaveTheCat(Object value, int size) {
		return shaveTheCat(null, value, size);
	}
	public static String shaveTheCat(String label, Object value, int size) {
		String separator = ": ";
		return shaveTheCat(label, value, size, separator);
	}
	public static String shaveTheCat(String label, Object value, int size, String separator) {
		return shaveTheCat(label, value, size, separator, Align.CENTER);
	}
	public static String shaveTheCat(String label, Object value, int size, String separator, Align align) {
		String out = "";
		String val = "";
		if (value != null) { val = value.toString(); }
		if (label != null) { out = label + separator + val;	}
		else { out = val; }
		
		int length = out.length();
		if (length >= size) {
			out = out.substring(0, size-3);
			out = out.concat("..");
		} else if (length < size) {
			int fora = size - length;
			for (int i = 0; i < fora; i++) {
				switch (align) {
					case LEFT:
						out = out.concat(" ");
						break;
					case CENTER:
						if (i % 2 == 0) {
							out = out.concat(" ");
						} else {
							out = " ".concat(out);
						}
						break;
					case RIGHT:
						out = " ".concat(out);
						break;
				}
				
			}
		}
		return out;
	}
	
	enum Align {
		LEFT,
		CENTER,
		RIGHT
	}
	
	public static List<Character> asListOfCharacters(String line) {
		List<Character> characterList = Chars.asList(line.toCharArray());
		return characterList;
	}
	
	public static String listOfCharactersAsString(List<Character> ccc) {
		String out = "";
		for (Character c : ccc) {
			out += c;
		}
		return out;		
	}
	
}
