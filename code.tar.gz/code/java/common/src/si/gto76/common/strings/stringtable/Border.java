package si.gto76.common.strings.stringtable;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class Border extends ArrayList<Line> {
	
	public Border(String... lines) {
		for (String stringLine : lines) {
			Line lineOut = new Line(stringLine);
			this.add(lineOut);
		}
	}
	
	public String toString(int width) {
		StringBuilder sb = new StringBuilder();
		
		for (Line line : this) {
			for (int i = 0; i < width; i++) {
				char c = line.getNext();
				sb.append(c);
			}
			sb.append('\n');
		}
		sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	
}
