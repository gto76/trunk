package si.gto76.common.strings.stringtable;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class Line extends ArrayList<Character> {
	private int position = 0;
	
	/*
	public Line() {
		this(0);
	}
	public Line(int position) {
		super();
		this.position = position;
	}
	 */
	
	public Line() {
		super();
	}
	
	public Line(String line) {
		super();
		for (char ch : line.toCharArray()) {
			this.add(ch);
		}
	}
	
	public Character getNext() {
		if (this.size() == 0) {	
			return null; 
		}
		if (position >= this.size()) {
			position = 0;
		}
		char out = this.get(position++);
		return out;
	}
	
	public String toString(int width) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < width; i++) {
			char c = this.getNext();
			sb.append(c);
		}
		return sb.toString();
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (char c : this) {
			sb.append(c);
		}
		return sb.toString();
	}
	
	/*
	@Override
	public String toString() {
		return String.valueOf(this.toArray());
	}
	*/
}
