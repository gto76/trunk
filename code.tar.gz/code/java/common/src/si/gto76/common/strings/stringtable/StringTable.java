package si.gto76.common.strings.stringtable;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import si.gto76.common._;
import si.gto76.common.collect.HeteroPair;
import si.gto76.common.strings.StringUtil;
import si.gto76.common.strings.stringtable.crosser.CutTroughCrosserVertical;

/**
 * Nice Text Table.
 * @author Jure Sorn
 * 
 *  TODO: Narest da so različni celli lahko različno poravnani. (columnHeader, RowHeader, columns..)
 *  TODO: Narest obrobo, horizontal margin.
 *  TODO: Narest še da je možen sprotni izpis. (flush())
 */
public class StringTable {

	private static final int DEFAULT_COLUMN_WIDTH = 15;
	private static final boolean DEBUG = true;
	private final TableStyle style = new TableStyle(12, new Border("1", "2", "3"),
					new Border("A", "B"),
					new Border("|"),
					new Border("-"),
					CutTroughCrosserVertical.class,
					CutTroughCrosserVertical.class,
					CutTroughCrosserVertical.class,
					CutTroughCrosserVertical.class,
					": ",
					" ");
	
	private final int noOfColumns;
	private final List<Integer> columnWidths;
	private final List<HeteroPair<String, Object>> cells =
		new ArrayList<HeteroPair<String, Object>>(); // (String label, Object value)
	
	private StringBuilder sb;

	
 	// ######################
	// #### CONSTRUCTORS ####
	// ######################
	public StringTable(int noOfColumns) {
		this(noOfColumns, DEFAULT_COLUMN_WIDTH);
	}
	public StringTable(int noOfColumns,	int columnWidth) {
		this(createColumnWidths(columnWidth, noOfColumns));
	}
	public StringTable(List<Integer> columnWidths) {
		this.noOfColumns = columnWidths.size();
		this.columnWidths = columnWidths;
	}
	
	
	// #################
	// #### GET/SET ####
	// #################
	public void add(String label, Object value) {
		HeteroPair<String, Object> in = new HeteroPair<String, Object>(label, value);
		cells.add(in);
	}
	public void add(Object value) {
		add(null, value);
	}
	public void add() {
		add(null, null);
	}
	/* Move to TableStyle
	public int getWidth() {
		int width = 0;
		for (int colWidth : columnWidths) {
			width += colWidth + (2*ts.getMargin().length());
			if (ts.ts.hasBorders()) {
				width += vBorder.length();
			} 
		}
		//if (ts.hasBorders()) { width -= vBorder.length(); }
		return width;
	}
	*/
	
	
	// ###################
	// #### TO STRING ####
	// ###################
	@Override
	public String toString() {
		sb = new StringBuilder();
		Iterator<HeteroPair<String, Object>> it = cells.iterator();
		
		for (int i=0; i<cells.size(); i++) {
			int colNumber = i%noOfColumns;
			int rowNumber = i/noOfColumns;

			appendCell(it, columnWidths.get(colNumber));
			appendVerticalBorder(colNumber);
			
			// End of line:
			if (colNumber == noOfColumns-1) {
				append("\n");
				appendHorizontalBorder(rowNumber);
			}
						
		}
		return sb.toString();
	}
	
	private void append(Object o) {
		if (DEBUG) System.out.print(o);
		sb.append(o);
	}

	private void appendCell(Iterator<HeteroPair<String, Object>> it, int columnWidth) {
		append(style.getMargin());
		append(createCell(it.next(), columnWidth));
		append(style.getMargin());
	}

	private void appendVerticalBorder(int colNumber) {
		Headerness head = Headerness.getFromColumnNumber(colNumber);
		BorderType type = BorderType.get(Orientation.VERTICAL, head);
		Border border = style.getBorder(type);
		
		for (Line line : border) {
			char c = line.getNext();
			append(""+c); //CHAR!!
		}
	}
	
	private void appendHorizontalBorder(int rowNumber) {
		if (!style.hasBorders()) {
			return;
		}
		// is header border:
		Headerness head = Headerness.getFromRowNumber(rowNumber);
		style.getHorizontalBorderAsString(columnWidths, head);
	}
	
	private String createCell(HeteroPair<String, Object> pair, int columnWidth) {
		return StringUtil.shaveTheCat(pair.getFirst(), pair.getSecond(), columnWidth, style.getSeparator().toString());
	}


	// ##############
	// #### UTIL ####
	// ##############
	private static List<Integer> createColumnWidths(int columnWidth, int noOfColumns) {
		List<Integer> out = new ArrayList<Integer>(noOfColumns);
		for (int i = noOfColumns; i > 0; i--) {
			out.add(columnWidth);
		}
		return out;
	}


	// ###############
	// #### ENUMS ####
	// ###############
	public enum Orientation {
		VERTICAL,
		HORIZONTAL
	}
	
	public enum Headerness {
		HEADER,
		NON_HEADER
		;;;;
		public static Headerness getFromRowNumber(int rowNumber) {
			return getFromColumnNumber(rowNumber);
		}
		public static Headerness getFromColumnNumber(int colNumber) {
			if (colNumber == 0) {
				return HEADER;
			} else {
				return NON_HEADER;
			}
		}
	}
	
	public enum BorderType {
		VERTICAL_HEADER(Orientation.VERTICAL, Headerness.HEADER),
		HORIZONTAL_HEADER(Orientation.HORIZONTAL, Headerness.HEADER),
		VERTICAL_NON_HEADER(Orientation.VERTICAL, Headerness.NON_HEADER),
		HORIZONTAL_NON_HEADER(Orientation.HORIZONTAL, Headerness.NON_HEADER)
		;;;;;;;;
		Orientation orientation;
		Headerness headerness;
		
		private BorderType(Orientation orientation, Headerness headerness) {
			this.orientation = orientation;
			this.headerness = headerness;
		}
		
		public Orientation getOrientation() {
			return orientation;
		}
		public Headerness getHeaderness() {
			return headerness;
		}

		// ## LOOKUP:
		private static final Table<Orientation, Headerness, BorderType> typesLookup = HashBasedTable.create();
		static {
			for(BorderType type : EnumSet.allOf(BorderType.class)) {
				typesLookup.put(type.getOrientation(), type.getHeaderness(), type);
		    }
		}
		public static BorderType get(Orientation orientation, Headerness headerness) {
			return typesLookup.get(orientation, headerness);
		}
		
	}

	
}

