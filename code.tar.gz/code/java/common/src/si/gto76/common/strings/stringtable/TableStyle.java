package si.gto76.common.strings.stringtable;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import si.gto76.common._;
import si.gto76.common.strings.StringUtil;
import si.gto76.common.strings.stringtable.StringTable.BorderType;
import si.gto76.common.strings.stringtable.StringTable.Headerness;
import si.gto76.common.strings.stringtable.StringTable.Orientation;
import si.gto76.common.strings.stringtable.crosser.Crosser;
import si.gto76.common.strings.stringtable.crosser.CutTroughCrosserVertical;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class TableStyle {
	
	public enum TableStyleEnum {
		NICE(12, new Border("1", "2", "3"),
				new Border("A", "B"),
				new Border("|"),
				new Border("-"),
				CutTroughCrosserVertical.class,
				CutTroughCrosserVertical.class,
				CutTroughCrosserVertical.class,
				CutTroughCrosserVertical.class,
				": ", 
				" ")
		;;;;;;;
		private TableStyle ts;
		
		private TableStyleEnum(int defaultColumnWidth, 
				Border vHeadBorder,	Border hHeadBorder, Border vBorder,	Border hBorder,
				Class<? extends Crosser> headHeadCrosser, Class<? extends Crosser> hHeadVcrosser, 
				Class<? extends Crosser> VHeadHcrosser, Class<? extends Crosser> VHcrosser,
				String separator, String margin) {
			ts = new TableStyle(defaultColumnWidth, vHeadBorder, hHeadBorder, vBorder,	hBorder,
					headHeadCrosser, hHeadVcrosser, VHeadHcrosser, VHcrosser, separator, margin);
		}
		public TableStyle get() {
			return ts;
		}
	}
	
	private final int defaultColumnWidth;
	private final Map<BorderType, Border> borders = new HashMap<>();
	private final Table<BorderType, BorderType, Crosser> crossers = HashBasedTable.create();
	// Probably here should (also) be Table<Border, Border, Crosser>
	private final List<Character> separator;
	private final List<Character> margin;
	private final boolean hasBorders;
	
	List<Integer> columnWidths;
	private StringBuilder sb;
	
	
	//////////
	// INIT //
	//////////
	public TableStyle(int defaultColumnWidth, 
			Border vHeadBorder,	Border hHeadBorder, Border vBorder,	Border hBorder,
			Class<? extends Crosser> headHeadCrosser, Class<? extends Crosser> hHeadVcrosser, 
			Class<? extends Crosser> VHeadHcrosser, Class<? extends Crosser> VHcrosser,
			String separator, String margin) {
		this.defaultColumnWidth = defaultColumnWidth;
		borders.put(BorderType.VERTICAL_HEADER, vHeadBorder);
		borders.put(BorderType.HORIZONTAL_HEADER, hHeadBorder);
		borders.put(BorderType.VERTICAL_NON_HEADER, vBorder);
		borders.put(BorderType.HORIZONTAL_NON_HEADER, hBorder);

		addCrosser(BorderType.HORIZONTAL_HEADER, BorderType.VERTICAL_HEADER, headHeadCrosser);
		addCrosser(BorderType.HORIZONTAL_HEADER, BorderType.VERTICAL_NON_HEADER, hHeadVcrosser);
		addCrosser(BorderType.HORIZONTAL_NON_HEADER, BorderType.VERTICAL_HEADER, VHeadHcrosser);
		addCrosser(BorderType.HORIZONTAL_NON_HEADER, BorderType.VERTICAL_NON_HEADER, VHcrosser);
		
		this.separator =  StringUtil.asListOfCharacters(separator);
		this.margin = StringUtil.asListOfCharacters(margin);
		hasBorders = bordersCheck();
	}
	
	private void addCrosser(BorderType borTyp1, BorderType borTyp2, Class<? extends Crosser> crosserClass) {
		try {
			createAndPutCrosser(borTyp1, borTyp2, crosserClass);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void createAndPutCrosser(BorderType borTyp1, BorderType borTyp2, Class<? extends Crosser> crosserClass) 
			throws InstantiationException, IllegalAccessException, IllegalArgumentException, 
			InvocationTargetException, NoSuchMethodException, SecurityException {
		@SuppressWarnings("unchecked")
		Constructor<Crosser> crosserConstructor = (Constructor<Crosser>) crosserClass.getConstructor(Border.class, Border.class);
		Crosser crosserOut = (Crosser) crosserConstructor.newInstance(borders.get(borTyp1), borders.get(borTyp2));
		crossers.put(borTyp1, borTyp2, crosserOut);
	}
	
	private boolean bordersCheck() {
		for (Border border : borders.values()) {
			for (Line line : border) {
				if (!line.isEmpty()) {
					return true;
				}	
			}
		}
		return false;
	}

	
	/////////////
	// GETTERS //
	/////////////
	public int getDefaultColumnWidth() {
		return defaultColumnWidth;
	}
	public Border getBorder(BorderType bType) {
		return borders.get(bType);
	}
	public Border getBorder(Orientation ori, Headerness hea) {
		return borders.get(BorderType.get(ori, hea));
	}
	public String getSeparator() {
		return StringUtil.listOfCharactersAsString(separator);
	}
	public String getMargin() {
		return StringUtil.listOfCharactersAsString(margin);
	}
	public boolean hasBorders() {
		return hasBorders;
	}

	
	/////////////////
	// MAIN GETTER //
	/////////////////
	public String getHorizontalBorderAsString(List<Integer> columnWidths, Headerness headerness) {
		sb = new StringBuilder();
		this.columnWidths = columnWidths;
		Border horizontalBorderPatterns = getBorder(Orientation.HORIZONTAL, headerness);

		int borderRowNum = 0;
		for (Line stripePattern : horizontalBorderPatterns) {
			appendOneLineOfBorder(stripePattern, headerness, borderRowNum);
			borderRowNum++;
		}
		
		return sb.toString();
	}

	private void appendOneLineOfBorder(Line stripePattern, Headerness headerness, int borderRowNum) {
		int colNum = 0;
		for (int colWidth : columnWidths) {
			// ### CELL:
			appendCell(colWidth, stripePattern);
			_.p(sb);
			// ### CROSS:
			appendStripeCrossing(colNum++, headerness, borderRowNum);
			_.p(sb);
		}
		sb.append("\n");
	}

	private void appendCell(int colWidth, Line stripePattern) {
		int marginWidth = 2*margin.size();
		int cellWidth = colWidth + marginWidth;
		sb.append(stripePattern.toString(cellWidth));
		/* EX:
		for (int i=0; i < cellWidth; i++) {
			sb.append(stripePattern.getNext());
		}
		*/
	}

	private void appendStripeCrossing(int colNumber, 
			Headerness horizontalBorderHeaderness, int bordersRowNumber) {
		
		Headerness verticalBorderHeaderness = Headerness.getFromColumnNumber(colNumber);
		BorderType borderType = BorderType.get(Orientation.VERTICAL, verticalBorderHeaderness);
		Border cross = getCross(BorderType.get(Orientation.HORIZONTAL, horizontalBorderHeaderness),
				borderType);
		
		//_.p(cross);
		
		Line crossLine = cross.get(bordersRowNumber);
		sb.append(crossLine.toString());
		
	}

	private Border getCross(BorderType bType1, BorderType bType2) {
		Crosser crosser = crossers.get(bType1, bType2);
		return crosser.getCross();
	}

}
