package si.gto76.common.strings.stringtable.crosser;

import java.util.HashMap;
import java.util.Map;

import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.StringTable.Orientation;

public abstract class Crosser {
	
	protected Map<Orientation, Border> borders =
			new HashMap<Orientation, Border>();
	
	public Crosser(Border verticalBorder, Border horizontalBorder) {
		borders.put(Orientation.VERTICAL, verticalBorder);
		borders.put(Orientation.HORIZONTAL, horizontalBorder);
	}

	public abstract Border getCross();
	public String toString() {
		return getCross().toString();
	}
}
