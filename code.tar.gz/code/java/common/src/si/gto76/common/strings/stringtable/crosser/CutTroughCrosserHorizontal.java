package si.gto76.common.strings.stringtable.crosser;

import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.Line;
import si.gto76.common.strings.stringtable.StringTable.Orientation;

public class CutTroughCrosserHorizontal extends Crosser {
	
	public CutTroughCrosserHorizontal(Border verticalBorder, Border horizontalBorder) {
		super(verticalBorder, horizontalBorder);
	}

	@Override
	public Border getCross() {
		Border outBor = new Border();
		Border horBor = borders.get(Orientation.HORIZONTAL);
		Border verBor = borders.get(Orientation.VERTICAL);
		
		for (Line line : horBor) {
			Line outLine = new Line();
			for (int i=0; i<verBor.size(); i++) {
				outLine.add(line.getNext());
			}
			outBor.add(outLine);
		}
		return outBor;
	}

}
