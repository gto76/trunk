package si.gto76.common.strings.stringtable.crosser;

import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.Line;
import si.gto76.common.strings.stringtable.StringTable.Orientation;

public class CutTroughCrosserVertical extends Crosser {
	
	public CutTroughCrosserVertical(Border verticalBorder, Border horizontalBorder) {
		super(verticalBorder, horizontalBorder);
	}

	@Override
	public Border getCross() {
		Border outBor = new Border();
		Border horBor = borders.get(Orientation.HORIZONTAL);
		Border verBor = borders.get(Orientation.VERTICAL);
		
		for (int i=0; i<horBor.size(); i++) {
			Line outLine = new Line();
			for (Line line : verBor) {
				outLine.add(line.getNext());
			}
			outBor.add(outLine);
		}
		return outBor;
	}
	
}
