package si.gto76.common.strings.stringtable.crosser.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import si.gto76.common._;
import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.crosser.Crosser;
import si.gto76.common.strings.stringtable.crosser.CutTroughCrosserHorizontal;
import si.gto76.common.strings.stringtable.crosser.CutTroughCrosserVertical;

public class CrosserTests {
	
	public static void main(String[] args) {
		Class<?> cl = CrosserTests.class;
		Result res = JUnitCore.runClasses(cl);
		_.p(res.wasSuccessful());
	}
	
    private Border verticalBorder;
	private Border horizontalBorder;
    
    @Before public void setUp() { 
        verticalBorder = new Border("1", "2");
    	horizontalBorder = new Border("A", "B");
    }
	
	@Test public void testCutTroughCrosserHorizontal() {
		//[[A, A], [B, B]]
		Crosser crosser = new CutTroughCrosserHorizontal(verticalBorder, horizontalBorder);
		Border cross = crosser.getCross();
		Border expectedCross = new Border("AA","BB");
		assertTrue(cross.equals(expectedCross));
	}

	@Test public void testCutTroughCrosserVertical() {
		//[[1, 2], [1, 2]]
		Crosser crosser = new CutTroughCrosserVertical(verticalBorder, horizontalBorder);
		Border cross = crosser.getCross();
		Border expectedCross = new Border("12","12");
		assertTrue(cross.equals(expectedCross));
	}
	
	
}
