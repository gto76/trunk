package si.gto76.common.strings.stringtable.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ BorderTest.class, LineTest.class })
public class AllTests {

}
