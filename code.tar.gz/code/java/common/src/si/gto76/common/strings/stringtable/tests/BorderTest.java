package si.gto76.common.strings.stringtable.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import si.gto76.common._;
import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.Line;

public class BorderTest {
	
	@Test
	public void test() {
		Border b = new Border("1234","abc","xy");
		int width = 15;
		String expectedBorder = "123412341234123\nabcabcabcabcabc\nxyxyxyxyxyxyxyx";
		String border = b.toString(width);
		assertTrue(border.equals(expectedBorder));
	}

}
