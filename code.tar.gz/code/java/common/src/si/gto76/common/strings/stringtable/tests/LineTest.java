package si.gto76.common.strings.stringtable.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import si.gto76.common._;
import si.gto76.common.strings.stringtable.Line;

public class LineTest {

	@Test
	public void test() {
		Line line = new Line("123");
		int width = 15;
		String expectedLine = "123123123123123";
		String sLine = line.toString(width);
		assertTrue(sLine.equals(expectedLine));
	}

}
