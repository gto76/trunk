package si.gto76.common.strings.stringtable.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import si.gto76.common._;

import si.gto76.common.strings.stringtable.StringTable;
import si.gto76.common.strings.stringtable.StringTable.Headerness;
import si.gto76.common.strings.stringtable.TableStyle;
import si.gto76.common.strings.stringtable.TableStyle.TableStyleEnum;

public class StringTableTests {
	
	public static void main(String[] args) {
		test2();
		
	}

	public static void test1() {
		_.pp("Creating new StringTable");
		StringTable st = new StringTable(4);

		_.pp("Populating StringTable");
		final int NO_OF_CELLS = 10;
		for (int i=0; i<NO_OF_CELLS; i++) {
			st.add("cell "+i);
		}
		
		_.pp("Printing StringTable");
		_.p(st);
	}
	
	public static void test2() {
		TableStyle ts = TableStyleEnum.NICE.get();
		
		List<Integer> columnWidths = new ArrayList<>(Arrays.asList(1,2));
		_.pp(columnWidths);
		String horizontalBorder = ts.getHorizontalBorderAsString(columnWidths, Headerness.HEADER);
		_.pp(horizontalBorder);
	}
	
}
