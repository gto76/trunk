package si.gto76.common.strings.stringtable.tests;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import si.gto76.common._;
import si.gto76.common.strings.stringtable.Border;
import si.gto76.common.strings.stringtable.StringTable.Headerness;
import si.gto76.common.strings.stringtable.TableStyle;
import si.gto76.common.strings.stringtable.crosser.CutTroughCrosserVertical;

public class TableStyleTest {
	
	public static void main(String[] args) {
		TableStyleTest t = new TableStyleTest();
		t.testGetHorizontalBorder();
	}

	@Test
	public void testGetHorizontalBorder() {
		TableStyle ts = new TableStyle(12, new Border("1", "2", "3"),
		new Border("A", "B"),
		new Border("|"),
		new Border("-"),
		CutTroughCrosserVertical.class,
		CutTroughCrosserVertical.class,
		CutTroughCrosserVertical.class,
		CutTroughCrosserVertical.class,
		": ", 
		" ");
		
		
		List<Integer> columnWidths = Arrays.asList(6,6,6,6);
		String horizontalBorder = ts.getHorizontalBorderAsString(columnWidths, Headerness.HEADER);
		
		_.p(horizontalBorder);
		
	}

}
