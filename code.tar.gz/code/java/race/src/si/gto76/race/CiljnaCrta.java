package si.gto76.race;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

class CiljnaCrta extends Objekt {
	CiljnaCrta (int x, int y) {
		super(x, y, '|', false);
	}
}
	
