package si.gto76.race;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="Race" width=655 height=485>
</applet>
*/

class Mina extends Objekt {
	Mina (int x, int y) {
		super(x, y, '*', true);
	}
}

/****************RAZRED RACE*********************/
public class Race extends Applet implements KeyListener{

	static Stevilo[] st = new Stevilo[10];
	static Vector zd = new Vector(1000);

	Color black = new Color(0,0,0);
	Color white = new Color(255,255,255);

	final int sirina = 80, visina = 25;
	private int krog = 2, faza = 0;
	private int w, h;
	private int players = 2;
	Image buffer = null;
	boolean solo = true;
	long time = System.currentTimeMillis();
	int speed = 200;

/**********************INIT**********************/
	public void init() {

	 	Font f = new Font("Dialoginput", Font.PLAIN, 14);
		setFont(f);
		addKeyListener(this);
		requestFocus(); //Za tipke

		//Double Buffer
		Dimension d = getSize();
		w = d.width;
		h = d.height;
		buffer = createImage(w, h);

	}


/********************PAINT***********************/
	public void paint(Graphics g) {
		//double buffer
		Graphics screengc = null;
		screengc = g;
		g = buffer.getGraphics();

		g.setColor(new Color(0,0,0));
		g.fillRect(0,0,700,400);
		g.setColor(new Color(255,255,255));


		if (faza == 0)
			meni(g);

		if (faza == 1)
			proga(g);

		if (faza == 2)
			proga(g);

		screengc.drawImage(buffer, 0, 0, null);
	}



/*******************KEYBAORD*********************/
	public void keyPressed(KeyEvent ke)
	{

		int key = ke.getKeyCode();
		Graphics g = getGraphics();

		if (faza == 0)  //Meni
		{
			switch(key) {
				case KeyEvent.VK_LEFT:
					if( players > 1 ) {
						players--;
						meni(g);
					}
					break;
				case KeyEvent.VK_RIGHT:
					if( players < 3 ) {
						players++;
						meni(g);
					}
					break;
				case KeyEvent.VK_DOWN:
					if( players > 1 ) {
						players--;
						meni(g);
					}
					break;
				case KeyEvent.VK_UP:
					if( players < 3 ) {
						players++;
						meni(g);
					}
					break;
				case KeyEvent.VK_S:
					if( players < 3 ) {
						if ( solo == false ) {
							solo = true;
						} else {
							solo = false;
						}
						meni(g);
					}
					break;

				case KeyEvent.VK_ENTER:
					narediStevila();
					narediProgo();
					faza = 1;
					paint(g);
					odstevanje();


					break;
			}
		}



		if (faza == 1)  //Odstevanje
		{
			switch(key) {
				case KeyEvent.VK_LEFT:
					break;
				case KeyEvent.VK_RIGHT:
					prehitriStart(1);
					break;
				case KeyEvent.VK_UP:
					break;
				case KeyEvent.VK_DOWN:
					break;
				case KeyEvent.VK_ESCAPE:
					faza = 0;
					paint(g);
					break;

			}
			if ( players == 2 ) {
				char key2 = ke.getKeyChar();
				switch(key2) {
					case 'a':
						break;
					case 'd':
						prehitriStart(2);
						break;
					case 'w':
						break;
					case 's':
						break;
				}
			}

			if ( players == 3 ) {
				char key3 = ke.getKeyChar();
				switch(key3) {
					case 'h':
						break;
					case 'k':
						prehitriStart(3);
						break;
					case 'u':
						break;
					case 'j':
						break;
				}
			}
		}



		if (faza == 2)  //Igra
		{
/*
			if ( solo == true ) {
				if ( System.currentTimeMillis() > time + speed ) {
					time = System.currentTimeMillis();
					if ( players == 2 ) {
						st[1].desno();
					}
				}
			}
*/


			switch(key) {
				case KeyEvent.VK_LEFT:

						if (!Race.isSolidObjectOnSpot(st[0].poX-1, st[0].poY)) {
						if( !((st[0].poY >= (int)(visina*2/3)) &
							(st[0].poX == (int)(sirina/2)+1)) )  //Da ne more it nazaj cez cilj
						st[0].levo();
						break;
						}
				case KeyEvent.VK_RIGHT:

					if (!Race.isSolidObjectOnSpot(st[0].poX+1, st[0].poY)) {
					st[0].desno();
					break;
					}
				case KeyEvent.VK_UP:

					if (!Race.isSolidObjectOnSpot(st[0].poX, st[0].poY-1)) {
					st[0].gor();
					break;
					}
				case KeyEvent.VK_DOWN:

					if (!Race.isSolidObjectOnSpot(st[0].poX, st[0].poY+1)) {
					st[0].dol();
					break;
					}
				
				case KeyEvent.VK_ESCAPE:
				{
					faza = 0;
					paint(g);
					break;
				}
				
			}
			if ( players == 2 ) {
				char key2 = ke.getKeyChar();
				switch(key2) {
					case 'a':
						if (!Race.isSolidObjectOnSpot(st[1].poX-1, st[1].poY)) {
							if( !((st[1].poY >= (int)(visina*2/3)) &
								(st[1].poX == (int)(sirina/2)+1)) )
							st[1].levo();
							break;
						}
					case 'A':

						if (!Race.isSolidObjectOnSpot(st[1].poX-1, st[1].poY)) {
							if( !((st[1].poY >= (int)(visina*2/3)) &
								(st[1].poX == (int)(sirina/2)+1)) )
							st[1].levo();
							break;
						}
					case 'd':

						if (!Race.isSolidObjectOnSpot(st[1].poX+1, st[1].poY)) {
						st[1].desno();
						break;
						}
					case 'D':

						if (!Race.isSolidObjectOnSpot(st[1].poX+1, st[1].poY)) {
						st[1].desno();
						break;
						}
					case 'w':

						if (!Race.isSolidObjectOnSpot(st[1].poX, st[1].poY-1)) {
						st[1].gor();
						break;
						}
					case 'W':

						if (!Race.isSolidObjectOnSpot(st[1].poX, st[1].poY-1)) {
						st[1].gor();
						break;
						}
					case 's':

						if (!Race.isSolidObjectOnSpot(st[1].poX, st[1].poY+1)) {
						st[1].dol();
						break;
						}
					case 'S':

						if (!Race.isSolidObjectOnSpot(st[1].poX, st[1].poY+1)) {
						st[1].dol();
						break;
						}
				}
			}

			if ( players == 3 ) {
				char key3 = ke.getKeyChar();
				switch(key3) {
					case 'h':
						if( !((st[2].poY >= (int)(visina*2/3)) &
							(st[2].poX == (int)(sirina/2)+1)) )
						st[2].levo();
						break;
					case 'H':
						if( !((st[2].poY >= (int)(visina*2/3)) &
							(st[2].poX == (int)(sirina/2)+1)) )
						st[2].levo();
						break;
					case 'k':
						st[2].desno();
						break;
					case 'K':
						st[2].desno();
						break;
					case 'u':
						st[2].gor();
						break;
					case 'U':
						st[2].gor();
						break;
					case 'j':
						st[2].dol();
						break;
					case 'J':
						st[2].dol();
						break;
				}
			}


			narisiPremik();
			krog();
			//karambol();
		}

		if (faza == 3)  //Game over
		{
			switch(key) {
				case KeyEvent.VK_ENTER:
					faza = 0;
					paint(g);
					break;
			}
		}
	}



	public void keyReleased(KeyEvent ke) {
		int key = ke.getKeyCode();

		if (faza == 2)
		{
			switch(key) {
				case KeyEvent.VK_LEFT:
					st[0].left = false;
					break;
				case KeyEvent.VK_RIGHT:
					st[0].right = false;
					break;
				case KeyEvent.VK_UP:
					st[0].up = false;
					break;
				case KeyEvent.VK_DOWN:
					st[0].down = false;
					break;
			}
			if ( players == 2 ) {
				char key2 = ke.getKeyChar();
				switch(key2) {
					case 'a':
						st[1].left = false;
						break;
					case 'd':
						st[1].right = false;
						break;
					case 'w':
						st[1].up = false;
						break;
					case 's':
						st[1].down = false;
						break;
				}
			}
			if ( players == 3 ) {
				char key3 = ke.getKeyChar();
				switch(key3) {
					case 'h':
						st[2].left = false;
						break;
					case 'k':
						st[2].right = false;
						break;
					case 'u':
						st[2].up = false;
						break;
					case 'j':
						st[2].down = false;
						break;
				}
			}
		}
	}

	public void keyTyped(KeyEvent ke) {
	}

	void prehitriStart(int a) {
		Graphics g = getGraphics();
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#');

		g.setColor(new Color(0,0,0));

		g.drawString("Too fast player No.", 20 * curX, 20 * curY);
		//napis("Too fast player No." /*+ st[a].ch*/, 20, int 20);
		faza = 3;

	}




/********************IZRIS PROGE*****************/
	void meni(Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#');

		g.setColor(new Color(0,0,0));
		g.fillRect(0, 0, 1000, 1000);
		g.setColor(new Color(255,255,255));
		g.drawString("How many players? " + players, 10 * curX, 10 * curY);
		g.drawString("Solo? (s) " + solo, 10 * curX, 11 * curY);
	}


	void proga(Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#');
		g.setColor(new Color(255,255,255));
		//IGRALCA
		for (int i=0; i < players; i++) {
			g.drawString(st[i].ch, st[i].poX * curX, st[i].poY * curY);;
		}

		Objekt o;
		for (int poz=0; poz < zd.size(); poz++) {
			o = (Objekt) zd.get(poz);
			g.drawString(o.ch, o.poX * curX, o.poY * curY);
		}
	}


	void narediStevila() {
		for (int i=0; i < players; i++) {
			st[i] = new Stevilo((int)(sirina/2)+1, (int) 19+2*i,(char) (i+49));

		}
	}

	void narediProgo() {
		Zid z;
		//ZUNANJI OKVIR
		for (int i=1; i<= sirina; i++) {
			zd.add(new Zid(i,1));
			zd.add(new Zid(i,visina));
		}
		for (int i=1; i<= visina; i++) {
			zd.add(new Zid(1,i));
			zd.add(new Zid(sirina,i));
		}
		//NOTRANJI OKVIR
		for (int i= (int) (sirina/4); i<= (int) (sirina*3/4); i++) {
			zd.add(new Zid(i,(int) (visina/3)));
			zd.add(new Zid(i,(int) (visina*2/3)));
		}
		for (int i= (int) (visina/3); i <= (int) (visina*2/3); i++) {
			zd.add(new Zid((int) (sirina/4), i));
			zd.add(new Zid((int) (sirina/4)+1, i));
			zd.add(new Zid((int) (sirina*3/4), i));
			zd.add(new Zid((int) (sirina*3/4)-1, i));
			for (int j= (int) (sirina/4 + 5); j<= (int) (sirina*3/8); j++) {
				zd.add(new Zid(j, i));
			}
			for (int j= (int) (sirina*5/8); j<= (int) (sirina*3/4) - 5; j++) {
				zd.add(new Zid(j, i));
			}
			if(i <= (int) (visina*2/3) -4) {
				for (int j= (int) (sirina/4) +2; j<= (int) (sirina/4) +4; j++) {
					zd.add(new Zid(j, i));
				}
				for (int j= (int) (sirina*3/4) -4; j<= (int) (sirina*3/4) -2; j++) {
					zd.add(new Zid(j, i));
				}
			}
		}
		//CILJNA CRTA
		for (int i= (int)(visina*2/3)+1; i <= visina-1; i++) {
			zd.add(new CiljnaCrta ((int)(sirina/2), i));
		}
		//MINA
		zd.add(new Mina(60, 20));
	}




/***************AKCIJE***************************/

	void odstevanje() {
		String str = new String();
		long time1, time2;
		int s, sLast = -1;
		Graphics g = getGraphics();
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#'),
			nmbY = curY * 12,
			nmbX = curX * 40;

		time1 = System.currentTimeMillis();
		time2 = System.currentTimeMillis();
		g.setColor(new Color(255,255,255));
        while (time2 - time1 < 3000) {
        	time2 = System.currentTimeMillis();
        	s = ((int) (time2 - time1))/1000;
        	if(sLast != s) {
        		g.setColor(black);
        		g.drawString(str.valueOf(3 - sLast), nmbX , nmbY );
        		g.setColor(white);
        		g.drawString(str.valueOf(3 - s), nmbX , nmbY );
        		sLast = s;
        	}
        }
        g.setColor(black);
        g.drawString("0", nmbX , nmbY );
        g.setColor(white);
        g.drawString("Go, Go, Go!!!", curX * 34, curY * 12);
        faza = 2;
	}

	void narisiPremik() {
		Graphics g = getGraphics();
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#');

		g.setColor(new Color(0,0,0));

		for (int i=0; i < players; i++) {
			g.drawString(st[i].ch, st[i].prejX * curX, st[i].prejY * curY);
		}
		g.setColor(new Color(255,255,255));
		for (int i=0; i < players; i++) {
			g.drawString(st[i].ch, st[i].poX * curX, st[i].poY * curY);
		}
		for (int i=0; i < players; i++) {
			if( (st[i].prejY >= (int)(visina*2/3)) &
				(st[i].prejX == (int)(sirina/2)) ) {
				g.drawString("|", st[i].prejX * curX, st[i].prejY * curY);
			}
		}
	}

	/*void narisiMeni() {
		Graphics g = getGraphics();
		FontMetrics fm = g.getFontMetrics();
		int curY = 15,
			curX = fm.charWidth('#');
		g.drawString("How many players? " + players, 10 * curX, 10 * curY);
	}*/

/*****PREVERJANJA PO VSAKEM PREMIKU**************/

	void krog() {
		for (int i=0; i < players; i++) {
			if( (st[i].poY >= (int)(visina*2/3)) &
				(st[i].poX == (int)(sirina/2)+1) &
				(st[i].prejX == (int)(sirina/2)) ) {
				st[i].krog++;
				zmaga(i);
			}
		}
	}

	void zmaga(int i) {
		if(st[i].krog==krog) {
			faza = 3;
			Graphics g = getGraphics();
			FontMetrics fm = g.getFontMetrics();
			int curY = 15,
				curX = fm.charWidth('#');
			g.setColor(new Color(255,255,255));
			g.drawString(" Player No." + st[i].ch + " wins",
				((int) (sirina*3/8)+1) * curX, ((int) (visina/3)+1)* curY);
		}
	}

	void karambol() {
		Objekt o;
		for (int i=0; i < players; i++) {
			for (int poz=0; poz < zd.size(); poz++) {
				o = (Objekt) zd.get(poz);
				if (o.trdnost == true) {
					
					if ( o.poX == st[i].poX && o.poY == st[i].poY) {
						//faza = 3;
						Graphics g = getGraphics();
						FontMetrics fm = g.getFontMetrics();
						int curY = 15,
							curX = fm.charWidth('#');
						g.setColor(new Color(0,0,0));
						g.drawString("#", st[i].poX * curX, st[i].poY * curY);
						g.setColor(new Color(255,255,255));
						g.drawString(st[i].ch , st[i].poX * curX, st[i].poY * curY);
						g.drawString(" Player No." + st[i].ch + " lost",
							((int) (sirina*3/8)+1) * curX, ((int) (visina/3)+1)* curY);
					}
				}
			}
		}
	}
	
	public static boolean isSolidObjectOnSpot(int x, int y) {
		for (int poz=0; poz < zd.size(); poz++) {
			Objekt o = (Objekt) zd.get(poz);
			if (o.trdnost == true) {
				
				if ( o.poX == x && o.poY == y) {
					return true;
				}
			}
		}
		return false;
	}


/********************THREAD**********************/
	/*boolean stopFlag;
	int time = 0;
	Thread thr;
	public void start() {
		thr = new Thread(this);
		stopFlag = false;
		thr.start();
	}

	public void stop() {
		stopFlag = true;
	}

	public void run() {
		Graphics gra = getGraphics();

		while (true) {
			time += 4;

			paint(gra);

			try { Thread.sleep(40); } catch (Exception e) {};
			if(stopFlag)
				return;
		}
	}
	*/

}




















