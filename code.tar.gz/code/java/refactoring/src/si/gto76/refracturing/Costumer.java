package si.gto76.refracturing;
import java.util.Vector;

class Customer {
	///////////////////////////
	private String name;
	private Vector<Rental> rentals = new Vector<Rental>();
	///////////////////////////
	
	public Customer (String name){
		this.name = name;
	}
	
	///////////////////////////
	public void addRental(Rental arg) {
		rentals.addElement(arg);
	}
	
	public String getName (){
		return name;
	}
	
	public Vector<Rental> getRentals() {
		return new Vector<Rental>(rentals);
	}
	
	public double getTotalCharge() {
		double totalAmount = 0;
		for (Rental rental : rentals) {
			totalAmount += rental.getCharge();
		}
		return totalAmount;
	}
	
	public int getTotalPoints() {
		int points = 0;
		for (Rental rental : rentals) {
			points += rental.getPoints();
		}
		return points;
	}
	
	public String statement(Format format) {
		Statement statement = new Statement(this, format);
		return statement.toString();
	}
	
}
