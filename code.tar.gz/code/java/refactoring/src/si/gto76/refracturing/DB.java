package si.gto76.refracturing;

import java.util.HashMap;
import java.util.Map;
import java.sql.*;

import si.gto76.refracturing.movietype.MovieType;

public class DB {

	public static void loadWholeDB() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		
		final String USER = "root";
		final String PASS = "aerosmi1";
		final String DB_URL = "jdbc:mysql://192.168.1.12/videoteka";
		
		System.out.println("Connecting to database...");
		Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		
		Map<Integer, MovieType> movieTypes = new HashMap<Integer, MovieType>();
		
		System.out.println("Creating statement...");
		java.sql.Statement stmt = conn.createStatement();
		String sql;
		sql = "SELECT * FROM costumer";
		ResultSet rs = stmt.executeQuery(sql);
	
		while(rs.next()){
		    //Retrieve by column name
		    String name = rs.getString("NAME");
		    //Display values
		    System.out.print("NAME: " + name);
		}
	}
	
}
