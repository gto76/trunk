package si.gto76.refracturing;

public interface Format {
	enum Instance {
		PLAIN(new FormatPlain()),
		HTML(new FormatHTML()),
		;;;;
		Format format;
		Instance(Format format) {
			this.format = format;
		}
	}
	
	public abstract String getHeader(String name);
	public abstract String getColumn(String title, String amount);
	public abstract String getFooter(String totalAmount, String points);
}

