package si.gto76.refracturing;

public class FormatHTML implements Format {

	@Override
	public String getHeader(String name) {
		return "<H1>Rentals for <EM>" + name + "</EM></H1><P>\n";
	}
	
	@Override
	public String getColumn(String title, String amount) {
		return title + ": " + amount + "<BR>\n";
	}

	@Override
	public String getFooter(String totalAmount, String points) {
		return "<P>You owe <EM>" + totalAmount + "</EM><P>\n" +
				"On this rental you earned <EM>" + points + "</EM> frequent renter points<P>";
	}

}
