package si.gto76.refracturing;

public class FormatPlain implements Format {

	@Override
	public String getHeader(String name) {
		return "Rental Record for " + name + "\n";
	}
	
	@Override
	public String getColumn(String title, String amount) {
		return "\t" + title + "\t" + amount + "\n";
	}

	@Override
	public String getFooter(String totalAmount, String points) {
		return "Amount owed is " + totalAmount + "\n" +
				"You earned " + points + " frequent renter points";
	}

}
