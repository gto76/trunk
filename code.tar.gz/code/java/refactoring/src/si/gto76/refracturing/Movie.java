package si.gto76.refracturing;

import si.gto76.refracturing.movietype.MovieType;

public class Movie {
	///////////////////////
	private String title;
	private MovieType type;
	///////////////////////

	public Movie(String title, MovieType type) {
		this.title = title;
		this.type = type;
	}
	
	///////////////////////
	public String getTitle (){
		return title;
	}

	public double getCharge(int daysRented) {
		double rentalsAmount = type.getStartingFee();
		if (daysRented > type.getDaysTreshold()) {
			rentalsAmount += (daysRented - type.getDaysTreshold()) * type.getDailyFee();
		}
		return rentalsAmount;
	}

	public int getPoints(int daysRented) {
		if (daysRented > type.getPointsDaysTreshold()) {
			return type.getStartingPoints() + type.getBonusPoints();
		} else {
			return type.getStartingPoints();
		}
	}
	
}
