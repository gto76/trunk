package si.gto76.refracturing;
public class Statement {
	private Customer customer;
	private Format format;
	
	public Statement(Customer customer, Format format) {
		this.customer = customer;
		this.format = format;
	}

	@Override
	public String toString() {
		StringBuilder text = new StringBuilder();
		addHeader(text);
		addColumns(text);
		addFooter(text);
		return text.toString();
	}

	private void addHeader(StringBuilder text) {
		String name = customer.getName();
		text.append(format.getHeader(name));
	}

	private void addColumns(StringBuilder text) {
		for (Rental rental : customer.getRentals()) {
			addColumn(rental, text);
		}
	}

	private void addColumn(Rental rental, StringBuilder text) {
		String title = rental.getMovie().getTitle();
		String amount = String.valueOf(rental.getCharge());
		text.append(format.getColumn(title, amount));
	}

	private void addFooter(StringBuilder text) {
		String totalAmount = String.valueOf(customer.getTotalCharge());
		String points = String.valueOf(customer.getTotalPoints());
		text.append(format.getFooter(totalAmount, points));
	}
}
