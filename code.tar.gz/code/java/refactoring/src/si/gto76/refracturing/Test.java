package si.gto76.refracturing;

import java.sql.SQLException;

import si.gto76.refracturing.movietype.MovieType;


public class Test {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//singleUserTest();
		DB.loadWholeDB();
	}

	private static void singleUserTest() {
		Customer joe = new Customer("Joe");
		addRentals(joe);
		System.out.println(joe.statement(Format.Instance.PLAIN.format));
	}

	private static void addRentals(Customer joe) {
		joe.addRental(new Rental(Movies.ALIEN.m, 2));
		joe.addRental(new Rental(Movies.SPRINGBREAKERS.m, 3));
		joe.addRental(new Rental(Movies.SHREK.m, 1));
	}
	
	public enum MovieTypes {
		REGULAR("Regular", 2, 2, 1.5, 0, 0, 1),
		CHILDRENS("Childrens", 1.5, 3, 1.5, 0, 0, 1),
		NEW_RELEASE("New Release", 0, 0, 3, 1, 1, 1)
		;;;;;
		final MovieType type;
		MovieTypes(String name, double startingFee, int daysTreshold, double dailyFee,
				int pointsDaysTreshold, int bonusPoints, int startingPoints) {
			this.type = new MovieType(name, startingFee, daysTreshold, dailyFee, 
					pointsDaysTreshold, bonusPoints, startingPoints);
		}
	}

	public enum Movies {
		JAWS("Jaws", MovieTypes.REGULAR),
		ALIEN("Alien", MovieTypes.REGULAR),
		GODFATHER("Godfather", MovieTypes.REGULAR),
		TERMINATOR_2("Terminator 2", MovieTypes.REGULAR),
		HOME_ALONE("Home Alone", MovieTypes.CHILDRENS),
		SHREK("Shrek", MovieTypes.CHILDRENS),
		SPRINGBREAKERS("Springbreakers", MovieTypes.NEW_RELEASE)
		;;;
		final Movie m;
		Movies(String title, MovieTypes movieType) {
			this.m = new Movie(title, movieType.type);
			;
		}
	}
}

