package si.gto76.refracturing.movietype;
public class MovieType {
	////////////////////////////
	protected String name;
	protected double startingFee; 
	protected int daysTreshold;
	protected double dailyFee;
	
	protected int pointsDaysTreshold;
	protected int bonusPoints;
	protected int startingPoints;
	////////////////////////////
	public MovieType(String name, double startingFee, int daysTreshold,
			double dailyFee, int pointsDaysTreshold, int bonusPoints,
			int startingPoints) {
		super();
		this.name = name;
		this.startingFee = startingFee;
		this.daysTreshold = daysTreshold;
		this.dailyFee = dailyFee;
		this.pointsDaysTreshold = pointsDaysTreshold;
		this.bonusPoints = bonusPoints;
		this.startingPoints = startingPoints;
	}
	////////////////////////////

	protected void setName(String name) {
		this.name = name;
	}

	protected void setStartingFee(double startingFee) {
		this.startingFee = startingFee;
	}

	protected void setDaysTreshold(int daysTreshold) {
		this.daysTreshold = daysTreshold;
	}

	protected void setDailyFee(double dailyFee) {
		this.dailyFee = dailyFee;
	}

	protected void setPointsDaysTreshold(int pointsDaysTreshold) {
		this.pointsDaysTreshold = pointsDaysTreshold;
	}

	protected void setBonusPoints(int bonusPoints) {
		this.bonusPoints = bonusPoints;
	}

	protected void setStartingPoints(int startingPoints) {
		this.startingPoints = startingPoints;
	}
	
	////////////////////////////

	public String getName() {
		return name;
	}

	public double getStartingFee() {
		return startingFee;
	}

	public int getDaysTreshold() {
		return daysTreshold;
	}

	public double getDailyFee() {
		return dailyFee;
	}

	public int getPointsDaysTreshold() {
		return pointsDaysTreshold;
	}

	public int getBonusPoints() {
		return bonusPoints;
	}

	public int getStartingPoints() {
		return startingPoints;
	}

}
