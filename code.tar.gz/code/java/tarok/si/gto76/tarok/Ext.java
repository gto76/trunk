package si.gto76.tarok;

public enum Ext {
	MIN, 
	MAX;
	///////
	public int get(int i1, int i2) {
		if (this.equals(MIN)) {
			return Math.min(i1, i2);
		}
		else {
			return Math.max(i1, i2);
		}
	}
	public boolean isFirstMoreExtreme(int i1, int i2) {
		if (this.equals(MIN)) {
			if (i1 < i2) return true;
			else return false;
		}
		else {
			if (i1 > i2) return true;
			else return false;
		}
	}
}
