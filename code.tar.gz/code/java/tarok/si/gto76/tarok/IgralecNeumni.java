package si.gto76.tarok;
import java.util.Vector;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;
import si.gto76.tarok.framework.TipIgre;
import si.gto76.tarok.framework.Uporabno;

public class IgralecNeumni implements KonkretniIgralec {
    public static final String Ime = "Neumni Igralec";
    public String getIme() {
		return Ime;
	}

	Vector<Karta> karte;

    public IgralecNeumni() {
    }

    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko) {
		return new TipIgre(3, false, Barva.KARO);
    
    }
    
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene) {
    	vzete.addAll(talon.get(1));
    	for (int i=0;i<karte.size();i++) {
    		if (karte.get(i).vrednost != 14 || karte.get(i).barva == Barva.TAROK) zalozene.add(karte.get(i));
    		if (zalozene.size() == 3) break;
    	}
    }

    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona) {
    	
    }
    
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec) {
		Vector<Karta> veljavne = Uporabno.veljavnePoteze(mojeKarte, karteNaMizi);
		return veljavne.get(0);
    }
    
    public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi) {
    }
    
    public void KonecIgre(String razlog) {
        System.out.println("Konec igre, razlog = " + razlog);
    }
}
