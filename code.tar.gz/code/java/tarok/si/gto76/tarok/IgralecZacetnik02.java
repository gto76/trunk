package si.gto76.tarok;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;
import si.gto76.tarok.framework.TipIgre;
import si.gto76.tarok.framework.Uporabno;

public class IgralecZacetnik02 implements KonkretniIgralec {
	private static Random rand = new Random();
    public static final String Ime = "Zac02";
    public String getIme() {
		return Ime;
	}
    Vector<Karta> karte;
    
    Barva kralj = null;

    public IgralecZacetnik02() {
    }

    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko) {
    	Set<Barva> barve = Util.katerihKraljevNimam(karteZaVRoko);
    	if (barve.isEmpty()) {
    		kralj = Barva.KARO;
    	} else {
    		kralj = (Barva) barve.toArray()[rand.nextInt(barve.size())];
    	}
		return new TipIgre(3, false, Barva.KARO);
    
    }
    
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene) {
    	vzete.addAll(talon.get(1));
    	for (int i=0;i<karte.size();i++) {
    		if (karte.get(i).vrednost != 14 || karte.get(i).barva == Barva.TAROK) zalozene.add(karte.get(i));
    		if (zalozene.size() == 3) break;
    	}
    }

    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona) {
    	
    }
    
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec) {
		Vector<Karta> veljavne = Uporabno.veljavnePoteze(mojeKarte, karteNaMizi);
		
		Karta karta = null;
		karta = Util.dobiNajboljsoBarvnoKarto(veljavne);
		if (karta == null) {
			if (karteNaMizi.size() == 0 ) {
				karta = Util.dobiNajmanjVredenTarok(veljavne);
			} else {
				karta = Util.dobiNaslednjiTarokPoVelikostiDrugaceNajmanjVrednega(karteNaMizi, veljavne);
			}
		}
		if (karta == null) {
			throw new NullPointerException("V Utilu je napaka v eni od funkcij: dobiNajbolj�oBarvnoKarto, dobiNajmanjVredenTarok.");
		}
		
		return karta;
    }
    
    public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi) {
    }
    
    public void KonecIgre(String razlog) {
        System.out.println("Konec igre, razlog = " + razlog);
    }
}
