package si.gto76.tarok;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;
import si.gto76.tarok.framework.TipIgre;
import si.gto76.tarok.framework.Uporabno;

public class IgralecZacetnik03 implements KonkretniIgralec {
	private static Random rand = new Random();
    public static final String Ime = "Zac03";
    public String getIme() {
		return Ime;
	}
    Vector<Karta> karte;
    
    Barva kralj = null;

    public IgralecZacetnik03() {
    }

    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko) {
    	Set<Barva> barve = Util.katerihKraljevNimam(karteZaVRoko);
    	if (barve.isEmpty()) {
    		kralj = Barva.KARO;
    	} else {
    		kralj = (Barva) barve.toArray()[rand.nextInt(barve.size())];
    	}
		return new TipIgre(3, false, Barva.KARO);
    
    }
    
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene) {
    	vzete.addAll(talon.get(1));
    	for (int i=0;i<karte.size();i++) {
    		if (karte.get(i).vrednost != 14 || karte.get(i).barva == Barva.TAROK) zalozene.add(karte.get(i));
    		if (zalozene.size() == 3) break;
    	}
    }

    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona) {
    	
    }
    
    Vector<Karta> mojeKarte;
    Vector<Karta> karteNaMizi;
    int prviIgralec;
    Vector<Karta> veljavne;
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec) {
        this.mojeKarte = mojeKarte;
        this.karteNaMizi = karteNaMizi;
        this.prviIgralec = prviIgralec;
		veljavne = Uporabno.veljavnePoteze(mojeKarte, karteNaMizi);
		
		if (karteNaMizi.isEmpty()) {
			return prviNaVrsti();
		} else {
			return nisemPrviNaVrsti();
		}
    }
   
	private Karta prviNaVrsti() {
		Karta karta = null;
		karta = Util.dobiNajboljsoBarvnoKarto(veljavne);
		if (karta == null) {
			karta = Util.dobiNajmanjVredenTarok(veljavne);
		}
		return karta;
	}
	
    private Karta nisemPrviNaVrsti() {
		if (Util.aliVsebujeTarok(karteNaMizi)) {
			if (Util.aliVsebujeTarok(veljavne)) {
				return Util.dobiNaslednjiTarokPoVelikostiDrugaceNajmanjVrednega(karteNaMizi, veljavne);
			} else {
				return Util.dobiNajmanjVrednoKarto(veljavne);
			}
		} else {
			if (Util.aliVsebujeTarok(veljavne)) {
				return Util.dobiNajmanjVredenTarok(veljavne);
			}
			if (Util.aliImamBoljsoKartoGledeNaZaporedje(karteNaMizi, veljavne)) {
				Vector<Karta> boljse = Util.dobiBoljseKarteGledeNaZaporedje(karteNaMizi, veljavne);
				return Util.dobiNajboljsoBarvnoKarto(boljse);
			} else {
				return Util.dobiNajmanjVrednoKarto(veljavne);
			}
		}
	}



	public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi) {
    }
    
    public void KonecIgre(String razlog) {
        System.out.println("Konec igre, razlog = " + razlog);
    }
}
