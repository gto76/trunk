package si.gto76.tarok;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import com.google.common.collect.Sets;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;
import si.gto76.tarok.framework.TipIgre;
import si.gto76.tarok.framework.Uporabno;

public class IgralecZacetnik04 implements KonkretniIgralec {
	private static Random rand = new Random();
    public static final String Ime = "Zac04";
    public String getIme() {
		return Ime;
	}
    Vector<Karta> karte;
    
    //boolean jazIgram = false;
    Integer soigralec = null;

    public IgralecZacetnik04() {
    }

    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko) {
    	//jazIgram = true;
    	//this.karte = karteZaVRoko;
    	
    	Set<Barva> barve = Util.katerihKraljevNimam(karteZaVRoko);
    	Barva kralj = null;
    	if (barve.isEmpty()) {
    		kralj = Barva.KARO;
    	} else {
    		kralj = (Barva) barve.toArray()[rand.nextInt(barve.size())];
    	}
		return new TipIgre(3, false, kralj);
    
    }
    
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene) {
    	vzete.addAll(talon.get(1));
    	for (int i=0;i<karte.size();i++) {
    		if (karte.get(i).vrednost != 14 || karte.get(i).barva == Barva.TAROK) zalozene.add(karte.get(i));
    		if (zalozene.size() == 3) break;
    	}
    }

    int idxIgralca;
    int glavniIgralec;
    TipIgre tipIgre;
    Vector<Karta> ostanekTalona;
    Vector<Karta> pobraneKarteTalona;
    
    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona) {
        this.idxIgralca = idxIgralca;
        this.glavniIgralec = glavniIgralec;
        this.tipIgre = tipIgre;
        this.ostanekTalona = ostanekTalona;
        this.pobraneKarteTalona = pobraneKarteTalona;
        
       
    }

	public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi) {
    }
    
    public void KonecIgre(String razlog) {
        System.out.println("Konec igre, razlog = " + razlog);
    }
    
    //#############################
    
    Vector<Karta> mojeKarte;
    Vector<Karta> karteNaMizi;
    int prviIgralec;
    Vector<Karta> veljavne;
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec) {
        this.mojeKarte = mojeKarte;
        this.karteNaMizi = karteNaMizi;
        this.prviIgralec = prviIgralec;
		veljavne = Uporabno.veljavnePoteze(mojeKarte, karteNaMizi);
		
		if (soigralec == null)
			preveriAliSeJePokazalKralj();
		
		Karta karta = null;
		if (karteNaMizi.isEmpty()) {
			karta = prviNaVrsti();
		} else {
			karta = nisemPrviNaVrsti();
		}
		
		if (karta != null) {
			return karta;
		} else {
			//return veljavne.firstElement();
			throw new NullPointerException("Program ni izbral nobene karte");
		}
    }
   


	private Karta prviNaVrsti() {
		Karta karta = null;
		karta = Util.dobiNajboljsoBarvnoKarto(veljavne);
		if (karta == null) {
			karta = Util.dobiNajmanjVredenTarok(veljavne);
		}
		return karta;
	}
	
    private Karta nisemPrviNaVrsti() {
		if (Util.aliVsebujeTarok(karteNaMizi)) {
			if (Util.aliVsebujeTarok(veljavne)) {
				return Util.dobiNaslednjiTarokPoVelikostiDrugaceNajmanjVrednega(karteNaMizi, veljavne);
			} else {
				return Util.dobiNajmanjVrednoKarto(veljavne);
			}
		} else {
			// na mizi ni taroka
			if (Util.aliVsebujeTarok(veljavne)) {
				return Util.dobiNajmanjVredenTarok(veljavne);
			}
			if (Util.aliImamBoljsoKartoGledeNaZaporedje(karteNaMizi, veljavne)) {
				Vector<Karta> boljse = Util.dobiBoljseKarteGledeNaZaporedje(karteNaMizi, veljavne);
				return Util.dobiNajboljsoBarvnoKarto(boljse);
			} else {
				// �meranje
				if (semZadnjiNaVrsti() && soigralec != null && soigralecImaTrenutnoStih()) {
					return Util.dobiNajboljsoBarvnoKarto(veljavne);
				} else {
					return Util.dobiNajmanjVrednoKarto(veljavne);
				}
			}
		}
	}

    //###################################
    
	private boolean soigralecImaTrenutnoStih() {
		int indexVodilneKarte = Util.dobiIndexNajboljseKarteNaMizi(karteNaMizi);
		int indexsIgralcaZVodilnoKarto = dobiIndexIgralcaIzIndexaKarte(indexVodilneKarte);
		if (indexsIgralcaZVodilnoKarto == soigralec) return true;
		return false;
	}

	private int dobiIndexIgralcaIzIndexaKarte(int indexVodilneKarte) {
		int igralecTemp = prviIgralec;
		for (int i=0; i<=indexVodilneKarte; i++) {
			if (igralecTemp <= 2) {
				igralecTemp++;
			} else {
				igralecTemp = 0;
			}
		}
		return igralecTemp;
	}

	private boolean semZadnjiNaVrsti() {
		if (karteNaMizi.size() == 4) return true;
		else return false;
	}

	private void preveriAliSeJePokazalKralj() {
		Barva barvaKlicanegaKralja = tipIgre.klicaniKralj;
		int vrednost = TipKarte.KRALJ.getVrednost();	
		
		// preveri �e imam klicanega kralja
	    if (Util.vsebujeKarto(mojeKarte, barvaKlicanegaKralja, vrednost)) {
	    	soigralec = glavniIgralec;
	    }
		
		if (Util.vsebujeKarto(karteNaMizi, barvaKlicanegaKralja, vrednost)) {
			int indexKralja = Util.indeksKarte(karteNaMizi, barvaKlicanegaKralja, vrednost);
			int indexIgralcaZKraljem = dobiIndexIgralcaZKraljem(indexKralja);
			if (igramJaz()) {
				soigralec = indexIgralcaZKraljem;
			} else {
				// ne igram in nisem z glavnim igralcem
				soigralec = 
						Sets.difference(new HashSet<Integer>(Arrays.asList(1, 2, 3, 4)), 
								new HashSet<Integer>(Arrays.asList(indexIgralcaZKraljem, prviIgralec, idxIgralca)))
									.iterator().next();
			}
		}
	}
	
	private int dobiIndexIgralcaZKraljem(int indexKralja) {
		int igralecTemp = prviIgralec;
		for (int i = 0; i < indexKralja; i++) {
			if (igralecTemp <= 3)
				igralecTemp++;
			else
				igralecTemp = 0;
		}
		return igralecTemp;
	}

	
	
	private boolean igramJaz() {
		if (idxIgralca == glavniIgralec) {
			return true;
		}
		return false;
	}


}
