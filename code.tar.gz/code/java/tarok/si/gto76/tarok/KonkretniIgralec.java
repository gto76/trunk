package si.gto76.tarok;

import java.util.Vector;

import si.gto76.tarok.framework.Karta;
import si.gto76.tarok.framework.TipIgre;


public interface KonkretniIgralec {
    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko);
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene);
    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona);
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec);
    public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi);
    public void KonecIgre(String razlog);
    public String getIme();
}
