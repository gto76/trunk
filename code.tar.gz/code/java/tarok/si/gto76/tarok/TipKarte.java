package si.gto76.tarok;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;

public enum TipKarte {
	ENA(7),
	DVE(8),
	TRI(9),
	STIRI(10),
	POB(11),
	KAVAL(12),
	DAMA(13),
	KRALJ(14)
	;;;;;;;;;
	int vrednost;
	TipKarte(int vrednost) {
		this.vrednost = vrednost;
	}
	public static TipKarte get(Karta karta) {
		if (karta.barva == Barva.TAROK) return null;
		for (TipKarte tip : TipKarte.values()) {
			if (tip.vrednost == karta.vrednost) {
				return tip;
			}
		}
		throw new NullPointerException();
	}
	public int getVrednost() {
		return vrednost;
	}
}
