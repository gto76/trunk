package si.gto76.tarok;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import com.google.common.collect.Sets;

import si.gto76.tarok.framework.Barva;
import si.gto76.tarok.framework.Karta;


public class Util {

	public static Karta dobiNajboljsoBarvnoKarto(Vector<Karta> karte) {
		Vector<Karta> samoBarve = dobiSamoBarve(karte);
		return dobiNajvrednejsoKarto(samoBarve);
	}
	public static Karta dobiNajmanjVredenTarok(Vector<Karta> karte) {
		Vector<Karta> samoTaroki = dobiSamoTaroke(karte);
		return dobiNajmanjVrednoKarto(samoTaroki);
	}
	public static Karta dobiNajvrednejsoKarto(Vector<Karta> karteIn) {
		return dobiEkstremnoVrednoKarto(karteIn, Ext.MAX);
	}
	public static Karta dobiNajmanjVrednoKarto(Vector<Karta> karteIn) {
		return dobiEkstremnoVrednoKarto(karteIn, Ext.MIN);
	}
	private static Karta dobiEkstremnoVrednoKarto(Vector<Karta> karteIn, Ext ext) {
		if (karteIn.isEmpty()) return null;
		Karta ekstrmnaKarta = karteIn.firstElement();
		for (Karta karta : karteIn) {
			if (ext.isFirstMoreExtreme(karta.stTock(), ekstrmnaKarta.stTock())) {
				ekstrmnaKarta = karta;
			}
		}
		return ekstrmnaKarta;
	}

	public static boolean aliVsebujeTarok(Vector<Karta> karte) {
		Vector<Karta> taroki = dobiSamoDoloceneBarve(karte, getSetFromElements(Barva.TAROK));
		if (taroki.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}
	

	
	public static Vector<Karta> dobiSamoTaroke(Vector<Karta> karte) {
		return dobiSamoDoloceneBarve(karte, getSetFromElements(Barva.TAROK));
	}

	public static Vector<Karta> dobiSamoBarve(Vector<Karta> karte) {
		return dobiSamoDoloceneBarve(karte, getSetFromElements(Barva.KARO, Barva.KRIZ, Barva.PIK, Barva.SRCE));
	}
	
	public static Vector<Karta> dobiSamoDoloceneBarve(Vector<Karta> karte, Set<Barva> barve) {
		Vector<Karta> izbor = new Vector<Karta>();
		for (Karta karta : karte) {
			if (barve.contains(karta.barva))  {
				izbor.add(karta);
			}
		}
		return izbor;
	}
	
	public static Vector<Karta> dobiSamoDolocenTipKarte(Vector<Karta> karte, TipKarte tipKarte) {
		Vector<Karta> izbor = new Vector<Karta>();
		for (Karta karta : karte) {
			if (tipKarte == TipKarte.get(karta))  {
				izbor.add(karta);
			}
		}
		return izbor;
	}

	public static Set<Barva> katerihKraljevNimam(Vector<Karta> karteZaVRoko) {
		Vector<Karta> izbor = dobiSamoDolocenTipKarte(karteZaVRoko, TipKarte.KRALJ);
		Set<Barva> mnozicaBarv = vrniMnozicoBarv(izbor);
		return negirajMnozicoBarv(mnozicaBarv);
	}

	public static Set<Barva> vrniMnozicoBarv(Vector<Karta> karte) {
		Set<Barva> out = new HashSet<Barva>();
		for (Karta karta : karte) {
			out.add(karta.barva);
		}
		return out;
	}
	
	public static Set<Barva> negirajMnozicoBarv(Set<Barva> barveIn) {
		return Sets.difference(new HashSet<Barva>(Arrays.asList(Barva.values())), barveIn);
	}

	public static Karta dobiNaslednjiTarokPoVelikostiDrugaceNajmanjVrednega(
			Vector<Karta> karteNaMizi, Vector<Karta> veljavne) {
		Karta najvisjiTarokNamizi = dobiNajvisjiTarok(karteNaMizi);
		if (najvisjiTarokNamizi == null) {
			return dobiNajmanjVredenTarok(veljavne);
		} else {
			if (aliImamBoljsiTarok(najvisjiTarokNamizi, veljavne)) {
				return dobiNaslednjiTarokPoVelikosti(najvisjiTarokNamizi, veljavne);
			} else {
				return dobiNajmanjVredenTarok(veljavne);
			}
		}
	}


	public static Karta dobiNaslednjiTarokPoVelikosti(
			Karta najvisjiTarokNamizi, Vector<Karta> veljavne) {
		Vector<Karta> veljavneTemp = new Vector<Karta>(veljavne);
		Collections.sort((List<Karta>)veljavneTemp, new Comparator<Karta>() {
			@Override
			public int compare(Karta k1, Karta k2) {
				if (k1.vrednost < k2.vrednost) return 1;
				if (k1.vrednost > k2.vrednost) return -1;
				else return 0;
			}
		});
		for (Karta out : veljavneTemp) {
			if (out.vrednost > najvisjiTarokNamizi.vrednost) {
				return out;
			}
		}
		return null;
	}

	public static boolean aliImamBoljsiTarok(Karta najvisjiTarokNamizi,
			Vector<Karta> taroki) {
		for (Karta tarok : taroki) {
			if (tarok.vrednost > najvisjiTarokNamizi.vrednost) {
				return true;
			}
		}
		return false;
	}

	public static Karta dobiNajvisjiTarok(Vector<Karta> karte) {
		Vector<Karta> taroki = dobiSamoTaroke(karte);
		if (taroki.size() == 0) return null;
		Karta najvisjiTarok = taroki.firstElement();
		for (Karta tarok : taroki) {
			if (tarok.vrednost > najvisjiTarok.vrednost) {
				najvisjiTarok = tarok;
			}
		}
		return najvisjiTarok;
	}

	public static boolean aliImamBoljsoKartoGledeNaZaporedje(Vector<Karta> karteNaMizi,
			Vector<Karta> veljavne) {
		Vector<Karta> mojeBoljse = dobiBoljseKarteGledeNaZaporedje(karteNaMizi, veljavne);
		if (mojeBoljse.isEmpty()) return false;
		else return true;
	}

	public static Karta dobiNajboljsoKartoNaMizi(Vector<Karta> karteNaMizi) {
		if (aliVsebujeTarok(karteNaMizi)) {
			return dobiNajvisjiTarok(karteNaMizi);
		} else {
			Karta najboljsa = karteNaMizi.firstElement();
			for (Karta karta : karteNaMizi) {
				if (karta.barva == najboljsa.barva && karta.vrednost > najboljsa.vrednost) {
					najboljsa = karta;
				}
			}
			return najboljsa;
		}
	}

	public static Vector<Karta> dobiBoljseKarteGledeNaZaporedje(
			Vector<Karta> karteNaMizi, Vector<Karta> veljavne) {
		Karta najboljsa = dobiNajboljsoKartoNaMizi(karteNaMizi);
		Vector<Karta> mojeBoljse = new Vector<Karta>();
		for (Karta karta : veljavne) {
			if ((karta.barva == najboljsa.barva && karta.vrednost > najboljsa.vrednost)
					||
				(karta.barva == Barva.TAROK && najboljsa.barva != Barva.TAROK ) ) {
				mojeBoljse.add(karta);
			}
		}
		return mojeBoljse;
	}

	public static boolean vsebujeKarto(Vector<Karta> karte, Barva barva,
			int vrednost) {
		for (Karta karta : karte) {
			if (karta.barva == barva && karta.vrednost == vrednost) {
				return true;
			}
		}
		return false;
	}

	public static Integer indeksKarte(Vector<Karta> karte, Barva barva,
			int vrednost) {
		int i = 0;
		for (Karta karta : karte) {
			if (karta.barva == barva && karta.vrednost == vrednost) {
				return i;
			}
			i++;
		}
		return null;
	}
	
	public static int dobiIndexNajboljseKarteNaMizi(Vector<Karta> karte) {
		if (karte.size() > 4) {
			throw new IllegalArgumentException();
		}
		
		Karta najboljsoKartaNaMizi = dobiNajboljsoKartoNaMizi(karte);
		return karte.indexOf(najboljsoKartaNaMizi);
	}

	public static Karta dobiNajboljsoKartoVBarvi(Vector<Karta> karte,
			Barva barva) {
		Vector<Karta> samoDoloceneBarve = dobiSamoDoloceneBarve(karte, getSetFromElements(barva));
		return dobiNajboljsoBarvnoKarto(samoDoloceneBarve);
	}
	
	
	public static <E> Set<E> getSetFromElements(E... elements) {
		return new HashSet<E>(Arrays.asList(elements));
	}
	public static String lepIzpis(Vector<Karta> karteNaMizi) {
		StringBuilder sb = new StringBuilder();
		for (Karta karta : karteNaMizi) {
			sb.append(karta.lepIzpis());
			sb.append(" ");
		}
		return sb.toString();
	}
	
	public static Vector<Karta> urediKarte(Vector<Karta> mojeKarte) {
		Vector<Karta> out = new Vector<Karta>();
		for (Barva barva : Barva.values()) {
			Vector<Karta> tempKarte = dobiSamoDoloceneBarve(mojeKarte, getSetFromElements(barva));
			Collections.sort((List) tempKarte, new Comparator<Karta>() {
				@Override
				public int compare(Karta k1, Karta k2) {
					if (k1.vrednost < k2.vrednost) return -1;
					if (k1.vrednost > k2.vrednost) return 1;
					return 0;
				}
			});
			out.addAll(tempKarte);
		}
		return out;
	}
	
}
