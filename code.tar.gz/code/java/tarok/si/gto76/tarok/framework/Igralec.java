package si.gto76.tarok.framework;

import java.util.Vector;

import si.gto76.tarok.IgralecNeumni;
import si.gto76.tarok.IgralecRandom;
import si.gto76.tarok.IgralecZacetnik;
import si.gto76.tarok.IgralecZacetnik02;
import si.gto76.tarok.IgralecZacetnik03;
import si.gto76.tarok.IgralecZacetnik04;
import si.gto76.tarok.IgralecZivi;
import si.gto76.tarok.KonkretniIgralec;

public class Igralec {
    //static KonkretniIgralec ig = new IgralecRandom();
    //static KonkretniIgralec ig = new IgralecZacetnik();
    //static KonkretniIgralec ig = new IgralecZacetnik02();
    //static KonkretniIgralec ig = new IgralecZacetnik03();
	static KonkretniIgralec ig = new IgralecZacetnik04();
	//static KonkretniIgralec ig = new IgralecZivi();
	   
    public static String Ime = ig.getIme();
    Vector<Karta> karte;

    public Igralec() {
    }

    public TipIgre zacniIgro(Vector<Karta> karteZaVRoko) {
		return ig.zacniIgro(karteZaVRoko);
    
    }
    
    public void zalozi(Vector<Karta> karte, Vector<Vector<Karta>> talon, Vector<Karta> vzete, Vector<Karta> zalozene) {
    	ig.zalozi(karte, talon, vzete, zalozene);
    }

    public void zacniRedniDel(int idxIgralca, int glavniIgralec, TipIgre tipIgre, Vector<Karta> ostanekTalona, Vector<Karta> pobraneKarteTalona) {
    	ig.zacniRedniDel(idxIgralca, glavniIgralec, tipIgre, ostanekTalona, pobraneKarteTalona);
    }
    
    public Karta vrziKarto(Vector<Karta> mojeKarte, Vector<Karta> karteNaMizi, int prviIgralec) {
		return ig.vrziKarto(mojeKarte, karteNaMizi, prviIgralec);
    }
    
    public void konecKroga(boolean zmagal, int prviIgralecVKrogu, int zmagovalec, Vector<Karta> karteNaMizi) {
    	ig.konecKroga(zmagal, prviIgralecVKrogu, zmagovalec, karteNaMizi);
    }
    
    public void KonecIgre(String razlog) {
    	ig.KonecIgre(razlog);
    }
}
