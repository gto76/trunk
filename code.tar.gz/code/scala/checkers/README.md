CHECKERS

Simple checkers game written in Scala.
