package si.gto76.checkers

import javax.swing.SwingUtilities
import javax.swing.JFrame
//import console.TextConsole
import java.awt.BorderLayout
//import console.ConsoleAPI
import java.awt.Color
//import si.gto76.checkers.console.KeyEventConnector

// TODO: add draw condition (three consecutive same moves)
// TODO: optional time limit for computer
// TODO: option for random selection of moves with same score
// TOD: parameter for closenes algorithm selection

object Checkers {
	
	var display: Display = _
	
	def main(args: Array[String]) {
		
		val connector = new EventConnector
		display = new Display(connector)
		display.startup(Array("","")) //array has no meaning
		
		object spParams1 extends SmartPlayerParams(5, 0.5);
		val playerWhite: Player = new SmartPlayer("D.H. Whitey", PieceColor.White, spParams1)
		
		object spParams2 extends SmartPlayerParams(4, 0.5);
		val playerBlack: Player = new SmartPlayer("Mr Black", PieceColor.Black, spParams2)
		
		//val playerBlack: Player = new RandomPlayer("Mr. Black")
		//val playerBlack: Player = new HumanPlayer("D.H. Whitey", connector)
		//val playerBlack: Player = new HumanPlayer("Mr Black", connector)
		
		val game = new Game(playerWhite, playerBlack, print)
		val winner = game.start
		
	}
	
	def print(state: GameState, selection: Option[Turn]): Unit = {
		display.changeState(state, selection)
	}
	
}