package si.gto76.checkers

object CheckersStartingPosition {
	def get = {
		 	List(  		new Piece(PieceColor.White, LegalPosition.get(0,1), false), 
				  		new Piece(PieceColor.White, LegalPosition.get(0,3), false),
				  		new Piece(PieceColor.White, LegalPosition.get(0,5), false),
				  		new Piece(PieceColor.White, LegalPosition.get(0,7), false),
				  		new Piece(PieceColor.White, LegalPosition.get(1,0), false),
				  		new Piece(PieceColor.White, LegalPosition.get(1,2), false),
				  		new Piece(PieceColor.White, LegalPosition.get(1,4), false),
				  		new Piece(PieceColor.White, LegalPosition.get(1,6), false),
				  		new Piece(PieceColor.White, LegalPosition.get(2,1), false),
				  		new Piece(PieceColor.White, LegalPosition.get(2,3), false),
				  		new Piece(PieceColor.White, LegalPosition.get(2,5), false),
				  		new Piece(PieceColor.White, LegalPosition.get(2,7), false),
  
				  		new Piece(PieceColor.Black, LegalPosition.get(5,0), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(5,2), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(5,4), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(5,6), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(6,1), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(6,3), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(6,5), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(6,7), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(7,0), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(7,2), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(7,4), false),
				  		new Piece(PieceColor.Black, LegalPosition.get(7,6), false) )
	}
}