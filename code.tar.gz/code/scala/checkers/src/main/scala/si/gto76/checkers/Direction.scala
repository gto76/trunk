package si.gto76.checkers

object Dir extends Enumeration {
	val N = Value
	val E = Value
	val S = Value
	val W = Value
}

object DiagDir extends Enumeration {
	val NW = Value
	val NE = Value
	val SE = Value
	val SW = Value
	//val all = List(DiagDir.NW, DiagDir.NE, DiagDir.SE, DiagDir.SW) 
	// Changed for human player convinience. 
	val all = List(DiagDir.SW, DiagDir.SE, DiagDir.NE, DiagDir.NW)
	def get(dir: Dir.Value) = {
		(dir) match {
			case (Dir.N) => List(DiagDir.NW, DiagDir.NE)
			case (Dir.E) => List(DiagDir.NE, DiagDir.SE)
			case (Dir.S) => List(DiagDir.SE, DiagDir.SW)
			case (Dir.W) => List(DiagDir.SW, DiagDir.NW)
		}
	}
	def is(diagDir: DiagDir.Value, dir: Dir.Value) = {
		(diagDir, dir) match {
			case (NW, Dir.N) => true
			case (NE, Dir.N) => true
			case (SE, Dir.N) => false
			case (SW, Dir.N) => false
			
			case (NW, Dir.E) => false
			case (NE, Dir.E) => true
			case (SE, Dir.E) => true
			case (SW, Dir.E) => false
			
			case (NW, Dir.S) => false
			case (NE, Dir.S) => false
			case (SE, Dir.S) => true
			case (SW, Dir.S) => true
			
			case (NW, Dir.W) => true
			case (NE, Dir.W) => false
			case (SE, Dir.W) => false
			case (SW, Dir.W) => true
		}
	}
}