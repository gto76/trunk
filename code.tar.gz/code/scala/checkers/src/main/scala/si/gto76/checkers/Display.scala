package si.gto76.checkers

import scala.swing._
import scala.swing.event._
import java.awt.Color
import java.awt.Dimension
import javax.swing.Icon
import javax.swing.ImageIcon
import java.awt.Image

class Display(connector: EventConnector) extends SimpleSwingApplication {
	val NO_OF_ROWS = 8
	
	val DATA_DIR = "./data/"
	  
	val BLACK = DATA_DIR + "black.gif"
	val BLACK_SEL = DATA_DIR + "blackSel.gif"
	val BLACK_KING = DATA_DIR + "blackKing.gif"
	val BLACK_KING_SEL = DATA_DIR + "blackKingSel.gif"
	val WHITE = DATA_DIR + "red.gif"
	val WHITE_SEL = DATA_DIR + "redSel.gif"
	val WHITE_KING = DATA_DIR + "redKing.gif"
	val WHITE_KING_SEL = DATA_DIR + "redKingSel.gif"
	val EMPTY = DATA_DIR + "empty.gif"
	val EMPTY_SEL = DATA_DIR + "emptySel.gif"
	val OTHER = DATA_DIR + "otherField.gif"
	
	var labels: Map[Position, Label] = Map()
	
	for (i <- 0 to NO_OF_ROWS-1) {
		for (j <- 0 to NO_OF_ROWS-1) {
			val position = new Position(i,j)
			val label = new Label
			if (!position.isLegal)
				label.icon_=(new ImageIcon(OTHER))
			else {
				val legPos = position.getLegalPosition
				if (InitialGameState.state.isFieldEmpty(legPos))
					label.icon_=(new ImageIcon(EMPTY))
				else {
					val piece = InitialGameState.state.getPieceOcupyingPosition(legPos)
					val filename = getFilename(piece.color, piece.knighted, false)
					label.icon_=(new ImageIcon(filename))
				}
			}
			labels += (position -> label)
		}
	}
	
	private def getFilename(barva: PieceColor.Value, king: Boolean, selected: Boolean) = {
		(barva, king, selected) match {
			case (PieceColor.White, false, false) => WHITE
			case (PieceColor.White, true, false) => WHITE_KING
			case (PieceColor.Black, false, false) => BLACK
			case (PieceColor.Black, true, false) => BLACK_KING
			case (PieceColor.White, false, true) => WHITE_SEL
			case (PieceColor.White, true, true) => WHITE_KING_SEL
			case (PieceColor.Black, false, true) => BLACK_SEL
			case (PieceColor.Black, true, true) => BLACK_KING_SEL
			case _ => throw new Exception("WTF")
		}
	}
	
	//******
	def top = new MainFrame {
		title = "Checkers"
		contents = new BoxPanel(Orientation.Vertical) {
			for (i <- 0 to NO_OF_ROWS-1) {
				contents += new BoxPanel(Orientation.Horizontal) {
					for (j <- 0 to NO_OF_ROWS-1) {
						val optionLabel = labels.get(new Position(i,j))
						contents += optionLabel.get
					}
				}
			}

			listenTo(keys)
            reactions += {
				case KeyPressed(_, b, _, _) =>
					connector.keyPressed(b.id);
            }
            focusable = true
            requestFocus
            
		}
		
	}	
	
	def changeState(state: GameState, turn: Option[Turn]) = {
		for (i <- 0 to NO_OF_ROWS-1) {
			for (j <- 0 to NO_OF_ROWS-1) {
				val pos = new Position(i,j)
				if (pos.isLegal) {
					val legPos = pos.getLegalPosition
					val label = labels(pos)
					val selected = { 
						if (turn==None || !turn.get.containsPosition(legPos))
							false
						else
							true
					}
					if (state.isFieldEmpty(legPos))
						if (selected)
							label.icon_=(new ImageIcon(EMPTY_SEL))
						else
							label.icon_=(new ImageIcon(EMPTY))
					else {
						val piece = state.getPieceOcupyingPosition(legPos)
						val filename = getFilename(piece.color, piece.knighted, selected)
						label.icon_=(new ImageIcon(filename))
					}
				}
			}
		}
	}
	
}
