package si.gto76.checkers;

class EventConnector {
	var lastKey: Option[Int] = None
	def keyPressed(vkLeft: Int) = {
		lastKey = Some(vkLeft)
	}
	def getLastKey() = {
		val keyTemp = lastKey
		lastKey = None
		keyTemp
	}
}