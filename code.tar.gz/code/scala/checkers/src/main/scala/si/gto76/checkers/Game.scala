package si.gto76.checkers

class Game(playerWhite: Player, playerBlack: Player, printConsole: (GameState, Option[Turn]) => Unit) {
  val DEBUG = 0;
  
  private var whosNext: Player = playerWhite
  private var gamestate = InitialGameState.state

  //***//
  def start = {
	  printConsole(gamestate, None)
	  
	  while(!gamestate.isStateFinal) { 	
	  	val legalTurns = gamestate.getLegalTurns
	  	if (DEBUG>0) print("Legal turns: "+legalTurns+"\n")
	  	val playersTurn = whosNext.move(legalTurns, gamestate, printGamestateWithSelTurn(_))
	  	if (DEBUG>0) print("Players turn: "+playersTurn+"\n")
	  	if (!legalTurns.contains(playersTurn))
	  		throw new Exception("Player "+whosNext+" made illegal turn "+playersTurn+".")
	  	gamestate = gamestate.getNewState(playersTurn)
	  	printConsole(gamestate, None)
	  	changePlayer
	  }
	  
	  val winner = gamestate.whoWon.get
	  print("Winner is "+winner)
  }
  //***//
  
  private def changePlayer = {
  	if (whosNext == playerWhite)
  		whosNext = playerBlack
  	else
  		whosNext = playerWhite
  }
  def printGamestateWithSelTurn(turn: Turn) {
  	printConsole(gamestate, Some(turn))
  }
  
}