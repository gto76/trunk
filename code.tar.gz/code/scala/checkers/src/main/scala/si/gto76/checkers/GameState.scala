package si.gto76.checkers

object InitialGameState {
  val whosNext = PieceColor.White
  val pieces: List[Piece] = CheckersStartingPosition.get
  val state = new GameState(whosNext, pieces)
}

class GameState(whosNext: PieceColor.Value, pieces: List[Piece]) {
  val DEBUG = false
  //****
  def getSymbolAtPosition(posIn: Position): String = {
    for (piece <- pieces)
  	  if (piece.getPosition.equals(posIn)) return piece.toString()
    " "
  }
  
  def getPieces(color: PieceColor.Value) = {
  	var piecesOfColor: List[Piece] = Nil
  	for (piece <- pieces)
  		if (piece.color == color)
  			piecesOfColor = piece::piecesOfColor
  	piecesOfColor
  }
  
  def getPieces(color: PieceColor.Value, knighted: Boolean) = {
  	var piecesOfColor: List[Piece] = Nil
  	for (piece <- pieces)
  		if (piece.color == color && piece.knighted == knighted)
  			piecesOfColor = piece::piecesOfColor
  	piecesOfColor
  }
  
  def getNewState(turn: Turn): GameState = {
    // Takes the piece that is at the start out.
  	var movingPiece = getPieceOcupyingPosition(turn.startingPosition)
  	var newPieces = pieces.filterNot(_==movingPiece)
  	movingPiece = movingPiece.setPosition(turn.endPosition)
  	newPieces = movingPiece::newPieces
  	newPieces = knightAsNecesary(newPieces)
  	
  	// If it's move, then just move it there.
  	if (turn.isMove) {
  		new GameState(PieceColor.getOther(whosNext), newPieces)
  	}
  	// If there are jumps, then move it on the final position and eat jumped pieces.
  	else {
  		for (jumpedPosition <- turn.getJumpedPositions)
  			newPieces = removePieceFromPosition(newPieces, jumpedPosition)
  		new GameState(PieceColor.getOther(whosNext), newPieces)
  	}
  }
  
  def knightAsNecesary(pieces: List[Piece]):List[Piece] = {
  	var piecesOut = pieces
  	for (piece <- pieces) {
  		if (!piece.knighted && piece.hasReachedOtherEnd) {
  			piecesOut = piecesOut.filterNot(_==piece)
  			piecesOut = new Piece(piece.color, piece.getPosition, true)::piecesOut
  			return piecesOut
  		}
  	}
  	pieces
  }
  
  // static
  def removePieceFromPosition(piecesIn: List[Piece], pos: LegalPosition): List[Piece] = {
  	var piecesOut: List[Piece] = Nil
  	for (piece <- piecesIn)
  		if (piece.getPosition == pos)
  			piecesOut = piecesIn.filterNot(_==piece)
  	piecesOut
  }
  
  var legalTurnsCache: Option[List[Turn]] = None
  def getLegalTurns: List[Turn] = {
  	// Cache check.
  	if (legalTurnsCache != None)
  		return legalTurnsCache.get
  	// Looks who's on the move, scans all of his pieces and checks it's legal moves.
  	val pieces = getPieces(whosNext)
  	var jumpFlag = false
  	var legalTurns: List[Turn] = Nil
  	for (piece <- pieces) {
  		val jumps: List[Turn] = getJumpsForPiece(piece)
  		// If there's still no jump.
  		if(!jumpFlag) {
  			if(jumps == Nil) {
  				legalTurns = getMovesForPiece(piece):::legalTurns
  			} else {
  			    // Found first jump.
  				legalTurns = jumps
  				jumpFlag = true
  			}
  		} else {
  			legalTurns = jumps:::legalTurns
  		}
  	}
  	legalTurnsCache = Option(legalTurns)
  	legalTurns
  }
  
  // 2. If Jumps: every jump must make all available captures in the chosen sequence. 
  // Uses recursion.
  def getJumpsForPiece(piece: Piece): List[Turn] = {
  	if (DEBUG) print("\ngetJumpsForPiece START")
  	var jumps: List[Turn] = Nil
  	for (direction <- piece.getPosition.getInboundJumps) {
  	  val jump: Option[Turn] = getJump(piece, direction)
  	  if (jump != None) {
  	  	val jumpVal: Turn = jump.get
  	  	if (DEBUG) print("\njump "+jump)
  	  	
  	  	val jumpDestination = jumpVal.lastMove.get
  	  	if (DEBUG) print("\njumpDestination "+jumpDestination)

  	  	var newPieces = pieces.filterNot(_==piece)
  	  	// remove jumped pieces:
  	  	for (jumpedLoc <- jumpVal.getJumpedPositions)
  	  		newPieces = removePieceFromPosition(newPieces, jumpedLoc) 
  	    val newPiece = piece.setPosition(jumpDestination)
  	    newPieces = newPiece::newPieces
  	    val newGameState = new GameState(whosNext, newPieces)
  	  	
  	  	if (DEBUG) print("\nRecursion START")
  	  	val returnedJumps: List[Turn] = newGameState.getJumpsForPiece(newPiece)
  	    if (DEBUG) print("\nRecursion END")
  	    
  	    if (returnedJumps == Nil) {
  	    	jumps = jumpVal::jumps
	  	} else {
	  	    for (returnedJump <- returnedJumps) {
	  	    	if (DEBUG) print("\nreturnedJump "+returnedJump)
	  	    	//glues returned jump to jump and adds to jumps
	  	    	val concateratedJump = jumpVal.concatAtTail(returnedJump)
	  	    	if (DEBUG) print("\nconcateratedJump "+concateratedJump)
	  	    	jumps = concateratedJump::jumps
	  	    }
	  	}
  	  }
  	}  
  	if (DEBUG) print("\ngetJumpsForPiece END\n\n")
  	jumps
  }
  
  
  def getJump(piece: Piece, direction: DiagDir.Value): Option[Turn] = {
	if (!piece.knighted && isBackward(piece.color, direction))
  		return None
  	val position = piece.getPosition
  	val oponentsPosition = position.newPositionMove(direction)
  	val newPosition = position.newPositionJump(direction)
  	if (isFieldEmpty(newPosition) && isFieldOcupatedBy(oponentsPosition, PieceColor.getOther(piece.color)))
  		Some(new Turn(position::newPosition::Nil))
  	else
  		None
  }
  
  def getMovesForPiece(piece: Piece) = {
  	var moves: List[Turn] = Nil
  	for (direction <- piece.getPosition.getInboundMoves) {
  	  moves = getMove(piece, direction):::moves
  	}
  	moves
  }
  
  def getMove(piece: Piece, direction: DiagDir.Value): List[Turn] = {
  	if (!piece.knighted && isBackward(piece.color, direction))
  		return Nil
  	val position = piece.getPosition
  	val newPosition = position.newPositionMove(direction)
  	if (isFieldEmpty(newPosition))
  		new Turn(position::newPosition::Nil)::Nil
  	else
  		Nil
  }
  
  def isBackward(color: PieceColor.Value, direction: DiagDir.Value): Boolean = {
  	if (color == PieceColor.White && DiagDir.is(direction, Dir.N))
  		return true
  	if (color == PieceColor.Black && DiagDir.is(direction, Dir.S))
  		return true
  	false
  }
  
  def isFieldEmpty(pos: LegalPosition): Boolean = {
  	for (piece <- pieces)
  		if (piece.getPosition == pos)
  			return false
  	true
  }
  
  def isFieldOcupatedBy(pos: LegalPosition, color: PieceColor.Value): Boolean = {
  	for (piece <- pieces)
  		if ( piece.getPosition == pos && piece.color == color)
  			return true
  	false
  }
  
  def getPieceOcupyingPosition(pos: LegalPosition): Piece = {
  	for (piece <- pieces)
  		if ( piece.getPosition == pos)
  			return piece
  	throw new IllegalArgumentException("No piece on position "+pos)
  }
  
  def isStateFinal: Boolean = {
  	if (getLegalTurns == Nil)
  		true
  	else
  		false
  }
  
  def whoWon: Option[PieceColor.Value] = {
  	if (!isStateFinal)
  		None
  	else
  		Option(PieceColor.getOther(whosNext))
  }
  
  def noOfPieces (clr: PieceColor.Value) = {
	getPieces(clr).size
  }
  
  def noOfKnightedPieces(clr: PieceColor.Value) = {
	noOfKnightedPiecesUtil(getPieces(clr))
  }
  def noOfKnightedPiecesUtil(pieces: List[Piece]) = {
    var count = 0
    for (piece <- pieces)
      if (piece.knighted)
        count=count+1
    count
  }  

  // To String //
  override def toString = {
  	genericToString("", (_: Int) => "", None)
  }
  def toStringWithAnot = {
  	genericToString("   0   1   2   3   4   5   6   7  \n", (x: Int) => x.toString(), None)
  }
  def toStringWithSelector(selPos: LegalPosition) = {
  	genericToString("", (_: Int) => "", Option(List(selPos)))
  }
  def toStringWithSelectorTurn(turn: Turn) = {
  	genericToString("", (_: Int) => "", Some(turn.moves))
  }
  
  def genericToString(header: String, f: (Int) => String, selPos: Option[List[LegalPosition]]) = {
    val out = new StringBuilder
    out.append(header)
    for (i <- 0 to 7) {
      out.append("---------------------------------\n")
      out.append(f(i))
      for (j <- 0 to 7) {
      	
      	  if (selPos!=None && selPos.get.exists(new Position(i,j)==_)) {
		     out.append("|[")
		     out.append(getSymbolAtPosition(new Position(i,j)))
		     out.append("]")
	      }
      	  else {
	        out.append("| ")
	        out.append(getSymbolAtPosition(new Position(i,j)))
	        out.append(" ")
	      }
      }
      out.append("|\n")
    }
    out.append("---------------------------------\n")  
    out.toString()
  }
  
}