package si.gto76.checkers

import scala.collection.immutable.List
//import si.gto76.checkers.console.KeyEventConnector
import java.awt.event.KeyEvent

class HumanPlayer(name: String, connector: EventConnector) extends Player(name) {

	def move(possibleMoves: List[Turn], state: GameState, printBoard: (Turn) => Unit): Turn = {
		printBoard(possibleMoves.head)
		var selMove = 0
		
		var keyPressed = keyPressConverter(connector)
		
		while (keyPressed != KeyEvent.VK_ENTER) {
			if ((keyPressed == KeyEvent.VK_LEFT) && selMove>0) {
				selMove = selMove-1
				printBoard(possibleMoves(selMove))
			} 
			else if (keyPressed == KeyEvent.VK_RIGHT && selMove<possibleMoves.size-1) {
				selMove = selMove+1
				printBoard(possibleMoves(selMove))
			}
			keyPressed = keyPressConverter(connector)
			Util.waiting(0.05)
		}
		possibleMoves(selMove)
	}
	
	def keyPressConverter(con: EventConnector): Int = {
		val key = connector.getLastKey()
		if (key==None)
			0
		else
			key.get.asInstanceOf[Int]
	}
}