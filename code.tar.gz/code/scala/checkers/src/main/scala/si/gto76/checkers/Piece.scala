package si.gto76.checkers

class Piece(val color: PieceColor.Value, val position: LegalPosition, val knighted: Boolean) {
	
	def getPosition = position
	def setPosition(newPosition: LegalPosition): Piece = {
		if (!knighted) {
			if (hasMovedBackward(newPosition))
				throw new IllegalArgumentException("Illegal backward move: " +position+ " " +newPosition+ ".")
		}
		new Piece(color, newPosition, knighted)
	}
	
	def hasMovedBackward(newPosition: LegalPosition): Boolean = {
		if ((color == PieceColor.White) && (newPosition.ver < position.ver)) 
		  return true
		if ((color == PieceColor.Black) && (newPosition.ver > position.ver))
		  return true
		false
	}
	
	def hasReachedOtherEnd(): Boolean = {
		if ((color == PieceColor.White) && (position.ver == 7 ))
			return true
		if ((color == PieceColor.Black) && (position.ver == 0 ))
			return true
		false
	}
	
	def distanceToOtherEnd(): Int = {
	  if (color == PieceColor.White) {
	    7 - position.ver
	  } else {
	    position.ver
	  }
	}
	
	override def toString: String = {
		if (!knighted) 
			return PieceColor.getSymbol(color)
		else 
			return PieceColor.getSymbolKnighted(color)
	}
	
	def toStringInfo: String = {
		toString + position
	}
}