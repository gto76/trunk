package si.gto76.checkers

object PieceColor extends Enumeration {
	val Black = Value
	val White = Value
	def getOther(color: PieceColor.Value) = {
	   if (color == PieceColor.Black) White
	   else Black
	}
	def getSymbol(color: PieceColor.Value) = {
	   if (color == PieceColor.Black) "x"
	   else "o"
	}
	def getSymbolKnighted(color: PieceColor.Value) = {
	   if (color == PieceColor.Black) "X"
	   else "0"
	}
}