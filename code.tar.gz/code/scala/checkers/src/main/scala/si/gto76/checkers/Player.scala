package si.gto76.checkers

abstract class Player(val name: String) {
	def move(possibleMoves: List[Turn], state: GameState, printBoard: (Turn) => Unit): Turn	
}