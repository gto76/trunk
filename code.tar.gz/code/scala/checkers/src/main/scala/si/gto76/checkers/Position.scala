package si.gto76.checkers

import java.math
import java.lang.Math
import scala.collection.mutable.Map
class Position(val ver: Int, val hor: Int) {
  if ((hor < 0) || (hor > 7) || (ver < 0) || (ver > 7) ) 
    throw new IllegalArgumentException("Position is out of bounds: " + hor + " " + ver + ".")
  override def hashCode = 41 * (41 + hor) + ver
  override def equals(other: Any) = other match {
  	case that: Position => this.hor == that.hor && this.ver == that.ver
  	case _ => false
  }
  override def toString = {
  	"["+ver+hor+"]"
  }
  def isLegal: Boolean = {
  	if ((hor + ver)%2 == 0)
  		return false
  	true
  }
  def getLegalPosition = {
  	LegalPosition.get(ver, hor)
  }
}

object LegalPosition {
	private var cache: Map[Int, LegalPosition] = Map()
	def get(ver: Int, hor: Int): LegalPosition = {
		val hash = ver*100 + hor
		if (cache.contains(hash)) {
			return cache(hash)
		} else {
			val legPos = new LegalPosition(ver, hor)
			cache += (hash -> legPos)
			return legPos
		}
	}
}

class LegalPosition(ver: Int, hor: Int) extends Position(ver, hor) {
	if ((hor + ver)%2 == 0)
      throw new IllegalArgumentException("Position is illegal: " + hor + " " + ver + ".")	
	
	def distanceTo(otherPosition: LegalPosition) = {
	  val deltaHor = Math.abs(this.hor - otherPosition.hor)
	  val deltaVer = Math.abs(this.ver - otherPosition.ver)
	  Math.max(deltaHor, deltaVer)
	}
	
	def newPositionMove(dir: DiagDir.Value) = {
		(dir) match {
			case (DiagDir.NW) => LegalPosition.get(ver-1, hor-1)
			case (DiagDir.NE) => LegalPosition.get(ver-1, hor+1)
			case (DiagDir.SE) => LegalPosition.get(ver+1, hor+1)
			case (DiagDir.SW) => LegalPosition.get(ver+1, hor-1)
			case (_) => throw new Exception("Unknown direction.")
		}
	}
	
	def newPositionJump(dir: DiagDir.Value) = {
		(dir) match {
			case (DiagDir.NW) => LegalPosition.get(ver-2, hor-2)
			case (DiagDir.NE) => LegalPosition.get(ver-2, hor+2)
			case (DiagDir.SE) => LegalPosition.get(ver+2, hor+2)
			case (DiagDir.SW) => LegalPosition.get(ver+2, hor-2)
			case (_) => throw new Exception("Unknown direction.")
		}
	}
	
	def getInboundMoves: List[DiagDir.Value] = {
		(ver, hor) match {
			case (0, 7) => List(DiagDir.SW)
			case (7, 0) => List(DiagDir.NE)
			
			case (0, _) => DiagDir.get(Dir.S)
			case (7, _) => DiagDir.get(Dir.N)
			
			case (_, 0) => DiagDir.get(Dir.E)
			case (_, 7) => DiagDir.get(Dir.W)
			
			case (_, _) => DiagDir.all
		}
	}
	
	def getInboundJumps: List[DiagDir.Value] = {
		if ( ver>1 && ver<6 && hor>1 && hor<6 )
			DiagDir.all
		
		else if ( ver<2 && hor>1 && hor<6 )
			DiagDir.get(Dir.S)
		else if ( ver>5 && hor>1 && hor<6 )
			DiagDir.get(Dir.N)
		else if ( ver>1 && ver<6 && hor<2)
			DiagDir.get(Dir.E)
		else if ( ver>1 && ver<6 && hor>5) //tle more bit >1 TODO!!!!!!
			DiagDir.get(Dir.W)
			
		else if ( ver<2 && hor<2 )
			DiagDir.SE::Nil
		else if ( ver<2 && hor>5 )
			DiagDir.SW::Nil
		else if ( ver>5 && hor>5 )
			DiagDir.NW::Nil
		else if ( ver>5 && hor<2 )
			DiagDir.NE::Nil
			
		else throw new Exception("Serious logical error in code!" +ver+" "+hor)
	}
}
