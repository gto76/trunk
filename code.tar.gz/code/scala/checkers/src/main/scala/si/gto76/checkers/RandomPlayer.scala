package si.gto76.checkers

import scala.collection.immutable.List

class RandomPlayer(name: String) extends Player(name) {
	def move(possibleMoves: List[Turn], state: GameState, printBoard: (Turn) => Unit): Turn = {
		if (possibleMoves == Nil)
			throw new IllegalArgumentException("No possible moves")
		Util.waiting(2)
		val size = possibleMoves.size
		val rand = Math.random
		val winningNumber: Int = (size*rand).asInstanceOf[Int]
		possibleMoves(winningNumber)
	}
}	

object Util {
	def waiting (seconds: Double) {
        val t0: Long = System.currentTimeMillis()
        var t1: Long = 0
        do{
            t1 = System.currentTimeMillis()
        }
        while ((t1 - t0) < (seconds * 1000))
    }
}