package si.gto76.checkers
import scala.math.Ordering

class SmartPlayerParams(val DEPTH: Int, val KNIGHT_FACTOR : Double)

class SmartPlayer(name: String, color: PieceColor.Value, params: SmartPlayerParams) extends Player(name) {
    val DEBUG = 1
  
	def move(possibleMoves: List[Turn], state: GameState, printBoard: (Turn) => Unit): Turn = {
		if (possibleMoves == Nil)
			throw new IllegalArgumentException("No possible moves")	
		
		//root - min, first - max, second - min...
		val root = new MinMaxTreeNode(state, color, None, 0, params)

		recursiveExpansion(root)
		
		val minChild = root.extChild
		val turn = minChild.turn.get
		
		if (DEBUG>=1) {
			print("\nPossible moves:\n")
			for (child <- root.children) {
			  print(child.turn.get +" "+ child.value+"\n")
			}
			print("Choose: "+turn+"\n\n")
		}
		turn
	}
    
    def recursiveExpansion(node: MinMaxTreeNode): Unit = {
      node.expandChildren
      if (node.generation < params.DEPTH) {
	      for (child <- node.children) {
	        if (!child.isStateFinal)
	        	recursiveExpansion(child)
		  }
      }
	  node.value = {
	    if(node.generation%2 == 0)
	      node.getMax
	    else
	      node.getMin
	  }
    }
	
}

class MinMaxTreeNode(state: GameState, myColor: PieceColor.Value, val turn: Option[Turn], 
						val generation: Int, params: SmartPlayerParams) {
	var value: Double = {
	  if (state.isStateFinal) {
	    if (state.whoWon.get==myColor)
	      100000-generation
	    else
	      -100000+generation
	  }
	  else {
	    val noOfMyKnights = state.noOfKnightedPieces(myColor)
		val myScore = state.noOfPieces(myColor) + noOfMyKnights*params.KNIGHT_FACTOR
		
	    val noOfOppKnights = state.noOfKnightedPieces(PieceColor.getOther(myColor))
		val oppScore = state.noOfPieces(PieceColor.getOther(myColor)) + noOfOppKnights*params.KNIGHT_FACTOR
		
		var distancePenately = 0
		val pieces = state.getPieces(myColor, false)
		for (myPiece <- pieces) {
		  distancePenately=distancePenately+myPiece.distanceToOtherEnd
		}
	    val penately=(distancePenately/(pieces.size+0.001))*0.0001
	    //val penately=(distancePenately)*0.000001
		
        (myScore-oppScore)-penately
	  }
	}
	
	var children: List[MinMaxTreeNode] = List()
	val isStateFinal = state.isStateFinal

	def expandChildren = {
		val legalTurns = state.getLegalTurns
		if (legalTurns.size == 0)
	      print("No legal turns")
		for (move <- legalTurns) {
			val newState = state.getNewState(move)
			val newNode = new MinMaxTreeNode(newState, myColor, Some(move), generation+1, params)
			children = newNode::children
		}
		
	}
	
	def getMax = {getExtreme(maxComp, -Double.MaxValue)}
	def maxComp(val1: Double, val2: Double) = {val1 > val2}
	
	def getMin= {getExtreme(minComp,Double.MaxValue)}
	def minComp(val1: Double, val2: Double) = {val1 < val2}
	
	var extChild: MinMaxTreeNode = _
	def getExtreme(comparator: (Double, Double) => Boolean, extreme: Double  ) : Double = {
	    if (state.isStateFinal)
	      return value
	  
		var ext = extreme
		for (child <- children) {
			if (comparator(child.value, ext)) {
				ext = child.value
				extChild = child
			}
		}
		ext	
	}
	
}