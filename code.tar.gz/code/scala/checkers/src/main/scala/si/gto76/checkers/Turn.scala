package si.gto76.checkers

class Turn(val moves: List[LegalPosition]) {
  var lastMove: Option[LegalPosition] = None

  if (moves.size < 2)
  	throw new IllegalArgumentException("Not a turn (less than two steps) "+moves+".")
  for (move <- moves) {
  	if (lastMove != None) {
  		if ( (lastMove.get.distanceTo(move) < 1)
  				|| (lastMove.get.distanceTo(move) > 2))
  			throw new IllegalArgumentException("Illegal move in turn: " +lastMove.get+ " to " +move+ ".")
  	}
    lastMove = Some(move)
  }
  
  def concatAtTail(tail: Turn): Turn = {
  	val newTurn = new Turn(moves:::(tail.moves.tail))
  	newTurn
  }
  def startingPosition: LegalPosition = {
  	moves.head
  }
  def endPosition: LegalPosition = {
  	moves.last
  }
  def containsPosition(position: LegalPosition): Boolean = {
  	for (pos <- moves)
  		if (pos==position)
  			return true
  	false
  }
  def isMove: Boolean = {
  	if ( moves.head.distanceTo(moves(1))==1 )
  		return true
  	false
  }
  def getJumpedPositions: List[LegalPosition] = {
  	var jumpedPositions: List[LegalPosition] = Nil
  	if (isMove)
  		return Nil
  	else {
  		for (i <- 1 to moves.size-1) {
  			val newVer = ((moves(i-1).ver+moves(i).ver)/2).asInstanceOf[Int]
  			val newHor = ((moves(i-1).hor+moves(i).hor)/2).asInstanceOf[Int]
  			val jumpedPos = LegalPosition.get(newVer, newHor)
  			jumpedPositions = jumpedPos::jumpedPositions
  		}
  	}
  	jumpedPositions
  }
  
  override def toString = {
  	val sb = new StringBuilder
  	sb.append("(")
  	var firstFlag = true
  	for (move <- moves) {
  		if (firstFlag) 
  			firstFlag = false
  		else
  			sb.append(",")
  		sb.append(move)
  	}
  	sb.append(")")
  	sb.toString()
  }
  
}