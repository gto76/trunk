package si.gto76.scaladaw

import javax.sound.sampled.AudioSystem
class Channel(masterChannelSend: Send) {
  /*
	val itemRecieves: List[Item] = List()
	val childRecieves: List[Channel] = List()
	val basicRecieves: List[Send] = List()
  */
  	var items: List[Item] = List()
	var recieves: List[Send] = List()
	
	var bufferId = -1
	var buffer = Array.fill[Double](SoundCard.EXTERNAL_BUFFER_SIZE)(0)
	val emptyBuf = Array.fill[Double](SoundCard.EXTERNAL_BUFFER_SIZE)(0)
	
	var components = new ComponentStack(this, masterChannelSend)
  	
  	def addComponent(component: Component) {
  	  components.addComponent(component)
  	} 
  	def addItem(item: Item) {
  	  items = item::items
  	}
  	def getSend() = {
  		val send = new Send
  		recieves = send::recieves
  		send
  	}

	// To bo potreboval samo master chanell -> vse ostalo se bo slo preko recievov!!!
	// tako da na koncu lahko tudi to skenslamo samo potem mora bit en master
	// recieve ki bo predstavljal zvo�no
	def getBuffer(id: Int) = {
  	  if (id == bufferId)
  	    buffer
  	  else {
  	  	  buffer = emptyBuf.clone()
  		  for (item <- items)
  			  buffer = sumBuffers(buffer, item.getBuffer(id))
  		  for (recieve <- recieves)
  			  buffer = sumBuffers(buffer, recieve.getBuffer(id))
  		  // ni dost more it �e skoz componenets chain!!!!!!! -> ni treba,
  			  // za to bo zadolzen RecievesToComponentsConnector
  		  bufferId = id
  		  buffer
  	  }
  	}
	
  	def sumBuffers(b1: Array[Double], b2: Array[Double]) = {
  	  if (b1.length > b2.length)
  	    sumBuffersUtil(b1, b2)
  	  else
  	    sumBuffersUtil(b2, b1)
  	}
	
  	def sumBuffersUtil(longer: Array[Double], shorter: Array[Double]) = {
  	    var bufferOut: Array[Double] = longer.clone()
  	    for (i <- 0 to shorter.length-1) {
  	      bufferOut(i) = bufferOut(i) + shorter(i)
  	    }  	  
  	    bufferOut
  	}
}