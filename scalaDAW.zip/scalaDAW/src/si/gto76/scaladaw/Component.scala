package si.gto76.scaladaw

abstract class Component() {
  var predecessor: Component = _
  def getBuffer(id: Int): Array[Double]
}