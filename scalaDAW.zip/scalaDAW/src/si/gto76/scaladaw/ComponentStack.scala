package si.gto76.scaladaw

class ComponentStack(channel: Channel, masterSend: Send) {
  val connector = new RecievesToComponentsConnector(channel)
  var components: List[Component] = List()
  val fader = new Gain()
  fader.predecessor = connector
  masterSend.predecessor = fader
  	
  def addComponent(component: Component) {
    component.predecessor = connector
    if (components.nonEmpty)
      components.head.predecessor = connector
    if (components.isEmpty)
      fader.predecessor = component
    components = component::components
  }

}