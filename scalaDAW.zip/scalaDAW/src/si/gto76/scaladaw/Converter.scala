package si.gto76.scaladaw

import javax.sound.sampled.AudioFormat

object Converter {

  //////TO FP//////
  def convertBufferToFP(format: AudioFormat, byteBuffer: Array[Byte]) = {
    //format.getChannels()    //format.getEncoding()
    //format.getFrameRate()    //format.getFrameSize()
    //format.getSampleRate()
    val bytesPerSample = format.getSampleSizeInBits() / 8
    val bigEndian = format.isBigEndian()
    
    val numberOfSamples = byteBuffer.size / bytesPerSample
    val fPointBuffer = Array.fill[Double](numberOfSamples)(0) //! a se da brez da nafilas?

    for (i <- 0 to numberOfSamples-1) {
      val position = i*bytesPerSample
      val slice = byteBuffer.slice(position, position+bytesPerSample) //! nimam resitve
      fPointBuffer(i) = convertSampleToFp(bigEndian, slice)
    }
    //print(byteBuffer(4)+" -> "+fPointBuffer(4)+"\n")
    fPointBuffer
  }

  def convertSampleToFp(bigEndian: Boolean, slice: Array[Byte]) = {
    var sl = slice
    /*
    if (bigEndian)
      sl = slice.reverse
    */
    var i = 0
    var sum = 0.0
    for (byte <- slice) {
      sum = sum + byte*pow2(i*8) //SIGNED-UNSIGNED!!!
      i = i+1
    }
    val out = sum / pow2(slice.size*8) 
    //print("in: "+slice(0)+" out: "+out+"\n")
    out
  }
  
  def pow2 (factor: Int) = {
	factor match {
		case 8 => 256
		case 16 => 65536
		case 24 => 16777216
		case _ => Math.pow(2, factor)
	}
  }
  
  //////FROM FP/////
  def convertBufferToByte(format: AudioFormat, fpBuffer: Array[Double]) = {
    val bytesPerSample = format.getSampleSizeInBits() / 8
    val bigEndian = format.isBigEndian()

    val numberOfBytes = fpBuffer.size * bytesPerSample
    val byteBuffer = Array.fill[Byte](numberOfBytes)(0)
    
    for (i <- 0 to fpBuffer.size-1) {
      val position = i*bytesPerSample
      val bytesSlice = convertSampleToByte(bigEndian, bytesPerSample, fpBuffer(i))
      for (j <- 0 to bytesSlice.size-1) {
    	byteBuffer(position+j) = bytesSlice(j)
      }
    }
    //print(fpBuffer(4)+" -> "+byteBuffer(4)+"\n\n")
    byteBuffer
  }
  
  def convertSampleToByte(bigEndian: Boolean, bytesPerSample: Int, fpSample: Double) = {
    var bytesSlice: Array[Byte] = Array.fill[Byte](bytesPerSample)(0)
    var intSample = { 
	  if (fpSample < 1.0)
	    (fpSample * pow2(bytesPerSample*8)).asInstanceOf[Int]
	  else
	    pow2(bytesPerSample*8).asInstanceOf[Int] //: clip
    }
    
    for (i <- 0 to bytesPerSample-1) {
    	bytesSlice(i) = ((intSample % pow2((i+1)*8)) / pow2(i*8)).asInstanceOf[Byte]
    }
    /*
    if(bigEndian) {
      bytesSlice = bytesSlice.reverse
    }
    */
    /*
    print("in: "+fpSample+" int: "+ intSample +" out: ")
    for (byte <- bytesSlice)
      print(byte+" ")
    print("\n")
    */
    bytesSlice
  }

}