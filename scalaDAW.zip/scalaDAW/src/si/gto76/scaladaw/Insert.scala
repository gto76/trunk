package si.gto76.scaladaw

abstract class Insert() extends Component {

  var signalIn: Array[Double] = _
  var signalOut: Array[Double] = Array.fill[Double](SoundCard.EXTERNAL_BUFFER_SIZE)(0)

  var parameters: InsertParameters = _

  var bufferId = -1

  def getBuffer(id: Int) = {
	if (id == bufferId)
	  signalOut
	else {
	  signalIn = predecessor.getBuffer(id)
	  run
	  bufferId = id
	  signalOut
	}
  }

  def run
  def setParameters(parameters: InsertParameters) = {
    this.parameters = parameters
  }
}

abstract class InsertParameters {
}
