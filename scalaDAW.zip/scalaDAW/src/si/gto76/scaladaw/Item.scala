package si.gto76.scaladaw

import java.io.File
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.DataLine
import javax.sound.sampled.SourceDataLine

//class Item(fileName: String, start: Int, end: Int, gain: Double, fadeIn: Int, fadeOut: Int) {
class Item(fileName: String) {

  val soundFile = new File(fileName)
  val audioInputStream: AudioInputStream = try {
    AudioSystem.getAudioInputStream(soundFile)
  }
  val audioFormat = audioInputStream.getFormat();
  
  var bufferId = -1
  var bufferByte = Array.fill[Byte](SoundCard.EXTERNAL_BUFFER_SIZE)(0)
  var bufferFp = Array.fill[Double](SoundCard.EXTERNAL_BUFFER_SIZE)(0)

  def getBuffer(id: Int) = {
	if (id == bufferId)
	  bufferFp
	else {
      audioInputStream.read(bufferByte, 0, bufferByte.length)
      bufferFp = Converter.convertBufferToFP(audioFormat, bufferByte)
	  bufferId = id
	  bufferFp
	}
  }
}
