package si.gto76.scaladaw

class Project {
	val masterChannel = new Channel(SoundCard.soundCardSend)
	var channels: List[Channel] = List()
	
	def addChannel() = {
	  val channel = new Channel(masterChannel.getSend())
	  channels = channel::channels
	}
	
	def addChannel(fileName: String) = {
	  val item = new Item(fileName)
	  val channel = new Channel(masterChannel.getSend())
	  channel.addItem(item)
	  channels = channel::channels
	}
	
	def removeChannel = {
	  channels = channels.tail
	}
	
}