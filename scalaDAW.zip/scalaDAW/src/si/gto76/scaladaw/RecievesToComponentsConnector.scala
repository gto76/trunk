package si.gto76.scaladaw

class RecievesToComponentsConnector(channel: Channel) extends Component {
  def getBuffer(id: Int) = {
    channel.getBuffer(id)
  }
}