package si.gto76.scaladaw

import java.io.File
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.DataLine
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.LineUnavailableException
import java.io.IOException
import scala.util.parsing.combinator.testing.Number

object ScalaDAW {
 
  var fileName: String = _
	
  def main(args: Array[String]) {
  	fileName = args(0)
	val project = new Project
	project.addChannel(fileName)
	SoundCard.play
  }
  
}







