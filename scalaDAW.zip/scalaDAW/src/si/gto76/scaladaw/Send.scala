package si.gto76.scaladaw

class Send() extends Component {
    
  var bufferId = -1
  var buffer = Array.fill[Double](SoundCard.EXTERNAL_BUFFER_SIZE)(0)

  def getBuffer(id: Int) = {
	if (id == bufferId)
	  buffer
	else {
	  buffer = predecessor.getBuffer(id)
	  bufferId = id
	  buffer
	}
  }
  
}