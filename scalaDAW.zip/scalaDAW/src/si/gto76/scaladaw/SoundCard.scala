package si.gto76.scaladaw

import javax.sound.sampled.AudioFormat
import javax.sound.sampled.DataLine
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.AudioSystem
import java.io.File
import javax.sound.sampled.AudioInputStream

object SoundCard {
  
  val EXTERNAL_BUFFER_SIZE = 128000
  var nBytesRead = 128000
  var bufferByte = Array.fill[Byte](EXTERNAL_BUFFER_SIZE)(0)
  var bufferFp = Array.fill[Double](EXTERNAL_BUFFER_SIZE)(0)
  var bufferId = 0
  //***
  
  //***
  //val outDataFormat: AudioFormat = new AudioFormat(44100.0.asInstanceOf[Float], 16, 1, true, false);
 
  val soundFile = new File(ScalaDAW.fileName)
  val audioInputStream: AudioInputStream = try {
    AudioSystem.getAudioInputStream(soundFile)
  }
  val	outDataFormat = audioInputStream.getFormat()
  audioInputStream.close()
  
  
  val	info: DataLine.Info = new DataLine.Info(classOf[SourceDataLine], outDataFormat)
  val line: SourceDataLine = try {
	(AudioSystem.getLine(info)).asInstanceOf[SourceDataLine]
  }
  try {
	line.open(outDataFormat)
  }
  line.start()

  /*
  var soundCardSends: List[SoundCardSend] = List()
  def addSoundCardSend(soundCardSend: SoundCardSend) {
    soundCardSends = soundCardSend::soundCardSends
  }
  */
  
  var soundCardSend = new Send
  /*
  def addSoundCardSend(soundCardSend: SoundCardSend) {
    this.soundCardSend = soundCardSend
  }
  */
  
  def play() = {
	  while (true) {
        bufferFp = soundCardSend.getBuffer(bufferId)
        bufferByte = Converter.convertBufferToByte(outDataFormat, bufferFp)
        line.write(bufferByte, 0, nBytesRead)
        bufferId = bufferId + 1
        print(bufferFp(0)+": "+bufferByte(0) +" " + bufferByte(1)+"\n")
	  }
    line.drain()
    line.close()
  }

}