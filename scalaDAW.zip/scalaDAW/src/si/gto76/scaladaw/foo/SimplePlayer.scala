package si.gto76.scaladaw.foo

import si.gto76.scaladaw.inserts._
import java.io.File
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.DataLine
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.LineUnavailableException
import java.io.IOException
import scala.util.parsing.combinator.testing.Number

object SimplePlayer {

  val EXTERNAL_BUFFER_SIZE = 128000
  var nBytesRead = 0
  var abData = Array.fill[Byte](EXTERNAL_BUFFER_SIZE)(0)
  
  //****** I N S E R T S ******//
  val noiser = new Noiser()
  val noiserPar = new NoiserParameters(30)
  noiser.setParameters(noiserPar)

  val averager = new Averager
  val averagerPar = new AveragerParameters(2)
  averager.setParameters(averagerPar)

  val tremolo = new Tremolo
  val tremoloPar = new TremoloParameters(126, 3.0, 1000, 10000)
  tremolo.setParameters(tremoloPar)

  val cleanInsert = new CleanInsert
  val cleanParameters = new CleanParameters
  //****** - - - - - - - ******//
  
  def main(args: Array[String]) {
    /*
		  We check that there is exactely one command-line
		  argument.
		  If not, we display the usage message and exit.
		*/
    if (args.length != 1) {
      printUsageAndExit();
    }

    /*
		  Now, that we're shure there is an argument, we
		  take it as the filename of the sound file
		  we want to play.
		*/
    val strFilename = args(0)
    val soundFile = new File(strFilename)

    /*
		  We have to read in the sound file.
		*/
    var audioInputStream: AudioInputStream = null
    try {
      audioInputStream = AudioSystem.getAudioInputStream(soundFile);
    } catch {
      case e => e.printStackTrace(); System.exit(1)
    }

    /*
		  From the AudioInputStream, i.e. from the sound file,
		  we fetch information about the format of the
		  audio data.
		  These information include the sampling frequency,
		  the number of
		  channels and the size of the samples.
		  These information
		  are needed to ask Java Sound for a suitable output line
		  for this audio file.
		*/
    val audioFormat = audioInputStream.getFormat();

    /*
		  Asking for a line is a rather tricky thing.
		  We have to construct an Info object that specifies
		  the desired properties for the line.
		  First, we have to say which kind of line we want. The
		  possibilities are: SourceDataLine (for playback), Clip
		  (for repeated playback)	and TargetDataLine (for
		  recording).
		  Here, we want to do normal playback, so we ask for
		  a SourceDataLine.
		  Then, we have to pass an AudioFormat object, so that
		  the Line knows which format the data passed to it
		  will have.
		  Furthermore, we can give Java Sound a hint about how
		  big the internal buffer for the line should be. This
		  isn't used here, signaling that we
		  don't care about the exact size. Java Sound will use
		  some default value for the buffer size.
		*/
    var line: SourceDataLine = null
    val info: DataLine.Info = new DataLine.Info(classOf[SourceDataLine],
      audioFormat)

    try {
      line = (AudioSystem.getLine(info)).asInstanceOf[SourceDataLine]
      /*
			  The line is there, but it is not yet ready to
			  receive audio data. We have to open the line.
			*/
      line.open(audioFormat);
    } catch {
      case e: LineUnavailableException => e.printStackTrace(); System.exit(1)
      case e: Exception => e.printStackTrace(); System.exit(1)
    }

    /*
		  Still not enough. The line now can receive data,
		  but will not pass them on to the audio output device
		  (which means to your sound card). This has to be
		  activated.
		*/
    line.start();

    /*
		  Ok, finally the line is prepared. Now comes the real
		  job: we have to write data to the line. We do this
		  in a loop. First, we read data from the
		  AudioInputStream to a buffer. Then, we write from
		  this buffer to the Line. This is done until the end
		  of the file is reached, which is detected by a
		  return value of -1 from the read method of the
		  AudioInputStream.
		*/
    while (nBytesRead != -1) {
      try {
        nBytesRead = audioInputStream.read(abData, 0, abData.length);
      } catch {
        case e: IOException => e.printStackTrace()
      }

      if (nBytesRead >= 0) {
        //abData = averager.processBuffer(abData)
        //abData = tremolo.processBuffer(abData)
        //abData = noiser.processBuffer(abData)
        val nBytesWritten = line.write(abData, 0, nBytesRead);
      }
    }

    /*
		  Wait until all data are played.
		  This is only necessary because of the bug noted below.
		  (If we do not wait, we would interrupt the playback by
		  prematurely closing the line and exiting the VM.)
		 
		  Thanks to Margie Fitch for bringing me on the right
		  path to this solution.
		*/
    line.drain();

    /*
		  All data are played. We can close the shop.
		*/
    line.close();

    /*
		  There is a bug in the jdk1.3/1.4.
		  It prevents correct termination of the VM.
		  So we have to exit ourselves.
		*/
    System.exit(0);
  }

  /*****/

  def printUsageAndExit() {
    println("SimpleAudioPlayer: usage:");
    println("\tjava SimpleAudioPlayer <soundfile>");
    System.exit(1);
  }

}
