package si.gto76.scaladaw.foo

import java.io.File
import javax.sound.sampled.AudioInputStream
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.SourceDataLine
import javax.sound.sampled.DataLine
import javax.sound.sampled.AudioSystem
import javax.sound.sampled.LineUnavailableException
import java.io.IOException

object SimplePlayerScala {

  val EXTERNAL_BUFFER_SIZE = 128000
  var nBytesRead = 0
  var abData = Array.fill[Byte](EXTERNAL_BUFFER_SIZE)(0)

  def main(args: Array[String]) {
	
	val soundFile = new File(args(0))
	val audioInputStream: AudioInputStream = try {
	  AudioSystem.getAudioInputStream(soundFile)
	}

	val	audioFormat = audioInputStream.getFormat();
	val	info: DataLine.Info = new DataLine.Info(classOf[SourceDataLine], audioFormat)
	val line: SourceDataLine = try {
		(AudioSystem.getLine(info)).asInstanceOf[SourceDataLine]
	}
	try {
		line.open(audioFormat)
	}
	line.start()

	while (nBytesRead != -1) {
      try {
        nBytesRead = audioInputStream.read(abData, 0, abData.length)
      }
      if (nBytesRead >= 0) {
        val nBytesWritten = line.write(abData, 0, nBytesRead)
      }
    }

	line.drain()
	line.close()

  }
}