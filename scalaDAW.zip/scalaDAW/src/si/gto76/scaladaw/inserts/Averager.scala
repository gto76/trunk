package si.gto76.scaladaw.inserts

import si.gto76.scaladaw._

class Averager() extends Insert() {
  
  parameters = new AveragerParameters(10)
  var params: AveragerParameters = _

  var average: Double = 0.1;

  def run() = {
    for (i <- 0 to signalIn.length - 1) {
      signalOut(i) = averageSample(signalIn(i))
    }
  }

  def averageSample(sample: Double) = {
    params = parameters.asInstanceOf[AveragerParameters]
    refreshAverage(sample)
    average
  }

  def refreshAverage(sample: Double) = {
    average = average * ((params.windowSize - 1.0) / params.windowSize)
    average += sample / params.windowSize
  }
}

class AveragerParameters(val windowSize: Int) extends InsertParameters {
}
