package si.gto76.scaladaw.inserts

import si.gto76.scaladaw._

class CleanInsert() extends Insert() {
  def run() = {
    signalOut = signalIn
  }
}

class CleanParameters() extends InsertParameters {
}