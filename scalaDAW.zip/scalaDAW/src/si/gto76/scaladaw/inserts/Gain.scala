package si.gto76.scaladaw.inserts

import si.gto76.scaladaw._

class Gain() extends Insert() {
  
  parameters = new GainParameters(0.2)

  def run() = {
    for (i <- 0 to signalIn.length - 1) {
      signalOut(i) = addGainToSample(signalIn(i))
    }
  }

  def addGainToSample(sample: Double): Double = {
    val gain = parameters.asInstanceOf[GainParameters].level
    sample * gain
  }

}

class GainParameters(val level: Double) extends InsertParameters {
}
