package si.gto76.scaladaw.inserts

import si.gto76.scaladaw._
import java.lang.Math

class Noiser() extends Insert() {
  
  parameters = new NoiserParameters(5)

  def run() = {
    for (i <- 0 to signalIn.length - 1) {
      signalOut(i) = addNoiseToSample(signalIn(i))
    }
  }

  def addNoiseToSample(sample: Double): Double = {
    val level = parameters.asInstanceOf[NoiserParameters].level
    val noisePressure = ((Math.random() - 0.5) * level)
    noisePressure + sample
  }

}

class NoiserParameters(val level: Int) extends InsertParameters {
}
