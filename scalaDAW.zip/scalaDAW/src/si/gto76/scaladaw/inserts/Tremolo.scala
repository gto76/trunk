package si.gto76.scaladaw.inserts

import si.gto76.scaladaw._

class Tremolo() extends Insert() {
/*
 * TODO: Ni �e prirejeno za Double!!!!!
 */
  parameters = new TremoloParameters(126, 3.0, 1000, 10000)
  var params: TremoloParameters = _
  
	// internal parameters:
	var compFactor = 1.0;
	var peakTemp: Double = 0;
	var peakTimeDelta = 1;
	val SPEED: Double = 1000
	var headRoom: Int = _

	def run() = {
	  	for (i <- 0 to signalIn.length-1) {
			signalOut(i) = tremolizeSample(signalIn(i))
		}
	}	
	
	def tremolizeSample(level: Double): Double = {
	    params = parameters.asInstanceOf[TremoloParameters]
	    headRoom = Byte.MaxValue - params.threshold
		refreshComp(level);
		return (level / compFactor).asInstanceOf[Byte];
	}
	
	//*******//
	
	def refreshComp(sample: Double) = {
		if (sample > peakTemp) {
			peakTemp = sample;
			peakTimeDelta = 1;
		} else {
			peakTimeDelta += 1;
		}
		
		if (peakTimeDelta > (params.attack + params.release)) {
			peakTimeDelta = 1;
			peakTemp = 0;
		}
		calculateCompFactor();
	}

	def calculateCompFactor() = {
		if (peakTemp < params.threshold) {
			setCompFactorSoftly(1.0);
		} else {
			if (peakTimeDelta < params.attack) {
				//attack
				attackRel(peakTimeDelta.asInstanceOf[Double]/params.attack);
			} else {
				//release
				attackRel(((( (peakTimeDelta.asInstanceOf[Double]+1) - params.attack)/ params.release)*(-1.0))+1);
			}
		}
	}
	
	def attackRel(factor: Double) = {
		val over = peakTemp - params.threshold
		val ratioFactor: Double = (over+1)/headRoom
		val ratioF: Double = ratioFactor * params.ratio;		
		setCompFactorSoftly(ratioF*factor);
	}

	def setCompFactorSoftly(factor: Double) {
		val delta: Double = Math.abs(compFactor - factor);
		if (delta < 0.01) {
			compFactor = factor;
		} else {
			if ((compFactor - factor) < 0) { //new factor bigger
				compFactor += (delta / SPEED) ;
			} else { //new factor smaller
				compFactor -= (delta / SPEED) ;				
			}
		}
		if (compFactor < 1.0) compFactor = 1.0;
		if (compFactor > 3.0) compFactor = 3.0;
	}
	
}

class TremoloParameters(val threshold: Byte, 
						val ratio: Double, 
						val attack: Int, 
						val release: Int) 
						extends InsertParameters {
}

